import { supabase } from '../lib/supabase';

// Password requirements
const PASSWORD_MIN_LENGTH = 12;
const PASSWORD_MAX_LENGTH = 128;

// Common password list (top 1000 most common passwords)
const commonPasswords = new Set([
  'password', 'password123', '123456', '12345678', 'qwerty',
  'letmein', 'dragon', 'monkey', 'football', 'baseball',
  'abc123', 'welcome', 'admin123', 'login', 'master',
  '123qwe', '123abc', '123456789', 'qwerty123', 'superman'
  // Add more as needed
]);

interface PasswordValidationError {
  code: string;
  message: string;
}

export interface PasswordValidationResult {
  isValid: boolean;
  errors: PasswordValidationError[];
}

// Check for minimum length and maximum length
function validateLength(password: string): PasswordValidationError | null {
  if (password.length < PASSWORD_MIN_LENGTH) {
    return {
      code: 'LENGTH_TOO_SHORT',
      message: `Password must be at least ${PASSWORD_MIN_LENGTH} characters long`
    };
  }
  if (password.length > PASSWORD_MAX_LENGTH) {
    return {
      code: 'LENGTH_TOO_LONG',
      message: `Password cannot be longer than ${PASSWORD_MAX_LENGTH} characters`
    };
  }
  return null;
}

// Check for required character types
function validateCharacterTypes(password: string): PasswordValidationError[] {
  const errors: PasswordValidationError[] = [];
  
  if (!/[A-Z]/.test(password)) {
    errors.push({
      code: 'NO_UPPERCASE',
      message: 'Password must contain at least one uppercase letter'
    });
  }
  
  if (!/[a-z]/.test(password)) {
    errors.push({
      code: 'NO_LOWERCASE',
      message: 'Password must contain at least one lowercase letter'
    });
  }
  
  if (!/[0-9]/.test(password)) {
    errors.push({
      code: 'NO_NUMBER',
      message: 'Password must contain at least one number'
    });
  }
  
  if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
    errors.push({
      code: 'NO_SPECIAL',
      message: 'Password must contain at least one special character'
    });
  }
  
  return errors;
}

// Check for common passwords
function validateCommonPasswords(password: string): PasswordValidationError | null {
  if (commonPasswords.has(password.toLowerCase())) {
    return {
      code: 'COMMON_PASSWORD',
      message: 'This password is too common. Please choose a more unique password'
    };
  }
  return null;
}

// Check for repeating characters
function validateRepeatingCharacters(password: string): PasswordValidationError | null {
  if (/(.)\1{2,}/.test(password)) {
    return {
      code: 'REPEATING_CHARS',
      message: 'Password cannot contain more than 2 repeating characters in a row'
    };
  }
  return null;
}

// Main validation function
export async function validatePassword(
  password: string
): Promise<PasswordValidationResult> {
  const errors: PasswordValidationError[] = [];

  // Basic validations
  const lengthError = validateLength(password);
  if (lengthError) errors.push(lengthError);

  const characterErrors = validateCharacterTypes(password);
  errors.push(...characterErrors);

  const commonPasswordError = validateCommonPasswords(password);
  if (commonPasswordError) errors.push(commonPasswordError);

  const repeatingCharsError = validateRepeatingCharacters(password);
  if (repeatingCharsError) errors.push(repeatingCharsError);

  return {
    isValid: errors.length === 0,
    errors
  };
}