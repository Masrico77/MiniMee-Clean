import { supabase } from '../lib/supabase';

export async function getUserAchievements(userId: string) {
  const { data: achievements, error: achievementsError } = await supabase
    .from('achievements')
    .select('*');

  if (achievementsError) throw achievementsError;

  const { data: userAchievements, error: userAchievementsError } = await supabase
    .from('user_achievements')
    .select('*')
    .eq('user_id', userId);

  if (userAchievementsError) throw userAchievementsError;

  return achievements.map(achievement => ({
    ...achievement,
    unlocked: userAchievements.some(ua => ua.achievement_id === achievement.id),
    unlocked_at: userAchievements.find(ua => ua.achievement_id === achievement.id)?.unlocked_at
  }));
}

export async function getUserLevel(userId: string) {
  const { data: userStats, error: statsError } = await supabase
    .from('user_stats')
    .select('*')
    .eq('user_id', userId)
    .single();

  if (statsError) throw statsError;

  const { data: levels, error: levelsError } = await supabase
    .from('user_levels')
    .select('*')
    .order('level_number', { ascending: true });

  if (levelsError) throw levelsError;

  const currentLevel = levels.find(level => 
    userStats.total_points >= level.min_points
  ) || levels[0];

  const nextLevel = levels.find(level => 
    level.level_number === currentLevel.level_number + 1
  );

  return {
    currentLevel,
    nextLevel,
    points: userStats.total_points
  };
}

export async function checkAndAwardAchievements(userId: string) {
  const { data: userStats, error: statsError } = await supabase
    .from('user_stats')
    .select('*')
    .eq('user_id', userId)
    .single();

  if (statsError) throw statsError;

  const { data: achievements, error: achievementsError } = await supabase
    .from('achievements')
    .select('*');

  if (achievementsError) throw achievementsError;

  const { data: existingAwards, error: existingError } = await supabase
    .from('user_achievements')
    .select('achievement_id')
    .eq('user_id', userId);

  if (existingError) throw existingError;

  const existingAwardIds = existingAwards.map(ea => ea.achievement_id);

  const newAchievements = achievements.filter(achievement => {
    if (existingAwardIds.includes(achievement.id)) return false;

    const requirements = achievement.requirements;
    return Object.entries(requirements).every(([key, value]) => {
      switch (key) {
        case 'entries':
          return userStats.total_entries >= value;
        case 'streak':
          return userStats.current_streak >= value;
        case 'words':
          return userStats.total_words >= value;
        case 'morning_entries':
          return userStats.entries_this_month >= value; // Simplified for example
        case 'night_entries':
          return userStats.entries_this_month >= value; // Simplified for example
        default:
          return false;
      }
    });
  });

  if (newAchievements.length > 0) {
    const { error: insertError } = await supabase
      .from('user_achievements')
      .insert(
        newAchievements.map(achievement => ({
          user_id: userId,
          achievement_id: achievement.id
        }))
      );

    if (insertError) throw insertError;

    // Update user points
    const totalNewPoints = newAchievements.reduce((sum, achievement) => sum + achievement.points, 0);
    
    const { error: updateError } = await supabase
      .from('user_stats')
      .update({ 
        total_points: userStats.total_points + totalNewPoints 
      })
      .eq('user_id', userId);

    if (updateError) throw updateError;
  }

  return newAchievements;
}