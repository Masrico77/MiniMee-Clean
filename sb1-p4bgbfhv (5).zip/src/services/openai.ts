import { supabase } from '../lib/supabase';
import type { Message } from '../types';

// Custom error class for OpenAI API errors
class OpenAIError extends Error {
  constructor(
    message: string,
    public status?: number,
    public code?: string,
    public retryable: boolean = false
  ) {
    super(message);
    this.name = 'OpenAIError';
  }
}

// Retry configuration
const MAX_RETRIES = 3;
const INITIAL_RETRY_DELAY = 1000;
const MAX_RETRY_DELAY = 10000;

// Helper function for exponential backoff
function getRetryDelay(attempt: number): number {
  const delay = Math.min(
    INITIAL_RETRY_DELAY * Math.pow(2, attempt),
    MAX_RETRY_DELAY
  );
  return delay + Math.random() * 1000; // Add jitter
}

async function getAIResponse(prompt: string, answer: string, type: 'journal' | 'chat' = 'journal', userId?: string): Promise<string> {
  let attempt = 0;

  while (true) {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new OpenAIError('Authentication required', 401, 'auth_required', false);
      }

      let context = '';
      if (userId) {
        context = await getComprehensiveContext(userId);
      }

      const systemPrompt = type === 'chat' 
        ? [
            `You are MiniMee, a friendly AI chat companion focused on personal growth.`,
            `Keep responses short, friendly, and conversational - like chatting with a supportive friend.`,
            `\nGuidelines:`,
            `- Keep responses under 3 sentences`,
            `- Use casual, friendly language`,
            `- Reference journal entries when relevant`,
            `- Focus on one key point or insight`,
            `- Never ask for personal details`,
            `- Be encouraging but brief`
          ].join('\n')
        : [
            `You are MiniMee, an AI journaling companion focused on personal growth.`,
            `Provide thoughtful insights while maintaining a natural, conversational flow.`,
            `\nGuidelines:`,
            `1. Reference specific details from context`,
            `2. Identify patterns and themes`,
            `3. Offer thoughtful insights`,
            `4. Maintain privacy (never ask for personal details)`,
            `5. Keep responses focused and clear`
          ].join('\n');

      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${import.meta.env.VITE_OPENAI_API_KEY}`,
        },
        body: JSON.stringify({
          model: "gpt-4-turbo-preview",
          messages: [
            { role: "system", content: systemPrompt },
            { 
              role: "user", 
              content: [
                context ? `Context:\n${context}\n` : '',
                "Current Input:",
                prompt,
                "\nUser's Response:",
                answer
              ].join('\n')
            }
          ],
          temperature: type === 'chat' ? 0.8 : 0.7,
          max_tokens: type === 'chat' ? 100 : 750,
          presence_penalty: 0.6,
          frequency_penalty: 0.4,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => null);
        const status = response.status;
        const retryable = status === 429 || status >= 500;

        throw new OpenAIError(
          errorData?.error?.message || `OpenAI API error: ${status} ${response.statusText}`,
          status,
          errorData?.error?.code,
          retryable
        );
      }

      const data = await response.json();
      if (!data?.choices?.[0]?.message?.content) {
        throw new OpenAIError('Invalid response format from OpenAI API', undefined, 'invalid_response', true);
      }

      const aiResponse = data.choices[0].message.content;
      return aiResponse;

    } catch (error) {
      console.error('Error in getAIResponse:', error);

      if (error instanceof OpenAIError) {
        // Check if we should retry
        if (error.retryable && attempt < MAX_RETRIES) {
          attempt++;
          const delay = getRetryDelay(attempt);
          await new Promise(resolve => setTimeout(resolve, delay));
          continue; // Retry the request
        }

        // Map errors to user-friendly messages
        if (error.status === 401) {
          throw new Error('Please sign in again to continue.');
        }
        if (error.status === 429) {
          throw new Error('Too many requests. Please wait a moment and try again.');
        }
        if (error.status >= 500) {
          throw new Error('Service temporarily unavailable. Please try again later.');
        }
      }

      // For network or other errors
      if (error instanceof TypeError && error.message.includes('fetch')) {
        throw new Error('Unable to connect. Please check your internet connection.');
      }

      // Default error message
      throw new Error('Unable to generate response. Please try again.');
    }
  }
}

export async function getJournalResponse(prompt: string, answer: string, userId?: string): Promise<string> {
  try {
    return await getAIResponse(prompt, answer, 'journal', userId);
  } catch (error) {
    console.error('Error in getJournalResponse:', error);
    throw error instanceof Error ? error : new Error('Failed to generate journal response');
  }
}

export async function getChatResponse(prompt: string, answer: string, userId?: string): Promise<string> {
  try {
    return await getAIResponse(prompt, answer, 'chat', userId);
  } catch (error) {
    console.error('Error in getChatResponse:', error);
    throw error instanceof Error ? error : new Error('Failed to generate chat response');
  }
}

export async function generatePersonalizedPrompt(userId: string): Promise<string> {
  try {
    return await getAIResponse(
      "Generate a personalized journaling prompt",
      "Based on the user's history, create a thoughtful prompt that encourages reflection while maintaining privacy",
      'journal',
      userId
    );
  } catch (error) {
    console.error('Error in generatePersonalizedPrompt:', error);
    throw error instanceof Error ? error : new Error('Failed to generate personalized prompt');
  }
}

async function getComprehensiveContext(userId: string): Promise<string> {
  try {
    // Get all journal entries from the past week with metadata
    const { data: journalEntries, error: journalError } = await supabase
      .from('journal_entries')
      .select('prompt, answer, ai_response, created_at, metadata')
      .eq('user_id', userId)
      .gte('created_at', new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString())
      .order('created_at', { ascending: true });

    if (journalError) throw journalError;

    // Get all chat messages from the past week with metadata
    const { data: chatMessages, error: chatError } = await supabase
      .from('chat_messages')
      .select('role, content, created_at, metadata')
      .eq('user_id', userId)
      .gte('created_at', new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString())
      .order('created_at', { ascending: true });

    if (chatError) throw chatError;

    // Get user stats and progress
    const { data: userStats, error: statsError } = await supabase
      .from('user_stats')
      .select('*')
      .eq('user_id', userId)
      .single();

    if (statsError) throw statsError;

    // Build rich context with temporal and emotional patterns
    let context = 'Weekly Activity Analysis:\n\n';

    // Add progress metrics
    context += 'Progress Metrics:\n';
    context += `Current Streak: ${userStats.current_streak} days\n`;
    context += `Longest Streak: ${userStats.longest_streak} days\n`;
    context += `Total Entries: ${userStats.total_entries}\n`;
    context += `Weekly Entries: ${journalEntries?.length || 0}\n`;
    context += `Weekly Chat Interactions: ${chatMessages?.filter(m => m.role === 'user').length || 0}\n\n`;

    // Add journal entries with temporal context
    if (journalEntries?.length) {
      context += 'Journal Activity:\n';
      const entriesByDay = new Map<string, any[]>();
      
      journalEntries.forEach(entry => {
        const date = new Date(entry.created_at).toLocaleDateString();
        if (!entriesByDay.has(date)) {
          entriesByDay.set(date, []);
        }
        entriesByDay.get(date)?.push(entry);
      });

      Array.from(entriesByDay.entries()).forEach(([date, entries]) => {
        context += `\n[${date}]\n`;
        entries.forEach(entry => {
          context += `Q: ${entry.prompt}\n`;
          context += `A: ${entry.answer}\n`;
          if (entry.metadata?.emotional_themes?.length) {
            context += `Emotional Themes: ${entry.metadata.emotional_themes.join(', ')}\n`;
          }
          if (entry.metadata?.key_topics?.length) {
            context += `Key Topics: ${entry.metadata.key_topics.join(', ')}\n`;
          }
          if (entry.metadata?.sentiment_indicators) {
            const sentiment = entry.metadata.sentiment_indicators;
            context += `Sentiment: ${JSON.stringify(sentiment)}\n`;
          }
          context += `AI Response: ${entry.ai_response}\n`;
        });
      });
    }

    // Add chat interactions with temporal context
    if (chatMessages?.length) {
      context += '\nChat Interactions:\n';
      const chatsByDay = new Map<string, any[]>();
      
      chatMessages.forEach(msg => {
        const date = new Date(msg.created_at).toLocaleDateString();
        if (!chatsByDay.has(date)) {
          chatsByDay.set(date, []);
        }
        chatsByDay.get(date)?.push(msg);
      });

      Array.from(chatsByDay.entries()).forEach(([date, messages]) => {
        context += `\n[${date}]\n`;
        messages.forEach(msg => {
          const role = msg.role === 'user' ? 'User' : 'AI';
          context += `${role}: ${msg.content}\n`;
          if (msg.metadata?.emotional_themes?.length) {
            context += `Themes: ${msg.metadata.emotional_themes.join(', ')}\n`;
          }
          if (msg.metadata?.key_topics?.length) {
            context += `Topics: ${msg.metadata.key_topics.join(', ')}\n`;
          }
        });
      });
    }

    return context;
  } catch (error) {
    console.error('Error getting comprehensive context:', error);
    return '';
  }
}

export async function generateWeeklySummary(userId: string): Promise<string> {
  const prompt = `As MiniMee, create a thoughtful, conversational weekly summary that feels like a supportive friend sharing observations about their journey. The analysis should flow naturally while covering three key areas:

Key Themes & Patterns
Write a natural paragraph discussing the emotional patterns and recurring topics you've noticed across their journals and chats this week. Weave in specific examples to illustrate these patterns, noting any shifts in perspective or mood. Connect themes between journal entries and chat conversations to show how different aspects of their reflection journey connect.

Insights & Observations
Share meaningful observations about their reflection journey in a warm, conversational way. Discuss moments of clarity or breakthrough you've noticed, connecting current insights with past reflections. Highlight particularly thoughtful or deep reflections, using specific examples to illustrate their growing self-awareness while maintaining privacy.

Growth & Progress
Celebrate their achievements and progress in a supportive, encouraging tone. Discuss improvements you've noticed in their reflection depth or consistency, acknowledge challenges they're working through, and highlight positive changes in their journaling practice. Offer gentle encouragement for continued growth while connecting current progress to their overall journey.

Guidelines:
1. Write in a warm, conversational tone like a supportive friend
2. Reference specific examples while maintaining privacy
3. Connect insights across different days and interactions
4. Focus on patterns and growth rather than specific events
5. Acknowledge both challenges and victories
6. Keep the analysis flowing naturally between topics
7. Avoid bullet points - use natural paragraph transitions

Remember to maintain a supportive, encouraging tone while keeping all personal details private. Focus on patterns, growth, and insights rather than specific personal events.`;

  try {
    const context = await getComprehensiveContext(userId);
    return await getAIResponse(prompt, context, 'journal', userId);
  } catch (error) {
    console.error('Error generating weekly summary:', error);
    throw error;
  }
}