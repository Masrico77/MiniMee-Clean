import { supabase } from '../lib/supabase';

// Check if the browser supports notifications
export function checkNotificationSupport(): boolean {
  return 'Notification' in window && 'serviceWorker' in navigator;
}

// Request notification permission
export async function requestNotificationPermission(): Promise<boolean> {
  try {
    const permission = await Notification.requestPermission();
    return permission === 'granted';
  } catch (error) {
    console.error('Error requesting notification permission:', error);
    return false;
  }
}

// Save notification preferences
export async function saveNotificationPreferences(
  userId: string,
  morningEnabled: boolean = true,
  eveningEnabled: boolean = true,
  morningTime: string = '09:00',
  eveningTime: string = '20:00'
): Promise<void> {
  try {
    const { error } = await supabase
      .from('profiles')
      .update({
        preferences: {
          notifications: {
            morning: {
              enabled: morningEnabled,
              time: morningTime
            },
            evening: {
              enabled: eveningEnabled,
              time: eveningTime
            }
          }
        }
      })
      .eq('id', userId);

    if (error) throw error;
  } catch (error) {
    console.error('Error saving notification preferences:', error);
    throw error;
  }
}

// Subscribe to push notifications
export async function subscribeToPushNotifications(userId: string): Promise<void> {
  try {
    // Register service worker
    const registration = await navigator.serviceWorker.register('/service-worker.js');

    // Get push subscription
    const subscription = await registration.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: import.meta.env.VITE_VAPID_PUBLIC_KEY
    });

    // Save subscription to database
    const { error } = await supabase
      .from('push_subscriptions')
      .upsert({
        user_id: userId,
        subscription: subscription,
        created_at: new Date().toISOString()
      });

    if (error) throw error;
  } catch (error) {
    console.error('Error subscribing to push notifications:', error);
    throw error;
  }
}