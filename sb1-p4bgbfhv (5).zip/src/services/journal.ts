import { supabase } from '../lib/supabase';
import { journalPrompts } from '../config/prompts';

export async function getJournalStats(userId: string) {
  try {
    // Force a recalculation of stats before fetching
    await supabase.rpc('recalculate_streaks', { p_user_id: userId });

    const { data, error } = await supabase
      .from('user_stats')
      .select('total_entries, current_streak, last_entry_date')
      .eq('user_id', userId)
      .single();

    if (error) throw error;

    return {
      totalEntries: data?.total_entries ?? 0,
      currentStreak: data?.current_streak ?? 0,
      lastEntryDate: data?.last_entry_date ?? null
    };
  } catch (error) {
    console.error('Error getting journal stats:', error);
    throw error;
  }
}

export async function canSubmitJournalToday(userId: string): Promise<boolean> {
  try {
    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);
    
    // Check if there's already a completed journal for today
    const { data: completedEntries, error: completedError } = await supabase
      .from('journal_entries')
      .select('id')
      .eq('user_id', userId)
      .eq('completed', true)
      .gte('created_at', startOfDay.toISOString())
      .limit(1);

    if (completedError) throw completedError;
    if (completedEntries?.length > 0) return false;

    // Check number of prompts answered today
    const { data: todayEntries, error } = await supabase
      .from('journal_entries')
      .select('prompt')
      .eq('user_id', userId)
      .gte('created_at', startOfDay.toISOString());

    if (error) throw error;

    const answeredPrompts = new Set(todayEntries?.map(entry => entry.prompt) || []);
    return answeredPrompts.size < journalPrompts.length;
  } catch (error) {
    console.error('Error checking journal submission:', error);
    throw error;
  }
}

export async function completeJournal(userId: string): Promise<void> {
  try {
    // Get today's entries
    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);
    
    const { data: todayEntries, error: entriesError } = await supabase
      .from('journal_entries')
      .select('id, prompt')
      .eq('user_id', userId)
      .gte('created_at', startOfDay.toISOString());

    if (entriesError) throw entriesError;

    // Verify all prompts are answered
    if (!todayEntries || todayEntries.length < journalPrompts.length) {
      throw new Error('Please answer all journal prompts before completing');
    }

    const answeredPrompts = new Set(todayEntries.map(entry => entry.prompt));
    const allPromptsAnswered = journalPrompts.every(prompt => 
      answeredPrompts.has(prompt.question)
    );

    if (!allPromptsAnswered) {
      throw new Error('Please answer all journal prompts before completing');
    }

    // Mark all entries as completed
    const { error: updateError } = await supabase
      .from('journal_entries')
      .update({ completed: true })
      .in('id', todayEntries.map(entry => entry.id));

    if (updateError) throw updateError;

    // Force a recalculation of streaks
    const { error: recalcError } = await supabase
      .rpc('recalculate_streaks', { p_user_id: userId });

    if (recalcError) throw recalcError;

    // Fetch updated stats to ensure UI is in sync
    await getJournalStats(userId);
  } catch (error) {
    console.error('Error completing journal:', error);
    throw error;
  }
}

export async function saveJournalEntry(
  userId: string,
  prompt: string,
  answer: string,
  aiResponse: string
) {
  try {
    // Extract metadata from the entry
    const metadata = {
      emotional_themes: extractEmotionalThemes(answer),
      key_topics: extractKeyTopics(answer),
      word_count: answer.split(/\s+/).length,
      timestamp: new Date().toISOString(),
      prompt_category: categorizePrompt(prompt),
      sentiment_indicators: analyzeSentiment(answer)
    };

    // Save the entry with metadata
    const { data: entry, error: entryError } = await supabase
      .from('journal_entries')
      .insert([{
        user_id: userId,
        prompt,
        answer,
        ai_response: aiResponse,
        metadata,
        completed: false // Explicitly set completed to false for new entries
      }])
      .select()
      .single();

    if (entryError) throw entryError;

    // Get today's entries after saving
    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);
    
    const { data: todayEntries, error: entriesError } = await supabase
      .from('journal_entries')
      .select('prompt, answer')
      .eq('user_id', userId)
      .gte('created_at', startOfDay.toISOString());

    if (entriesError) throw entriesError;

    // Check if all prompts are answered
    if (todayEntries && todayEntries.length === journalPrompts.length) {
      // Force a recalculation of streaks
      const { error: recalcError } = await supabase
        .rpc('recalculate_streaks', { p_user_id: userId });

      if (recalcError) throw recalcError;

      // Fetch updated stats to ensure UI is in sync
      await getJournalStats(userId);
    }

    return entry;
  } catch (error) {
    console.error('Error in saveJournalEntry:', error);
    throw error;
  }
}

// Helper functions for metadata extraction
function extractEmotionalThemes(text: string): string[] {
  const emotionalKeywords = {
    joy: ['happy', 'excited', 'grateful', 'love', 'wonderful'],
    sadness: ['sad', 'disappointed', 'hurt', 'lonely'],
    anger: ['angry', 'frustrated', 'annoyed', 'upset'],
    fear: ['afraid', 'worried', 'anxious', 'nervous'],
    hope: ['hopeful', 'optimistic', 'looking forward'],
    growth: ['learning', 'improving', 'growing', 'progress']
  };

  const themes = new Set<string>();
  const lowercaseText = text.toLowerCase();

  Object.entries(emotionalKeywords).forEach(([theme, keywords]) => {
    if (keywords.some(keyword => lowercaseText.includes(keyword))) {
      themes.add(theme);
    }
  });

  return Array.from(themes);
}

function extractKeyTopics(text: string): string[] {
  const topics = new Set<string>();
  const sentences = text.split(/[.!?]+/).filter(Boolean);

  sentences.forEach(sentence => {
    const lowercaseSentence = sentence.toLowerCase().trim();
    if (lowercaseSentence.includes('because')) topics.add('reasoning');
    if (lowercaseSentence.includes('feel') || lowercaseSentence.includes('feeling')) topics.add('emotions');
    if (lowercaseSentence.includes('think') || lowercaseSentence.includes('believe')) topics.add('thoughts');
    if (lowercaseSentence.includes('want') || lowercaseSentence.includes('goal')) topics.add('aspirations');
    if (lowercaseSentence.includes('learned') || lowercaseSentence.includes('realized')) topics.add('insights');
  });

  return Array.from(topics);
}

function categorizePrompt(prompt: string): string {
  const categories = {
    reflection: ['reflect', 'think about', 'remember', 'recall'],
    emotion: ['feel', 'emotion', 'mood', 'happy', 'sad'],
    growth: ['learn', 'improve', 'grow', 'change', 'goal'],
    gratitude: ['grateful', 'thankful', 'appreciate'],
    challenge: ['challenge', 'difficult', 'overcome', 'struggle']
  };

  const lowercasePrompt = prompt.toLowerCase();
  for (const [category, keywords] of Object.entries(categories)) {
    if (keywords.some(keyword => lowercasePrompt.includes(keyword))) {
      return category;
    }
  }

  return 'general';
}

function analyzeSentiment(text: string): Record<string, number> {
  const sentiments = {
    positive: 0,
    negative: 0,
    neutral: 0
  };

  const positiveWords = ['good', 'great', 'happy', 'excited', 'love', 'wonderful', 'amazing'];
  const negativeWords = ['bad', 'sad', 'angry', 'upset', 'hate', 'terrible', 'awful'];

  const words = text.toLowerCase().split(/\s+/);
  words.forEach(word => {
    if (positiveWords.includes(word)) sentiments.positive++;
    else if (negativeWords.includes(word)) sentiments.negative++;
    else sentiments.neutral++;
  });

  return sentiments;
}

export async function getJournalHistory(userId: string) {
  try {
    const { data, error } = await supabase
      .from('journal_entries')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Error in getJournalHistory:', error);
    throw error;
  }
}