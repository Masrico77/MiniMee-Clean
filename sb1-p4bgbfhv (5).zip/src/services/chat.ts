import { supabase } from '../lib/supabase';
import type { Message, ChatConversation } from '../types';

export async function saveChatMessage(
  userId: string,
  conversationId: string | null,
  role: 'user' | 'assistant',
  content: string
) {
  try {
    // If no conversationId, create a new conversation
    if (!conversationId) {
      const { data: conversation, error: convError } = await supabase
        .from('chat_conversations')
        .insert([{ user_id: userId }])
        .select()
        .single();

      if (convError) throw convError;
      conversationId = conversation.id;
    }

    // Extract metadata
    const metadata = {
      emotional_themes: extractEmotionalThemes(content),
      key_topics: extractKeyTopics(content),
      references: extractReferences(content),
      word_count: content.split(/\s+/).length,
      timestamp: new Date().toISOString(),
      conversation_markers: extractConversationMarkers(content),
      sentiment_indicators: analyzeSentiment(content)
    };

    // Save the message with metadata
    const { data: message, error: msgError } = await supabase
      .from('chat_messages')
      .insert([{
        conversation_id: conversationId,
        role,
        content,
        user_id: userId,
        metadata
      }])
      .select()
      .single();

    if (msgError) throw msgError;
    return { message, conversationId };
  } catch (error) {
    console.error('Error saving chat message:', error);
    throw error;
  }
}

export async function getChatHistory(userId: string): Promise<ChatConversation[]> {
  try {
    const { data: conversations, error: convError } = await supabase
      .from('chat_conversations')
      .select(`
        id,
        created_at,
        chat_messages (
          id,
          role,
          content,
          created_at,
          metadata
        )
      `)
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (convError) throw convError;
    return conversations || [];
  } catch (error) {
    console.error('Error getting chat history:', error);
    throw error;
  }
}

export async function getConversation(conversationId: string): Promise<Message[]> {
  try {
    const { data: messages, error } = await supabase
      .from('chat_messages')
      .select('*')
      .eq('conversation_id', conversationId)
      .order('created_at', { ascending: true });

    if (error) throw error;
    return messages || [];
  }
  catch (error) {
    console.error('Error getting conversation:', error);
    throw error;
  }
}

// Helper functions for metadata extraction
function extractEmotionalThemes(text: string): string[] {
  const emotionalKeywords = {
    joy: ['happy', 'excited', 'grateful', 'love', 'wonderful', 'amazing'],
    sadness: ['sad', 'disappointed', 'hurt', 'lonely', 'depressed'],
    anger: ['angry', 'frustrated', 'annoyed', 'upset'],
    fear: ['afraid', 'worried', 'anxious', 'nervous'],
    hope: ['hopeful', 'optimistic', 'looking forward', 'excited about'],
    growth: ['learning', 'improving', 'growing', 'developing', 'progress']
  };

  const themes = new Set<string>();
  const lowercaseText = text.toLowerCase();

  Object.entries(emotionalKeywords).forEach(([theme, keywords]) => {
    if (keywords.some(keyword => lowercaseText.includes(keyword))) {
      themes.add(theme);
    }
  });

  return Array.from(themes);
}

function extractKeyTopics(text: string): string[] {
  const topics = new Set<string>();
  const sentences = text.split(/[.!?]+/).filter(Boolean);

  sentences.forEach(sentence => {
    const lowercaseSentence = sentence.toLowerCase().trim();
    if (lowercaseSentence.includes('because')) topics.add('reasoning');
    if (lowercaseSentence.includes('feel') || lowercaseSentence.includes('feeling')) topics.add('emotions');
    if (lowercaseSentence.includes('think') || lowercaseSentence.includes('believe')) topics.add('thoughts');
    if (lowercaseSentence.includes('want') || lowercaseSentence.includes('goal')) topics.add('aspirations');
    if (lowercaseSentence.includes('learned') || lowercaseSentence.includes('realized')) topics.add('insights');
    if (lowercaseSentence.includes('remember') || lowercaseSentence.includes('recall')) topics.add('memories');
    if (lowercaseSentence.includes('future') || lowercaseSentence.includes('plan')) topics.add('future');
    if (lowercaseSentence.includes('challenge') || lowercaseSentence.includes('difficult')) topics.add('challenges');
  });

  return Array.from(topics);
}

function extractReferences(text: string): string[] {
  const references = new Set<string>();
  const lowercaseText = text.toLowerCase();

  // Time references
  if (lowercaseText.includes('previous')) references.add('previous_entries');
  if (lowercaseText.includes('last time')) references.add('recent_entries');
  if (lowercaseText.includes('earlier')) references.add('earlier_entries');
  if (lowercaseText.includes('yesterday')) references.add('yesterday');
  if (lowercaseText.includes('today')) references.add('today');

  // Content references
  if (lowercaseText.includes('journal')) references.add('journal_entries');
  if (lowercaseText.includes('mentioned')) references.add('past_conversations');
  if (lowercaseText.includes('wrote')) references.add('written_content');
  if (lowercaseText.includes('talked about')) references.add('discussed_topics');
  if (lowercaseText.includes('remember when')) references.add('shared_memories');

  return Array.from(references);
}

function extractConversationMarkers(text: string): Record<string, boolean> {
  const markers = {
    continues_previous_topic: false,
    asks_followup: false,
    references_past: false,
    introduces_new_topic: false,
    seeks_clarification: false,
    expresses_agreement: false,
    expresses_disagreement: false
  };

  const lowercaseText = text.toLowerCase();

  markers.continues_previous_topic = /^(and|also|additionally|moreover|furthermore|besides)/i.test(text);
  markers.asks_followup = /\b(what about|how about|tell me more|could you elaborate)\b/i.test(text);
  markers.references_past = /\b(earlier|before|previously|last time|remember|recall)\b/i.test(text);
  markers.introduces_new_topic = /\b(by the way|speaking of|on another note|changing topics)\b/i.test(text);
  markers.seeks_clarification = /\b(what do you mean|could you explain|i don't understand)\b/i.test(text);
  markers.expresses_agreement = /\b(yes|agree|exactly|right|true|indeed)\b/i.test(text);
  markers.expresses_disagreement = /\b(no|disagree|not really|actually|however)\b/i.test(text);

  return markers;
}

function analyzeSentiment(text: string): Record<string, number> {
  const sentiments = {
    positive: 0,
    negative: 0,
    neutral: 0,
    intensity: 0
  };

  const positiveWords = ['good', 'great', 'happy', 'excited', 'love', 'wonderful', 'amazing', 'excellent'];
  const negativeWords = ['bad', 'sad', 'angry', 'upset', 'hate', 'terrible', 'awful', 'disappointed'];
  const intensifiers = ['very', 'really', 'extremely', 'absolutely', 'totally', 'completely'];

  const words = text.toLowerCase().split(/\s+/);
  let hasIntensifier = false;

  words.forEach((word, index) => {
    if (intensifiers.includes(word)) {
      hasIntensifier = true;
      sentiments.intensity++;
    } else {
      const multiplier = hasIntensifier ? 2 : 1;
      if (positiveWords.includes(word)) {
        sentiments.positive += multiplier;
      } else if (negativeWords.includes(word)) {
        sentiments.negative += multiplier;
      } else {
        sentiments.neutral++;
      }
      hasIntensifier = false;
    }
  });

  return sentiments;
}