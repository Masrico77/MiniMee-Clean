import { supabase } from '../lib/supabase';

// Rate limiting configuration
const MAX_ATTEMPTS = 5;
const LOCKOUT_DURATION = 15 * 60 * 1000; // 15 minutes
const rateLimitMap = new Map<string, { attempts: number; lastAttempt: number }>();

// Check rate limit
function checkRateLimit(email: string): boolean {
  const now = Date.now();
  const rateLimit = rateLimitMap.get(email);

  if (rateLimit) {
    if (now - rateLimit.lastAttempt < LOCKOUT_DURATION) {
      if (rateLimit.attempts >= MAX_ATTEMPTS) {
        return false;
      }
    } else {
      // Reset if lockout duration has passed
      rateLimit.attempts = 0;
    }
    rateLimit.attempts++;
    rateLimit.lastAttempt = now;
  } else {
    rateLimitMap.set(email, { attempts: 1, lastAttempt: now });
  }

  return true;
}

export async function signUp(email: string, password: string) {
  if (!checkRateLimit(email)) {
    throw new Error('Too many attempts. Please try again later.');
  }

  try {
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: `${window.location.origin}/auth/callback`,
      }
    });
    
    if (authError) throw authError;
    if (!authData.user) throw new Error('User creation failed');

    return { 
      user: authData.user, 
      isNewUser: true,
      isVerified: false,
      needsEmailVerification: true
    };
  } catch (error) {
    console.error('Error during user setup:', error);
    throw error;
  }
}

export async function signIn(email: string, password: string) {
  if (!checkRateLimit(email)) {
    throw new Error('Too many attempts. Please try again later.');
  }

  try {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    
    if (error) throw error;
    if (!data.user) throw new Error('Sign in failed');

    // Check if email is verified
    if (!data.user.email_confirmed_at) {
      throw new Error('Please verify your email address before signing in');
    }

    // Check onboarding status
    const { data: profile } = await supabase
      .from('profiles')
      .select('onboarding_completed')
      .eq('id', data.user.id)
      .single();

    return { 
      user: data.user, 
      isNewUser: !profile?.onboarding_completed,
      isVerified: true,
      needsEmailVerification: false
    };
  } catch (error) {
    console.error('Error during sign in:', error);
    throw error;
  }
}

export async function resendVerificationEmail(email: string) {
  if (!checkRateLimit(email)) {
    throw new Error('Too many attempts. Please try again later.');
  }

  try {
    const { error } = await supabase.auth.resend({
      type: 'signup',
      email,
      options: {
        emailRedirectTo: `${window.location.origin}/auth/callback`,
      },
    });

    if (error) throw error;
  } catch (error) {
    console.error('Error resending verification email:', error);
    throw error;
  }
}

export async function resetPassword(email: string) {
  if (!checkRateLimit(email)) {
    throw new Error('Too many attempts. Please try again later.');
  }

  try {
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/auth/callback?type=recovery`,
    });

    if (error) {
      // If the error indicates the user doesn't exist, throw a user-friendly error
      if (error.message?.toLowerCase().includes('user not found')) {
        throw new Error('No account exists with this email address');
      }
      throw error;
    }
  } catch (error) {
    console.error('Error in reset password:', error);
    throw error;
  }
}

export async function updatePassword(newPassword: string) {
  try {
    const { error } = await supabase.auth.updateUser({
      password: newPassword
    });

    if (error) throw error;
  } catch (error) {
    console.error('Error updating password:', error);
    throw error;
  }
}

// Helper function to clear auth storage
function clearAuthStorage() {
  try {
    // Clear Supabase-specific storage
    const storageKeys = [
      'supabase.auth.token',
      'supabase.auth.refreshToken',
      'supabase.auth.expires_at',
      'supabase.auth.provider_token',
      'supabase.auth.access_token'
    ];

    storageKeys.forEach(key => {
      try {
        localStorage.removeItem(key);
      } catch (e) {
        console.debug(`Failed to remove ${key} from localStorage:`, e);
      }
      try {
        sessionStorage.removeItem(key);
      } catch (e) {
        console.debug(`Failed to remove ${key} from sessionStorage:`, e);
      }
    });
  } catch (e) {
    console.debug('Error clearing auth storage:', e);
  }
}

export async function signOut() {
  try {
    // First clear all auth storage to ensure clean state
    clearAuthStorage();

    // Attempt to sign out locally first
    await supabase.auth.signOut({ scope: 'local' }).catch(error => {
      console.debug('Local sign out error (non-critical):', error);
    });

    // Get current session state
    const { data: { session } } = await supabase.auth.getSession();

    // If we still have a session, try to sign out globally
    if (session) {
      try {
        await supabase.auth.signOut({ scope: 'global' });
      } catch (error) {
        console.debug('Global sign out error (non-critical):', error);
      }
    }

    // Final cleanup - force a new instance of the Supabase client
    supabase.auth.setSession(null);

  } catch (error) {
    // Log but don't throw - we want the sign out to succeed even if there are errors
    console.debug('Sign out cleanup error (non-critical):', error);
  }
}

export async function checkOnboardingStatus(userId: string) {
  const { data, error } = await supabase
    .from('profiles')
    .select('onboarding_completed')
    .eq('id', userId)
    .single();

  if (error) throw error;
  return data?.onboarding_completed || false;
}

export async function completeOnboarding(userId: string) {
  const { error } = await supabase
    .from('profiles')
    .update({ onboarding_completed: true })
    .eq('id', userId);

  if (error) throw error;
}