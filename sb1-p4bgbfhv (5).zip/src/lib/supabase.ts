import { createClient } from '@supabase/supabase-js';
import type { Database } from '../types';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  throw new Error('Missing Supabase environment variables');
}

// Secure storage implementation with better error handling
const secureStorage = {
  getItem: (key: string): string | null => {
    try {
      // Try sessionStorage first
      const sessionValue = sessionStorage.getItem(key);
      if (sessionValue) return sessionValue;

      // Fallback to localStorage if needed
      const localValue = localStorage.getItem(key);
      if (localValue) {
        // Move to sessionStorage for better security
        sessionStorage.setItem(key, localValue);
        localStorage.removeItem(key);
        return localValue;
      }

      return null;
    } catch (error) {
      console.debug('Error reading from storage:', error);
      return null;
    }
  },
  setItem: (key: string, value: string): void => {
    try {
      sessionStorage.setItem(key, value);
    } catch (error) {
      console.error('Error writing to storage:', error);
    }
  },
  removeItem: (key: string): void => {
    try {
      sessionStorage.removeItem(key);
      localStorage.removeItem(key); // Clean up any old values
    } catch (error) {
      console.error('Error removing from storage:', error);
    }
  },
  clear: (): void => {
    try {
      sessionStorage.clear();
      localStorage.clear();
    } catch (error) {
      console.error('Error clearing storage:', error);
    }
  }
};

// Initialize auth state
let authInitialized = false;
let authInitPromise: Promise<void> | null = null;

// Function to handle auth errors
async function handleAuthError(error: any): Promise<void> {
  if (error?.message?.includes('refresh_token_not_found') || 
      error?.message?.includes('Invalid Refresh Token')) {
    // Clear all auth state and storage
    secureStorage.clear();
    
    // Force sign out
    try {
      await supabase.auth.signOut({ scope: 'global' });
    } catch (signOutError) {
      console.debug('Error during force sign out:', signOutError);
    }

    // Reset auth state
    authInitialized = false;
    authInitPromise = null;

    // Reload the page to reset the app state
    window.location.reload();
  }
}

// Function to initialize auth state with better error handling
async function initializeAuth(): Promise<void> {
  if (authInitialized) return;
  if (authInitPromise) return authInitPromise;

  authInitPromise = (async () => {
    try {
      // First try to recover any existing session
      const existingSession = secureStorage.getItem('supabase.auth.token');
      if (existingSession) {
        try {
          const parsedSession = JSON.parse(existingSession);
          if (parsedSession?.access_token && parsedSession?.refresh_token) {
            await supabase.auth.setSession({
              access_token: parsedSession.access_token,
              refresh_token: parsedSession.refresh_token
            });
          }
        } catch (error) {
          console.debug('Failed to restore session:', error);
          secureStorage.removeItem('supabase.auth.token');
        }
      }

      // Then get current session state
      const { data: { session }, error } = await supabase.auth.getSession();
      if (error) throw error;

      // Set up auth state change listener
      const { data: { subscription } } = supabase.auth.onAuthStateChange(
        async (event, session) => {
          if (event === 'SIGNED_OUT' || event === 'USER_DELETED') {
            secureStorage.clear();
          } else if (event === 'TOKEN_REFRESHED' && !session) {
            // Handle failed token refresh
            await handleAuthError(new Error('refresh_token_not_found'));
          }
        }
      );

      authInitialized = true;
    } catch (error) {
      console.error('Error initializing auth:', error);
      await handleAuthError(error);
      throw error;
    } finally {
      authInitPromise = null;
    }
  })();

  return authInitPromise;
}

// Enhanced Supabase client with better error handling
export const supabase = createClient<Database>(supabaseUrl, supabaseKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
    flowType: 'pkce',
    storage: secureStorage,
    debug: import.meta.env.DEV,
    onAuthStateChange: (event, session) => {
      if (event === 'SIGNED_OUT' || event === 'USER_DELETED') {
        secureStorage.clear();
      }
    }
  },
  global: {
    headers: {
      'x-application-name': 'minimee',
      'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
      'X-Frame-Options': 'DENY',
      'X-Content-Type-Options': 'nosniff',
      'Referrer-Policy': 'strict-origin-when-cross-origin'
    }
  }
});

// Add error interceptor
const originalAuthRequest = supabase.auth.api;
if (originalAuthRequest) {
  const handler = {
    get: function(target: any, property: string) {
      const original = target[property];
      if (typeof original === 'function') {
        return async function(...args: any[]) {
          try {
            const result = await original.apply(target, args);
            if (result.error) {
              await handleAuthError(result.error);
            }
            return result;
          } catch (error) {
            await handleAuthError(error);
            throw error;
          }
        };
      }
      return original;
    }
  };
  supabase.auth.api = new Proxy(originalAuthRequest, handler);
}

export { initializeAuth, handleAuthError };

// Helper function for exponential backoff with jitter
function getRetryDelay(attempt: number): number {
  const exponentialDelay = Math.min(
    INITIAL_RETRY_DELAY * Math.pow(2, attempt),
    MAX_RETRY_DELAY
  );
  const jitter = Math.random() * JITTER_MAX;
  return exponentialDelay + jitter;
}

// Enhanced retry wrapper with better error handling
async function withRetry<T>(
  operation: () => Promise<T>,
  retries = MAX_RETRIES,
  context = 'operation'
): Promise<T> {
  let lastError: Error | null = null;
  
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const result = await operation();
      if (attempt > 0) {
        console.debug(`Successfully completed ${context} after ${attempt} retries`);
      }
      return result;
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));
      
      if (attempt === retries) {
        console.error(`Failed ${context} after ${retries} retries:`, lastError);
        throw lastError;
      }

      const delay = getRetryDelay(attempt);
      console.debug(`Retry attempt ${attempt + 1}/${retries} for ${context} after ${delay}ms`);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }

  throw lastError || new Error(`Retry failed for ${context}`);
}

// Helper to check if the connection is working with enhanced retry
export async function checkSupabaseConnection(): Promise<boolean> {
  try {
    await initializeAuth();
    
    const { error } = await withRetry(
      () => supabase.from('profiles').select('id').limit(1).maybeSingle(),
      3,
      'connection check'
    );

    return !error;
  } catch (error) {
    console.error('Supabase connection error:', error);
    return false;
  }
}

// Helper to ensure user is authenticated with retry
export async function ensureAuthenticated() {
  try {
    await initializeAuth();

    const { data: { session }, error } = await withRetry(
      () => supabase.auth.getSession(),
      3,
      'auth check'
    );
    
    if (error) throw error;
    if (!session) throw new Error('No authenticated session');
    return session;
  } catch (error) {
    throw new Error('Authentication required');
  }
}

// Function to ensure user setup is complete with enhanced reliability
export async function ensureUserSetup(userId: string, email: string): Promise<void> {
  try {
    // First, ensure profile exists with retry
    const { error: profileError } = await withRetry(
      () => supabase
        .from('profiles')
        .upsert({
          id: userId,
          email,
          created_at: new Date().toISOString(),
          last_login: new Date().toISOString()
        }, {
          onConflict: 'id'
        }),
      3,
      'profile setup'
    );

    if (profileError) throw profileError;

    // Then ensure user stats exist with retry
    const { error: statsError } = await withRetry(
      () => supabase
        .from('user_stats')
        .upsert({
          user_id: userId,
          total_entries: 0,
          longest_streak: 0,
          current_streak: 0,
          total_words: 0,
          total_points: 0,
          current_level: 1,
          entries_this_week: 0,
          entries_this_month: 0,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }, {
          onConflict: 'user_id'
        }),
      3,
      'stats setup'
    );

    if (statsError) throw statsError;
  } catch (error) {
    console.error('Error ensuring user setup:', error);
    throw error;
  }
}

// Enhanced query wrapper with proper error handling and retry
export async function supabaseQuery<T>(
  operation: () => Promise<{ data: T | null; error: any }>,
  context = 'database query'
): Promise<T> {
  try {
    await initializeAuth();
    
    const { data, error } = await withRetry(
      operation,
      3,
      context
    );
    
    if (error) {
      throw handleSupabaseError(error);
    }
    
    if (data === null) {
      throw new Error('No data returned from query');
    }
    
    return data;
  } catch (error) {
    throw handleSupabaseError(error);
  }
}

// Enhanced error handler with better error classification
function handleSupabaseError(error: unknown): Error {
  if (error instanceof Error) {
    return error;
  }
  
  if (typeof error === 'object' && error !== null) {
    const supabaseError = error as { 
      message?: string; 
      details?: string; 
      hint?: string; 
      statusCode?: number;
      code?: string;
    };
    
    // Enhanced error classification
    if (supabaseError.statusCode === 401) {
      return new Error('Authentication required. Please sign in again.');
    }
    
    if (supabaseError.statusCode === 429) {
      return new Error('Too many requests. Please try again in a moment.');
    }
    
    if (supabaseError.statusCode === 503 || supabaseError.statusCode === 504) {
      return new Error('Service temporarily unavailable. Please try again later.');
    }

    if (supabaseError.code === '23505') { // Unique violation
      return new Error('This record already exists.');
    }

    if (supabaseError.code === '23503') { // Foreign key violation
      return new Error('Referenced record does not exist.');
    }

    return new Error(
      supabaseError.message || 
      supabaseError.details || 
      'An unexpected database error occurred'
    );
  }

  return new Error('An unexpected error occurred');
}