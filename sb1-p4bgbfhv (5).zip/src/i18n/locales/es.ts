export default {
  common: {
    loading: 'Cargando...',
    error: 'Ocurrió un error',
    retry: 'Reintentar',
    save: 'Guardar',
    cancel: 'Cancelar',
    submit: 'Enviar',
    next: 'Siguiente',
    back: 'Atrás',
    close: 'Cerrar',
    processing: 'Procesando...',
    completing: 'Completando...'
  },
  guide: {
    title: 'El Poder de MiniMee',
    previous: 'Anterior',
    next: 'Siguiente',
    getStarted: 'Comenzar',
    steps: {
      smartJournaling: {
        title: 'Diario Inteligente',
        description: 'Experimenta un diario potenciado por IA que se adapta a tu viaje único. Obtén perspectivas personalizadas y sugerencias que evolucionan contigo.'
      },
      aiCompanion: {
        title: 'Compañero IA',
        description: 'Participa en conversaciones significativas con tu compañero IA. Obtén apoyo, perspectivas y orientación cuando lo necesites.'
      },
      progress: {
        title: 'Sigue Tu Progreso',
        description: 'Observa cómo se desarrolla tu viaje con logros, rachas e indicadores de crecimiento personal.'
      },
      insights: {
        title: 'Resúmenes Semanales',
        description: 'Obtén una comprensión más profunda de tus patrones y crecimiento con resúmenes y análisis semanales impulsados por IA.'
      }
    }
  },
  welcome: {
    hero: {
      title: "Hola, Soy",
      subtitle: "Tu Diario Inteligente con IA",
      description: "Todos sabemos que escribir un diario es bueno para nosotros, pero seamos sinceros: mirar una página en blanco puede sentirse como una tarea tediosa. MiniMee cambia eso haciendo que la autorreflexión sea interesante y perspicaz. Nuestro compañero de IA te guía con sugerencias personalizadas, descubre patrones significativos en tus pensamientos y te ayuda a crecer a través de la reflexión interactiva. Es como tener un amigo reflexivo que siempre sabe las preguntas correctas para hacer.",
      cta: "Transforma tus reflexiones diarias en perspectivas significativas con un diario mejorado por IA que hace que el autodescubrimiento sea interesante y gratificante."
    },
    stats: {
      title: "Revolución del Diario Inteligente",
      clarity: {
        value: "83%",
        text: "de los usuarios reportan ideas más profundas a través de la reflexión potenciada por IA en comparación con el diario tradicional"
      },
      awareness: {
        value: "92%",
        text: "experimentan mayor conciencia emocional con perspectivas personalizadas de IA"
      },
      growth: {
        value: "76%",
        text: "logran mejor crecimiento personal a través del reconocimiento inteligente de patrones y sugerencias adaptativas"
      }
    },
    features: {
      title: "La Diferencia MiniMee",
      reflection: {
        title: "Reflexión Inteligente",
        description: "Nuestra IA analiza tus entradas para proporcionar perspectivas más profundas y sugerencias personalizadas que evolucionan con tu viaje"
      },
      growth: {
        title: "Reconocimiento de Patrones",
        description: "IA avanzada identifica patrones emocionales y oportunidades de crecimiento únicas para tu narrativa personal"
      },
      dialogue: {
        title: "Conversaciones Dinámicas",
        description: "Participa en diálogos significativos con un compañero IA que recuerda tu contexto y viaje de crecimiento"
      }
    },
    privacy: {
      title: 'Tu Privacidad, Tu Control',
      description: 'MiniMee nunca solicita información personal ni información médica protegida. Comparte tanto o tan poco como desees - tu compañero está aquí para escuchar y aprender de tu viaje mientras mantiene tu privacidad sagrada.',
      features: {
        security: {
          title: 'Privacidad Completa',
          description: 'Nunca recopilamos información personal ni información médica protegida. Tus entradas están encriptadas y almacenadas de forma segura.'
        },
        growth: {
          title: 'Comparte en Tus Términos',
          description: 'Tú controlas lo que compartes. Concéntrate en tu viaje interior sin presión por revelar detalles personales.'
        },
        conversations: {
          title: 'Espacio Seguro',
          description: 'Exprésate libremente sabiendo que tu compañero AI aprende de tu viaje sin almacenar información personal ni datos médicos.'
        }
      }
    },
    cta: {
      title: 'Listo para Comenzar tu Viaje',
      description: 'Únete a miles de personas que han descubierto el poder del diario consciente con MiniMee.',
      button: 'Comienza tu Viaje'
    },
    seeHowItWorks: 'Ver Cómo Funciona'
  },
  auth: {
    signIn: 'Iniciar Sesión',
    signUp: 'Registrarse',
    signOut: 'Cerrar Sesión',
    email: 'Correo electrónico',
    password: 'Contraseña',
    createAccount: 'Crear Cuenta',
    alreadyHaveAccount: '¿Ya tienes una cuenta? Inicia sesión',
    needAccount: '¿Necesitas una cuenta? Regístrate',
    form: {
      emailLabel: 'Correo electrónico',
      emailPlaceholder: 'Ingresa tu correo electrónico',
      passwordLabel: 'Contraseña',
      passwordPlaceholder: 'Ingresa tu contraseña',
      signUpDescription: 'Comienza tu viaje de diario hoy',
      signInDescription: 'Continúa tu viaje de autodescubrimiento',
      submitButton: {
        signIn: 'Iniciar Sesión',
        signUp: 'Crear Cuenta',
        processing: 'Procesando...'
      },
      verification: {
        title: 'Revisa tu Correo',
        description: 'Hemos enviado un enlace de verificación a',
        instruction: 'Por favor revisa tu bandeja de entrada y haz clic en el enlace para verificar tu correo electrónico.',
        resendButton: 'Reenviar correo de verificación',
        emailSent: '¡Correo de verificación enviado!',
        afterVerify: 'Después de verificar tu correo, por favor inicia sesión para continuar.'
      },
      invite: {
        title: 'Invita a tus Amigos',
        description: 'Comparte el regalo del diario consciente con tus amigos',
        shareButton: 'Compartir MiniMee',
        shareTitle: 'Únete a mí en MiniMee',
        shareText: 'He estado usando MiniMee para el diario consciente y la autorreflexión. ¡Únete a mí en este viaje de crecimiento personal!',
        copied: '¡Enlace Copiado!',
        copyLink: 'Copiar enlace de invitación:',
        copyButton: 'Copiar enlace',
        copyError: 'No se pudo copiar. Por favor, selecciona y copia el enlace manualmente.',
        shareError: 'No se pudo compartir directamente. Puedes copiar el enlace a continuación.'
      },
      resetPassword: {
        title: 'Restablecer Contraseña',
        description: 'Ingresa tu correo electrónico y te enviaremos instrucciones para restablecer tu contraseña.',
        submit: 'Enviar Instrucciones',
        emailSent: 'Instrucciones Enviadas',
        checkEmail: 'Por favor revisa tu correo en',
        backToLogin: 'Volver al Inicio de Sesión',
        forgotPassword: '¿Olvidaste tu contraseña?'
      }
    },
    verifyEmail: {
      title: 'Verifica tu Correo',
      message: 'Por favor revisa tu bandeja de entrada y haz clic en el enlace para verificar tu correo electrónico.',
      resend: 'Reenviar correo de verificación',
      sent: '¡Correo de verificación enviado!',
      afterVerify: 'Después de verificar tu correo, por favor inicia sesión para continuar.',
      error: 'Error al reenviar el correo de verificación'
    }
  },
  journal: {
    title: 'Tu Santuario Interior',
    subtitle: 'Un espacio sagrado para la autorreflexión y el crecimiento',
    startEntry: 'Comenzar Entrada de Diario',
    viewPastJournals: 'Ver Diarios Anteriores',
    returnToJournal: 'Volver al Diario',
    features: {
      reflection: {
        title: 'Reflexión Profunda',
        description: 'Descubre ideas a través de la autoexploración guiada'
      },
      growth: {
        title: 'Crecimiento Personal',
        description: 'Observa cómo tu autoconciencia se profundiza con el tiempo'
      },
      dialogue: {
        title: 'Diálogo Interior',
        description: 'Participa en conversaciones significativas contigo mismo'
      }
    },
    chat: {
      start: 'Iniciar una Conversación',
      description: 'Haz clic aquí para abrir el chat y explorar tus pensamientos'
    },
    privacy: {
      title: 'Tu Viaje, Tus Términos',
      description: 'MiniMee aprende a comprender tu camino único de autodescubrimiento sin nunca pedir información personal. Comparte lo que te parezca adecuado, y tu compañero se adaptará para proporcionar ideas significativas mientras mantiene tu privacidad sagrada.',
      insight: 'Tu privacidad siempre está protegida'
    },
    history: {
      title: 'Historial del Diario',
      empty: 'Aún no hay entradas en el diario. Comienza a escribir para iniciar tu viaje.',
      aiResponse: 'Reflexión de IA'
    },
    writePlaceholder: 'Escribe tus pensamientos aquí...',
    progress: 'Pregunta {{current}} de {{total}}',
    complete: 'Completar Diario',
    completing: 'Completando...',
    completed: {
      title: '¡Diario de Hoy Completado!',
      message: '¡Excelente trabajo completando tu diario hoy. ¡Tu racha ha sido actualizada!',
      returnTomorrow: 'Vuelve mañana para nuevas reflexiones',
      tip: 'Usa este tiempo para revisar tus entradas anteriores o chatear con MiniMee sobre tus pensamientos.'
    },
    completeError: 'Error al completar el diario',
    reflection: {
      title: 'Reflexión de MiniMee'
    },
    prompts: {
      smile: {
        question: "¿Qué te hizo sonreír hoy?",
        description: "Reflexiona sobre los momentos de alegría, sin importar cuán pequeños sean."
      },
      challenge: {
        question: "¿Qué desafío enfrentaste y cómo lo manejaste?",
        description: "Explora tu crecimiento a través de las dificultades."
      },
      future: {
        question: "¿Qué es algo que esperas con ansias?",
        description: "Conéctate con tus esperanzas y aspiraciones."
      },
      gratitude: {
        question: "¿Por qué cosa estás agradecido hoy?",
        description: "Practica la gratitud y la atención plena."
      },
      improvement: {
        question: "¿Qué te gustaría mejorar mañana?",
        description: "Establece intenciones para el crecimiento personal."
      }
    }
  },
  chat: {
    title: 'Chatea con MiniMee',
    subtitle: 'Tu compañero de crecimiento personal',
    welcome: "¡Hola! Soy MiniMee, tu compañero de crecimiento personal. Estoy aquí para escuchar y aprender de tu viaje, sin nunca pedir detalles personales. Comparte lo que te resulte cómodo. ¿Qué tienes en mente hoy?",
    placeholder: 'Escribe tu mensaje...',
    history: 'Historial de Chat',
    newChat: 'Iniciar Nuevo Chat',
    messages: '{{count}} mensaje',
    messages_plural: '{{count}} mensajes',
    noHistory: 'Aún No Hay Historial de Chat',
    startNewChat: "Inicia un nuevo chat para comenzar tu conversación con MiniMee",
    error: "Lo siento, pero estoy teniendo problemas para responder en este momento. Por favor, inténtalo de nuevo.",
    privacy: 'MiniMee nunca solicita información personal. Comparte lo que te parezca adecuado - tu compañero está aquí para escuchar y aprender.'
  },
  achievements: {
    title: 'Logros',
    categories: {
      milestones: 'Hitos',
      streaks: 'Rachas',
      writing: 'Escritura',
      habits: 'Hábitos'
    },
    points: '{{count}} pts',
    unlockedOn: 'Desbloqueado el {{date}}',
    firstEntry: {
      name: 'Primera Entrada',
      description: 'Completa tu primera entrada en el diario'
    },
    weeklyWarrior: {
      name: 'Guerrero Semanal',
      description: 'Completa entradas durante 7 días consecutivos'
    },
    monthlyMaster: {
      name: 'Maestro Mensual',
      description: 'Completa entradas durante 30 días consecutivos'
    },
    reflectionRookie: {
      name: 'Novato Reflexivo',
      description: 'Escribe 5 entradas en el diario'
    },
    journalingJourney: {
      name: 'Viaje de Diario',
      description: 'Escribe 20 entradas en el diario'
    },
    wordsmith: {
      name: 'Maestro de Palabras',
      description: 'Escribe más de 10,000 palabras'
    },
    earlyBird: {
      name: 'Madrugador',
      description: 'Completa 5 entradas antes de las 9 AM'
    },
    nightOwl: {
      name: 'Búho Nocturno',
      description: 'Completa 5 entradas después de las 9 PM'
    }
  },
  status: {
    levels: {
      novice: {
        title: 'Explorador Novato',
        description: 'Comenzando tu viaje de escritura'
      },
      consistent: {
        title: 'Escritor Constante',
        description: 'Construyendo hábitos saludables de escritura'
      },
      dedicated: {
        title: 'Periodista Dedicado',
        description: 'Haciendo del diario una práctica diaria'
      },
      master: {
        title: 'Maestro de la Reflexión',
        description: 'Dominando el arte de la autorreflexión'
      },
      keeper: {
        title: 'Guardián de la Sabiduría',
        description: 'Alcanzando la excelencia en el diario'
      }
    },
    streak: '{{count}} día de racha',
    streak_plural: '{{count}} días de racha',
    untilNext: '• {{days}} días hasta {{level}}',
    stats: {
      streak: 'Racha Actual',
      streakValue: '{{count}} día',
      streakValue_plural: '{{count}} días',
      entries: 'Total de Entradas',
      lastEntry: 'Última Entrada'
    },
    progress: {
      title: 'Progreso del Viaje',
      current: 'Actual',
      untilNext: '{{days}} días hasta {{level}}',
      streakRequired: '{{count}} día de racha requerido',
      streakRequired_plural: '{{count}} días de racha requeridos'
    },
    guide: {
      title: 'Niveles de Estado del Diario',
      openButton: 'Ver guía de estados',
      toggleButton: 'Alternar detalles de progreso',
      streakRequired: '{{count}} día de racha requerido',
      streakRequired_plural: '{{count}} días de racha requeridos'
    }
  },
  footer: {
    description: 'Tu compañero de confianza para el autodescubrimiento y el crecimiento personal a través del diario consciente.',
    copyright: '© {{year}} MiniMee. Todos los derechos reservados.',
    legal: {
      title: 'Legal',
      privacy: 'Política de Privacidad',
      terms: 'Términos de Uso'
    },
    security: {
      title: 'Seguridad',
      description: 'Tus datos están encriptados y almacenados de forma segura. Nunca compartimos tu información personal.'
    },
    privacy: {
      title: 'Tu Privacidad es Importante',
      description: 'Nos tomamos en serio tu privacidad y estamos comprometidos a proteger tu información personal.',
      sections: {
        collection: {
          title: 'Información que Recopilamos',
          description: 'Solo recopilamos la información necesaria para brindarte la mejor experiencia de diario:',
          items: [
            'Tu correo electrónico para la gestión de la cuenta',
            'Tus entradas del diario e interacciones con MiniMee',
            'Datos de uso para mejorar nuestro servicio'
          ]
        },
        usage: {
          title: 'Cómo Usamos tu Información',
          description: 'Tu información se utiliza exclusivamente para:',
          items: [
            'Proporcionar experiencias de diario personalizadas',
            'Mejorar las respuestas de nuestro compañero AI',
            'Mantener y asegurar tu cuenta'
          ]
        },
        security: {
          title: 'Seguridad de Datos',
          description: 'Empleamos medidas de seguridad y encriptación estándar de la industria para proteger tus datos. Tus entradas del diario son privadas y solo accesibles para ti.'
        },
        rights: {
          title: 'Tus Derechos',
          description: 'Tienes derecho a:',
          items: [
            'Acceder a tus datos personales',
            'Solicitar la eliminación de datos',
            'Exportar tus entradas del diario',
            'Optar por no participar en la recopilación de datos no esencial'
          ]
        }
      }
    },
    terms: {
      title: 'Términos de Uso',
      sections: {
        acceptance: {
          title: 'Aceptación de Términos',
          description: 'Al usar MiniMee, aceptas estos términos y condiciones. Por favor, léelos cuidadosamente antes de usar nuestro servicio.'
        },
        responsibilities: {
          title: 'Responsabilidades del Usuario',
          description: 'Eres responsable de:',
          items: [
            'Mantener la confidencialidad de tu cuenta',
            'Todas las actividades que ocurran bajo tu cuenta',
            'Asegurar que tu contenido no viole ninguna ley'
          ]
        },
        service: {
          title: 'Uso del Servicio',
          description: 'MiniMee se proporciona "tal cual" y puede ser actualizado o modificado con el tiempo. Nos reservamos el derecho de suspender cuentas que violen nuestros términos.'
        },
        intellectual: {
          title: 'Propiedad Intelectual',
          description: 'Conservas los derechos de tus entradas del diario. El contenido y las funciones de MiniMee están protegidos por derechos de autor y otras leyes de propiedad intelectual.'
        },
        liability: {
          title: 'Limitación de Responsabilidad',
          description: 'MiniMee no es responsable por ningún daño indirecto, incidental o consecuente que surja del uso del servicio.'
        }
      }
    },
    faq: {
      title: 'Preguntas Frecuentes',
      data: {
        title: '¿Cómo se utilizan mis datos?',
        description: 'Tu privacidad es nuestra máxima prioridad. Nunca compartimos, vendemos ni proporcionamos tus datos a terceros por ningún motivo. Tus entradas de diario e información personal están encriptadas y almacenadas de forma segura, accesibles solo para ti.'
      },
      app: {
        title: '¿Existe una aplicación para iOS?',
        description: '¡Estamos desarrollando activamente una aplicación nativa para iOS para proporcionar una experiencia de diario aún mejor en dispositivos móviles. ¡Mantente atento a las actualizaciones sobre su lanzamiento!'
      },
      language: {
        title: '¿Qué idiomas están disponibles?',
        description: 'MiniMee está completamente disponible tanto en inglés como en español, ofreciendo funcionalidad completa en ambos idiomas. Nuestro compañero de IA se adapta perfectamente a tu idioma preferido para una experiencia de diario natural.'
      },
      benefits: {
        title: '¿Por qué debería escribir un diario con MiniMee?',
        intro: 'Escribir un diario regularmente con MiniMee ofrece numerosos beneficios científicamente probados:',
        items: [
          'Reduce el estrés y la ansiedad a través de la reflexión consciente',
          'Mejora la inteligencia emocional y el autoconocimiento',
          'Potencia la capacidad de resolución de problemas mediante el pensamiento estructurado',
          'Aumenta la creatividad y la claridad mental',
          'Realiza un seguimiento del crecimiento y progreso personal a lo largo del tiempo'
        ],
        conclusion: 'Nuestro compañero impulsado por IA proporciona perspectivas y sugerencias personalizadas, haciendo que tu práctica de diario sea más atractiva y significativa.'
      }
    }
  },
  weekSummary: {
    title: 'Tu Semana en Resumen',
    subtitle: 'Perspectivas impulsadas por IA de tu viaje de diario',
    loading: 'Generando tus perspectivas semanales...',
    empty: {
      title: 'Comienza Tu Viaje',
      description: 'Comienza tu viaje de diario esta semana. Estoy aquí para guiarte a través de una reflexión significativa.'
    },
    error: {
      title: 'No se pudo generar el resumen',
      description: 'Error al generar el resumen. Por favor, inténtalo de nuevo más tarde.',
      retry: 'Reintentar'
    },
    insights: {
      title: 'Perspectivas de IA',
      description: 'Aquí están los temas y patrones clave de tu semana:'
    }
  }
};