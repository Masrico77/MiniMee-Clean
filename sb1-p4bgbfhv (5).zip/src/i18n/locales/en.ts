import React from 'react';

export default {
  common: {
    loading: 'Loading...',
    error: 'An error occurred',
    retry: 'Retry',
    save: 'Save',
    cancel: 'Cancel',
    submit: 'Submit',
    next: 'Next',
    back: 'Back',
    close: 'Close',
    processing: 'Processing...',
    completing: 'Completing...'
  },
  guide: {
    title: 'The Power of MiniMee',
    previous: 'Previous',
    next: 'Next',
    getStarted: 'Get Started',
    steps: {
      smartJournaling: {
        title: 'Smart Journaling',
        description: 'Experience AI-powered journaling that adapts to your unique journey. Get personalized insights and prompts that evolve with you.'
      },
      aiCompanion: {
        title: 'AI Companion',
        description: 'Engage in meaningful conversations with your AI companion. Get support, insights, and guidance whenever you need it.'
      },
      progress: {
        title: 'Track Your Progress',
        description: 'Watch your journey unfold with achievements, streaks, and personal growth indicators.'
      },
      insights: {
        title: 'Weekly Insights',
        description: 'Gain deeper understanding of your patterns and growth with AI-powered weekly summaries and analysis.'
      }
    }
  },
  auth: {
    signIn: 'Sign In',
    signUp: 'Sign Up',
    signOut: 'Sign Out',
    email: 'Email',
    password: 'Password',
    createAccount: 'Create Account',
    alreadyHaveAccount: 'Already have an account? Sign in',
    needAccount: 'Need an account? Sign up',
    form: {
      emailLabel: 'Email',
      emailPlaceholder: 'Enter your email',
      passwordLabel: 'Password',
      passwordPlaceholder: 'Enter your password',
      signUpDescription: 'Start your journaling journey today',
      signInDescription: 'Continue your journey of self-discovery',
      submitButton: {
        signIn: 'Sign In',
        signUp: 'Create Account',
        processing: 'Processing...'
      },
      resetPassword: {
        title: 'Reset Your Password',
        description: 'Enter your email and we will send you instructions to reset your password.',
        submit: 'Send Reset Instructions',
        emailSent: 'Reset Instructions Sent',
        checkEmail: 'Please check your email at',
        backToLogin: 'Back to Login',
        forgotPassword: 'Forgot your password?'
      },
      verification: {
        title: 'Check Your Email',
        description: "We've sent a verification link to",
        instruction: 'Please check your inbox and click the link to verify your email address.',
        resendButton: 'Resend verification email',
        emailSent: 'Verification email sent!',
        afterVerify: 'After verifying your email, please sign in to continue.'
      },
      invite: {
        title: 'Invite Friends to Join',
        description: 'Share the gift of mindful journaling with your friends',
        shareButton: 'Share MiniMee',
        shareTitle: 'Join me on MiniMee',
        shareText: "I've been using MiniMee for mindful journaling and self-reflection. Join me on this journey of personal growth!",
        copied: 'Link Copied!',
        copyLink: 'Copy invitation link:',
        copyButton: 'Copy link',
        copyError: 'Unable to copy. Please select and copy the link manually.',
        shareError: 'Unable to share directly. You can copy the link below.'
      }
    },
    verifyEmail: {
      title: 'Verify Your Email',
      message: 'Please check your inbox and click the link to verify your email address.',
      resend: 'Resend verification email',
      sent: 'Verification email sent!',
      afterVerify: 'After verifying your email, please sign in to continue.',
      error: 'Failed to resend verification email'
    }
  },
  welcome: {
    hero: {
      title: "Experience",
      subtitle: "AI-Powered Smart Journaling",
      description: "Tired of staring at empty pages?\nMeet MiniMee – the smart AI journal that turns self-reflection into an engaging adventure. With tailored prompts and insightful analysis, MiniMee helps you discover yourself in ways traditional journals can't. Perfect for the digitally savvy seeking meaningful growth.",
      cta: "Join the future of personal growth with AI-enhanced journaling that adapts to your unique journey."
    },
    stats: {
      title: "Smart Journaling Revolution",
      clarity: {
        value: "83%",
        text: "of users report deeper insights through AI-powered reflection compared to traditional journaling"
      },
      awareness: {
        value: "92%",
        text: "experience enhanced emotional awareness with personalized AI insights"
      },
      growth: {
        value: "76%",
        text: "achieve better personal growth through intelligent pattern recognition and adaptive prompts"
      }
    },
    features: {
      title: "The MiniMee Difference",
      reflection: {
        title: "Intelligent Reflection",
        description: "Our AI analyzes your entries to provide deeper insights and personalized prompts that evolve with your journey"
      },
      growth: {
        title: "Pattern Recognition",
        description: "Advanced AI identifies emotional patterns and growth opportunities unique to your personal narrative"
      },
      dialogue: {
        title: "Dynamic Conversations",
        description: "Engage in meaningful dialogue with an AI companion that remembers your context and growth journey"
      }
    },
    privacy: {
      title: 'Your Privacy, Your Control',
      description: 'MiniMee never asks for personal information or protected health information. Share as much or as little as you want - your companion is here to listen and learn from your journey while keeping your privacy sacred.',
      features: {
        security: {
          title: 'Complete Privacy',
          description: 'We never collect personal information or protected health information. Your entries are encrypted and securely stored.'
        },
        growth: {
          title: 'Share on Your Terms',
          description: 'You control what you share. Focus on your inner journey with no pressure to reveal personal details.'
        },
        conversations: {
          title: 'Safe Space',
          description: 'Express yourself freely knowing your AI companion learns from your journey without storing personal information or health data.'
        }
      }
    },
    cta: {
      title: 'Ready to Begin Your Journey?',
      description: 'Join thousands of others who have discovered the power of mindful journaling with MiniMee.',
      button: 'Start Your Journey'
    },
    seeHowItWorks: 'See How It Works'
  },
  journal: {
    title: 'Your Inner Sanctuary',
    subtitle: 'A sacred space for self-reflection and growth',
    startEntry: 'Start Journal Entry',
    viewPastJournals: 'View Past Journals',
    returnToJournal: 'Return to Journal',
    features: {
      reflection: {
        title: 'Deep Reflection',
        description: 'Discover insights through guided self-exploration'
      },
      growth: {
        title: 'Personal Growth',
        description: 'Watch your self-awareness deepen with time'
      },
      dialogue: {
        title: 'Inner Dialogue',
        description: 'Engage in meaningful conversations with yourself'
      }
    },
    chat: {
      start: 'Start a Conversation',
      description: 'Click here to open chat and explore your thoughts'
    },
    privacy: {
      title: 'Your Journey, Your Terms',
      description: 'MiniMee learns to understand your unique path of self-discovery without ever asking for personal information. Share what feels right for you, and your companion will adapt to provide meaningful insights while keeping your privacy sacred.',
      insight: 'Your privacy is always protected'
    },
    history: {
      title: 'Journal History',
      empty: 'No journal entries yet. Start writing to begin your journey.',
      aiResponse: 'AI Reflection'
    },
    writePlaceholder: 'Write your thoughts here...',
    progress: 'Question {{current}} of {{total}}',
    complete: 'Complete Journal',
    completing: 'Completing...',
    completed: {
      title: "Today's Journal Complete!",
      message: 'Great job on completing your journal for today. Your streak has been updated!',
      returnTomorrow: 'Come back tomorrow for new reflections',
      tip: 'Use this time to review your past entries or chat with MiniMee about your thoughts.'
    },
    completeError: 'Failed to complete journal',
    reflection: {
      title: "MiniMee's Reflection"
    },
    prompts: {
      smile: {
        question: "What made you smile today?",
        description: "Reflect on the moments of joy, no matter how small."
      },
      challenge: {
        question: "What's a challenge you faced, and how did you handle it?",
        description: "Explore your growth through difficulties."
      },
      future: {
        question: "What's something you're looking forward to?",
        description: "Connect with your hopes and aspirations."
      },
      gratitude: {
        question: "What's one thing you're grateful for today?",
        description: "Practice gratitude and mindfulness."
      },
      improvement: {
        question: "What would you like to improve about tomorrow?",
        description: "Set intentions for personal growth."
      }
    }
  },
  chat: {
    title: 'Chat with MiniMee',
    subtitle: 'Your personal growth companion',
    welcome: "Hi there! I'm MiniMee, your personal growth companion. I'm here to listen and learn from your journey, without ever asking for personal details. Share what feels comfortable for you. What's on your mind today?",
    placeholder: 'Type your message...',
    history: 'Chat History',
    newChat: 'Start New Chat',
    messages: '{{count}} message',
    messages_plural: '{{count}} messages',
    noHistory: 'No Chat History Yet',
    startNewChat: "Start a new chat to begin your conversation with MiniMee",
    error: "I apologize, but I'm having trouble responding right now. Please try again.",
    privacy: 'MiniMee never asks for personal information. Share what feels right for you - your companion is here to listen and learn.'
  },
  achievements: {
    title: 'Achievements',
    categories: {
      milestones: 'Milestones',
      streaks: 'Streaks',
      writing: 'Writing',
      habits: 'Habits'
    },
    points: '{{count}} pts',
    unlockedOn: 'Unlocked on {{date}}',
    firstEntry: {
      name: 'First Entry',
      description: 'Complete your first journal entry'
    },
    weeklyWarrior: {
      name: 'Weekly Warrior',
      description: 'Complete entries for 7 consecutive days'
    },
    monthlyMaster: {
      name: 'Monthly Master',
      description: 'Complete entries for 30 consecutive days'
    },
    reflectionRookie: {
      name: 'Reflection Rookie',
      description: 'Write 5 journal entries'
    },
    journalingJourney: {
      name: 'Journaling Journey',
      description: 'Write 20 journal entries'
    },
    wordsmith: {
      name: 'Wordsmith',
      description: 'Write over 10,000 words'
    },
    earlyBird: {
      name: 'Early Bird',
      description: 'Complete 5 entries before 9 AM'
    },
    nightOwl: {
      name: 'Night Owl',
      description: 'Complete 5 entries after 9 PM'
    }
  },
  status: {
    levels: {
      novice: {
        title: 'Novice Explorer',
        description: 'Beginning your journaling journey'
      },
      consistent: {
        title: 'Consistent Writer',
        description: 'Building healthy writing habits'
      },
      dedicated: {
        title: 'Dedicated Journalist',
        description: 'Making journaling a daily practice'
      },
      master: {
        title: 'Reflection Master',
        description: 'Mastering the art of self-reflection'
      },
      keeper: {
        title: 'Wisdom Keeper',
        description: 'Achieving journaling excellence'
      }
    },
    streak: '{{count}} day streak',
    streak_plural: '{{count}} days streak',
    untilNext: '• {{days}} days until {{level}}',
    stats: {
      streak: 'Current Streak',
      streakValue: '{{count}} day',
      streakValue_plural: '{{count}} days',
      entries: 'Total Entries',
      lastEntry: 'Last Entry'
    },
    progress: {
      title: 'Journey Progress',
      current: 'Current',
      untilNext: '{{days}} days until {{level}}',
      streakRequired: '{{count}} day streak required',
      streakRequired_plural: '{{count}} days streak required'
    },
    guide: {
      title: 'Journal Status Levels',
      openButton: 'View status guide',
      toggleButton: 'Toggle progress details',
      streakRequired: '{{count}} day streak required',
      streakRequired_plural: '{{count}} days streak required'
    }
  },
  footer: {
    description: 'Your trusted companion for self-discovery and personal growth through mindful journaling.',
    copyright: '© {{year}} MiniMee. All rights reserved.',
    legal: {
      title: 'Legal',
      privacy: 'Privacy Policy',
      terms: 'Terms of Use'
    },
    security: {
      title: 'Security',
      description: 'Your data is encrypted and securely stored. We never share your personal information.'
    },
    privacy: {
      title: 'Your Privacy Matters',
      description: 'We take your privacy seriously and are committed to protecting your personal information.',
      sections: {
        collection: {
          title: 'Information We Collect',
          description: 'We collect only the information necessary to provide you with the best journaling experience:',
          items: [
            'Your email address for account management',
            'Your journal entries and interactions with MiniMee',
            'Usage data to improve our service'
          ]
        },
        usage: {
          title: 'How We Use Your Information',
          description: 'Your information is used exclusively to:',
          items: [
            'Provide personalized journaling experiences',
            'Improve our AI companion\'s responses',
            'Maintain and secure your account'
          ]
        },
        security: {
          title: 'Data Security',
          description: 'We employ industry-standard encryption and security measures to protect your data. Your journal entries are private and only accessible to you.'
        },
        rights: {
          title: 'Your Rights',
          description: 'You have the right to:',
          items: [
            'Access your personal data',
            'Request data deletion',
            'Export your journal entries',
            'Opt-out of non-essential data collection'
          ]
        }
      }
    },
    terms: {
      title: 'Terms of Use',
      sections: {
        acceptance: {
          title: 'Acceptance of Terms',
          description: 'By using MiniMee, you agree to these terms and conditions. Please read them carefully before using our service.'
        },
        responsibilities: {
          title: 'User Responsibilities',
          description: 'You are responsible for:',
          items: [
            'Maintaining the confidentiality of your account',
            'All activities that occur under your account',
            'Ensuring your content doesn\'t violate any laws'
          ]
        },
        service: {
          title: 'Service Usage',
          description: 'MiniMee is provided "as is" and may be updated or modified over time. We reserve the right to suspend accounts that violate our terms.'
        },
        intellectual: {
          title: 'Intellectual Property',
          description: 'You retain rights to your journal entries. MiniMee\'s content and features are protected by copyright and other intellectual property laws.'
        },
        liability: {
          title: 'Limitation of Liability',
          description: 'MiniMee is not liable for any indirect, incidental, or consequential damages arising from your use of the service.'
        }
      }
    },
    faq: {
      title: 'Frequently Asked Questions',
      data: {
        title: 'How is my data used?',
        description: 'Your privacy is our top priority. We never share, sell, or provide your data to any third parties for any reason. Your journal entries and personal information are encrypted and securely stored, accessible only to you.'
      },
      app: {
        title: 'Is there an iOS app?',
        description: "We're actively developing a native iOS app to provide an even better journaling experience on mobile devices. Stay tuned for updates on its release!"
      },
      language: {
        title: 'What languages are supported?',
        description: 'MiniMee is fully available in both English and Spanish, offering complete functionality in both languages. Our AI companion seamlessly adapts to your preferred language for a natural journaling experience.'
      },
      benefits: {
        title: 'Why should I journal with MiniMee?',
        intro: 'Regular journaling with MiniMee offers numerous scientifically-proven benefits:',
        items: [
          'Reduces stress and anxiety through mindful reflection',
          'Improves emotional intelligence and self-awareness',
          'Enhances problem-solving abilities through structured thinking',
          'Boosts creativity and mental clarity',
          'Tracks personal growth and progress over time'
        ],
        conclusion: 'Our AI-powered companion provides personalized insights and prompts, making your journaling practice more engaging and meaningful.'
      }
    }
  },
  weekSummary: {
    title: 'Your Week in Review',
    subtitle: 'AI-powered insights from your journaling journey',
    loading: 'Generating your weekly insights...',
    empty: {
      title: 'Start Your Journey',
      description: "Start your journaling journey this week. I'm here to guide you through meaningful self-reflection."
    },
    error: {
      title: 'Unable to generate summary',
      description: 'Failed to generate summary. Please try again later.',
      retry: 'Retry'
    },
    insights: {
      title: 'AI Insights',
      description: 'Here are the key themes and patterns from your week:'
    }
  }
};