export interface JournalEntry {
  id: string;
  question: string;
  answer: string;
  aiResponse: string;
  date: string;
}

export interface JournalPrompt {
  id: number;
  question: string;
  description: string;
}

export interface Message {
  id?: string;
  role: 'user' | 'assistant';
  content: string;
  created_at?: string;
}

export interface ChatConversation {
  id: string;
  created_at: string;
  chat_messages: Message[];
}