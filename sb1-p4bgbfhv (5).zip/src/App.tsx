import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Book, Brain, Sparkles, MessageSquare, Shield, Lock, Loader, AlertCircle, CheckCircle, Calendar, BarChart, History } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { JournalModal } from './components/JournalModal';
import { JournalHistory } from './components/JournalHistory';
import { UserProgress } from './components/UserProgress';
import { WelcomeScreen } from './components/WelcomeScreen';
import { journalPrompts } from './config/prompts';
import { getJournalResponse } from './services/openai';
import { AuthForm } from './components/AuthForm';
import { signOut } from './services/auth';
import { supabase, checkSupabaseConnection, ensureUserSetup } from './lib/supabase';
import { saveJournalEntry, getJournalHistory, getJournalStats, canSubmitJournalToday, completeJournal } from './services/journal';
import { AIChatModal } from './components/AIChatModal';
import { ChatButton } from './components/ChatButton';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { WeeklySummary } from './components/WeeklySummary';
import type { User } from '@supabase/supabase-js';

function App() {
  const { t } = useTranslation();
  const [user, setUser] = useState<User | null>(null);
  const [showHistory, setShowHistory] = useState(false);
  const [journalEntries, setJournalEntries] = useState([]);
  const [currentPromptIndex, setCurrentPromptIndex] = useState(0);
  const [aiResponse, setAiResponse] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [stats, setStats] = useState({
    totalEntries: 0,
    currentStreak: 0,
    lastEntryDate: null
  });
  const [showChat, setShowChat] = useState(false);
  const [isInitializing, setIsInitializing] = useState(true);
  const [canSubmitToday, setCanSubmitToday] = useState(true);
  const [showJournalModal, setShowJournalModal] = useState(false);
  const [isCompleting, setIsCompleting] = useState(false);
  const [showWeeklySummary, setShowWeeklySummary] = useState(false);

  useEffect(() => {
    async function initializeApp() {
      try {
        const isConnected = await checkSupabaseConnection();
        if (!isConnected) {
          setError('Unable to connect to the database. Please try again later.');
          setIsInitializing(false);
          return;
        }

        const { data: { session } } = await supabase.auth.getSession();
        if (session?.user) {
          // Ensure user setup is complete before setting the user
          await ensureUserSetup(session.user.id, session.user.email || '');
        }
        setUser(session?.user ?? null);

        const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_event, session) => {
          if (session?.user) {
            // Ensure user setup on auth state change
            await ensureUserSetup(session.user.id, session.user.email || '');
          }
          setUser(session?.user ?? null);
        });

        setIsInitializing(false);
        return () => subscription.unsubscribe();
      } catch (error) {
        console.error('Error initializing app:', error);
        setError('Failed to initialize the application');
        setIsInitializing(false);
      }
    }

    initializeApp();
  }, []);

  useEffect(() => {
    if (user) {
      loadUserData();
    } else {
      // Reset state when user logs out
      setJournalEntries([]);
      setStats({
        totalEntries: 0,
        currentStreak: 0,
        lastEntryDate: null
      });
      setShowHistory(false);
      setShowJournalModal(false);
      setShowChat(false);
      setCurrentPromptIndex(0);
      setAiResponse('');
    }
  }, [user]);

  const loadUserData = async () => {
    if (!user) return;
    
    setError('');
    try {
      const [entries, userStats, canSubmit] = await Promise.all([
        getJournalHistory(user.id),
        getJournalStats(user.id),
        canSubmitJournalToday(user.id)
      ]);
      setJournalEntries(entries);
      setStats(userStats);
      setCanSubmitToday(canSubmit);
    } catch (error) {
      console.error('Error loading user data:', error);
      setError('Failed to load your journal data. Please try refreshing the page.');
    }
  };

  const handleJournalSubmit = async (answer: string) => {
    if (!user) return;
    setIsLoading(true);
    setError('');

    try {
      const response = await getJournalResponse(journalPrompts[currentPromptIndex].question, answer, user.id);
      setAiResponse(response);
      await saveJournalEntry(user.id, journalPrompts[currentPromptIndex].question, answer, response);
      await loadUserData();
    } catch (error) {
      console.error('Error saving journal entry:', error);
      setError('Failed to save your journal entry');
    } finally {
      setIsLoading(false);
    }
  };

  const handleNextPrompt = () => {
    setCurrentPromptIndex((prev) => Math.min(prev + 1, journalPrompts.length - 1));
    setAiResponse('');
  };

  const handleJournalComplete = async () => {
    if (!user) return;
    setIsCompleting(true);
    try {
      await completeJournal(user.id);
      await loadUserData();
      setShowJournalModal(false);
      setCurrentPromptIndex(0);
      setAiResponse('');
    } catch (error) {
      console.error('Error completing journal:', error);
      setError('Failed to complete journal');
    } finally {
      setIsCompleting(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut();
    } catch (error) {
      console.error('Error signing out:', error);
      setError('Failed to sign out');
    }
  };

  const handleChatHistoryClick = () => {
    setShowChat(true);
    setShowHistory(true);
  };

  if (isInitializing) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-50 flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center"
        >
          <div className="flex items-center justify-center mb-4">
            <Loader className="w-8 h-8 text-indigo-600 animate-spin" />
          </div>
          <p className="text-gray-600">{t('common.loading')}</p>
        </motion.div>
      </div>
    );
  }

  if (error && !user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-50 flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-lg shadow-xl p-6 max-w-md w-full text-center"
        >
          <div className="flex justify-center mb-4">
            <div className="p-3 bg-red-100 rounded-full">
              <AlertCircle className="w-6 h-6 text-red-600" />
            </div>
          </div>
          <h2 className="text-xl font-semibold text-gray-900 mb-2">{t('common.error')}</h2>
          <p className="text-gray-600 mb-4">{error}</p>
          <button
            onClick={() => window.location.reload()}
            className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
          >
            {t('common.retry')}
          </button>
        </motion.div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-50">
        <Header user={null} />
        <main className="pt-20 pb-12 px-4">
          <WelcomeScreen />
          <AuthForm onSuccess={() => {}} />
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-50">
      <Header 
        user={user} 
        showHistory={showHistory} 
        onHistoryClick={() => setShowHistory(!showHistory)} 
        onSignOut={handleSignOut}
        onChatHistoryClick={handleChatHistoryClick}
      />

      <main className="pt-20 pb-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl mx-auto mb-12"
        >
          <div className="bg-white/90 backdrop-blur-lg rounded-2xl shadow-lg overflow-hidden">
            <div className="px-4 sm:px-8 py-6 border-b border-indigo-50">
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-6">
                <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-2xl flex items-center justify-center transform rotate-3">
                  <Book className="w-8 h-8 text-white" />
                </div>
                <div className="text-center sm:text-left">
                  <h1 className="text-2xl sm:text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-purple-600">
                    {t('journal.title')}
                  </h1>
                  <p className="text-gray-600 mt-1 text-sm sm:text-base">
                    {t('journal.subtitle')}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
                <div className="p-4 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="p-2 bg-indigo-100 rounded-lg">
                      <Brain className="w-4 h-4 text-indigo-600" />
                    </div>
                    <h3 className="font-medium text-gray-900">{t('journal.features.reflection.title')}</h3>
                  </div>
                  <p className="text-sm text-gray-600">
                    {t('journal.features.reflection.description')}
                  </p>
                </div>

                <div className="p-4 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="p-2 bg-indigo-100 rounded-lg">
                      <Sparkles className="w-4 h-4 text-indigo-600" />
                    </div>
                    <h3 className="font-medium text-gray-900">{t('journal.features.growth.title')}</h3>
                  </div>
                  <p className="text-sm text-gray-600">
                    {t('journal.features.growth.description')}
                  </p>
                </div>

                <div className="p-4 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="p-2 bg-indigo-100 rounded-lg">
                      <MessageSquare className="w-4 h-4 text-indigo-600" />
                    </div>
                    <h3 className="font-medium text-gray-900">{t('journal.features.dialogue.title')}</h3>
                  </div>
                  <p className="text-sm text-gray-600">
                    {t('journal.features.dialogue.description')}
                  </p>
                </div>
              </div>

              <div className="mt-6 flex flex-col sm:flex-row gap-4">
                <motion.button
                  onClick={() => setShowChat(true)}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full p-4 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-xl text-white shadow-lg hover:shadow-xl transition-all group"
                >
                  <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                    <div className="p-2 bg-white/10 rounded-lg group-hover:bg-white/20 transition-colors">
                      <Brain className="w-5 h-5" />
                    </div>
                    <div className="text-center sm:text-left">
                      <h3 className="font-semibold text-lg">{t('journal.chat.start')}</h3>
                      <p className="text-sm text-white/90">
                        {t('journal.chat.description')}
                      </p>
                    </div>
                  </div>
                </motion.button>

                <motion.button
                  onClick={() => setShowWeeklySummary(true)}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full p-4 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl text-white shadow-lg hover:shadow-xl transition-all group"
                >
                  <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                    <div className="p-2 bg-white/10 rounded-lg group-hover:bg-white/20 transition-colors">
                      <BarChart className="w-5 h-5" />
                    </div>
                    <div className="text-center sm:text-left">
                      <h3 className="font-semibold text-lg">{t('weekSummary.title')}</h3>
                      <p className="text-sm text-white/90">
                        {t('weekSummary.subtitle')}
                      </p>
                    </div>
                  </div>
                </motion.button>
              </div>
            </div>

            {user && !showHistory && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="px-4 sm:px-8 py-6 bg-gradient-to-r from-indigo-50 to-purple-50 border-t border-indigo-100"
              >
                <div className="flex flex-col sm:flex-row items-start gap-4">
                  <div className="p-2 bg-indigo-100 rounded-lg mt-1">
                    <Brain className="w-5 h-5 text-indigo-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      {t('journal.privacy.title')}
                    </h3>
                    <p className="text-gray-600 leading-relaxed">
                      {t('journal.privacy.description')}
                    </p>
                    <div className="flex items-center gap-2 mt-3 text-sm text-indigo-600">
                      <Sparkles className="w-4 h-4" />
                      <span>{t('journal.privacy.insight')}</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </div>
        </motion.div>

        {error && (
          <div className="max-w-2xl mx-auto mb-8 p-4 bg-red-50 border border-red-200 rounded-lg text-red-600">
            {error}
          </div>
        )}

        <AnimatePresence mode="wait">
          {showHistory ? (
            <motion.div
              key="history"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <JournalHistory 
                entries={journalEntries} 
                onBack={() => setShowHistory(false)}
              />
            </motion.div>
          ) : (
            <motion.div
              key="progress"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-8"
            >
              {!canSubmitToday ? (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="max-w-3xl mx-auto px-4 sm:px-0"
                >
                  <div className="bg-white/80 backdrop-blur-lg rounded-2xl shadow-xl p-6 sm:p-8 text-center">
                    <div className="flex items-center justify-center mb-4">
                      <div className="p-3 bg-green-100 rounded-full">
                        <CheckCircle className="w-6 h-6 sm:w-8 sm:h-8 text-green-600" />
                      </div>
                    </div>
                    <h2 className="text-xl sm:text-2xl font-bold text-gray-900 mb-2">
                      {t('journal.completed.title')}
                    </h2>
                    <p className="text-gray-600 mb-4">
                      {t('journal.completed.message')}
                    </p>
                    <div className="flex items-center justify-center gap-2 text-gray-500 mb-6">
                      <Calendar className="w-4 h-4" />
                      <span>{t('journal.completed.returnTomorrow')}</span>
                    </div>
                    <div className="p-4 bg-indigo-50 rounded-lg">
                      <p className="text-sm text-indigo-700">
                        {t('journal.completed.tip')}
                      </p>
                    </div>
                  </div>
                </motion.div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-4xl mx-auto px-4 sm:px-6">
                  <motion.button
                    onClick={() => setShowJournalModal(true)}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="relative group overflow-hidden"
                  >
                    <div className="bg-gradient-to-br from-indigo-500 via-indigo-600 to-purple-600 p-6 sm:p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all">
                      <div className="absolute inset-0 bg-white/5 transform -skew-y-12 group-hover:skew-y-12 transition-transform duration-700 ease-out" />
                      <div className="relative flex flex-col items-center text-white space-y-4">
                        <div className="p-3 bg-white/10 rounded-xl">
                          <Brain className="w-8 h-8" />
                        </div>
                        <div className="text-center">
                          <h3 className="text-xl sm:text-2xl font-bold mb-2">{t('journal.startEntry')}</h3>
                          <p className="text-white/80 text-sm sm:text-base">Begin your mindful reflection journey</p>
                        </div>
                      </div>
                    </div>
                  </motion.button>

                  <motion.button
                    onClick={() => setShowHistory(true)}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="relative group overflow-hidden"
                  >
                    <div className="bg-gradient-to-br from-purple-500 via-fuchsia-600 to-pink-600 p-6 sm:p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all">
                      <div className="absolute inset-0 bg-white/5 transform skew-y-12 group-hover:-skew-y-12 transition-transform duration-700 ease-out" />
                      <div className="relative flex flex-col items-center text-white space-y-4">
                        <div className="p-3 bg-white/10 rounded-xl">
                          <History className="w-8 h-8" />
                        </div>
                        <div className="text-center">
                          <h3 className="text-xl sm:text-2xl font-bold mb-2">{t('journal.viewPastJournals')}</h3>
                          <p className="text-white/80 text-sm sm:text-base">Explore your reflection journey</p>
                        </div>
                      </div>
                    </div>
                  </motion.button>
                </div>
              )}

              <UserProgress
                currentStreak={stats.currentStreak}
                totalEntries={stats.totalEntries}
                lastEntryDate={stats.lastEntryDate}
              />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Chat Button */}
        <div className="fixed bottom-0 left-0 right-0 z-50 p-4 sm:left-auto pointer-events-none">
          <div className="pointer-events-auto flex justify-center sm:justify-end">
            <ChatButton onClick={() => setShowChat(true)} />
          </div>
        </div>

        {/* Modals */}
        <JournalModal
          isOpen={showJournalModal}
          onClose={() => setShowJournalModal(false)}
          prompt={journalPrompts[currentPromptIndex]}
          onSubmit={handleJournalSubmit}
          aiResponse={aiResponse}
          isLoading={isLoading}
          currentPromptIndex={currentPromptIndex}
          totalPrompts={journalPrompts.length}
          onNextPrompt={handleNextPrompt}
          onComplete={handleJournalComplete}
          isCompleting={isCompleting}
        />

        <AIChatModal 
          isOpen={showChat} 
          onClose={() => setShowChat(false)} 
          userId={user.id} 
        />

        <WeeklySummary
          isOpen={showWeeklySummary}
          onClose={() => setShowWeeklySummary(false)}
          userId={user.id}
        />
      </main>
      <Footer />
    </div>
  );
}

export default App;