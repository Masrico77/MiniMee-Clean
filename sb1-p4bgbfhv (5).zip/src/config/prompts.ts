export const journalPrompts = [
  {
    id: 1,
    question: 'journal.prompts.smile.question',
    description: 'journal.prompts.smile.description'
  },
  {
    id: 2,
    question: 'journal.prompts.challenge.question',
    description: 'journal.prompts.challenge.description'
  },
  {
    id: 3,
    question: 'journal.prompts.future.question',
    description: 'journal.prompts.future.description'
  },
  {
    id: 4,
    question: 'journal.prompts.gratitude.question',
    description: 'journal.prompts.gratitude.description'
  },
  {
    id: 5,
    question: 'journal.prompts.improvement.question',
    description: 'journal.prompts.improvement.description'
  }
];