import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import * as Icons from 'lucide-react';
import { useTranslation } from 'react-i18next';
import type { IconProps } from 'lucide-react';

interface Props {
  currentStreak: number;
  totalEntries: number;
  lastEntryDate: string | null;
}

const statusLevels = [
  {
    titleKey: 'status.levels.novice.title',
    icon: 'Sparkles',
    minStreak: 0,
    color: 'gray',
    descriptionKey: 'status.levels.novice.description'
  },
  {
    titleKey: 'status.levels.consistent.title',
    icon: 'Pen',
    minStreak: 5,
    color: 'blue',
    descriptionKey: 'status.levels.consistent.description'
  },
  {
    titleKey: 'status.levels.dedicated.title',
    icon: 'BookOpen',
    minStreak: 10,
    color: 'green',
    descriptionKey: 'status.levels.dedicated.description'
  },
  {
    titleKey: 'status.levels.master.title',
    icon: 'Brain',
    minStreak: 15,
    color: 'purple',
    descriptionKey: 'status.levels.master.description'
  },
  {
    titleKey: 'status.levels.keeper.title',
    icon: 'Star',
    minStreak: 20,
    color: 'yellow',
    descriptionKey: 'status.levels.keeper.description'
  }
];

export const UserProgress: React.FC<Props> = ({ currentStreak, totalEntries, lastEntryDate }) => {
  const [showDetails, setShowDetails] = useState(false);
  const { t } = useTranslation();

  const getCurrentStatus = (streak: number) => {
    return [...statusLevels].reverse().find(level => streak >= level.minStreak) || statusLevels[0];
  };

  const currentStatus = getCurrentStatus(currentStreak);
  const nextStatus = statusLevels.find(level => level.minStreak > currentStreak);
  const Icon = (Icons as Record<string, React.FC<IconProps>>)[currentStatus.icon];

  const getColorClasses = (color: string) => {
    const colors = {
      gray: 'from-gray-500 to-gray-600',
      blue: 'from-blue-500 to-blue-600',
      green: 'from-green-500 to-green-600',
      purple: 'from-purple-500 to-purple-600',
      yellow: 'from-yellow-500 to-amber-600'
    };
    return colors[color as keyof typeof colors] || colors.gray;
  };

  const progressPercentage = nextStatus 
    ? ((currentStreak - currentStatus.minStreak) / (nextStatus.minStreak - currentStatus.minStreak)) * 100
    : 100;

  return (
    <div className="max-w-4xl mx-auto mb-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-2xl shadow-lg overflow-hidden"
      >
        <div className="p-6 border-b border-gray-100">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-4">
              <div className={`p-4 rounded-xl bg-gradient-to-br ${getColorClasses(currentStatus.color)}`}>
                <Icon className="w-8 h-8 text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-900">{t(currentStatus.titleKey)}</h2>
                <p className="text-gray-600">{t(currentStatus.descriptionKey)}</p>
              </div>
            </div>
            <button
              onClick={() => setShowDetails(!showDetails)}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              aria-label={t('status.guide.toggleButton')}
            >
              <Icons.ChevronDown
                className={`w-5 h-5 text-gray-500 transition-transform ${showDetails ? 'rotate-180' : ''}`}
              />
            </button>
          </div>

          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="p-4 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl">
              <div className="flex items-center gap-2 mb-1">
                <Icons.Flame className="w-4 h-4 text-orange-500" />
                <span className="text-sm font-medium text-gray-600">{t('status.stats.streak')}</span>
              </div>
              <p className="text-2xl font-bold text-gray-900">
                {t('status.stats.streakValue', { count: currentStreak })}
              </p>
            </div>
            <div className="p-4 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl">
              <div className="flex items-center gap-2 mb-1">
                <Icons.BookOpen className="w-4 h-4 text-indigo-500" />
                <span className="text-sm font-medium text-gray-600">{t('status.stats.entries')}</span>
              </div>
              <p className="text-2xl font-bold text-gray-900">{totalEntries}</p>
            </div>
            <div className="p-4 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl">
              <div className="flex items-center gap-2 mb-1">
                <Icons.Calendar className="w-4 h-4 text-purple-500" />
                <span className="text-sm font-medium text-gray-600">{t('status.stats.lastEntry')}</span>
              </div>
              <p className="text-lg font-bold text-gray-900">
                {lastEntryDate 
                  ? new Date(lastEntryDate).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })
                  : '-'}
              </p>
            </div>
          </div>

          {nextStatus && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">{t(currentStatus.titleKey)}</span>
                <span className="text-gray-600">{t(nextStatus.titleKey)}</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${progressPercentage}%` }}
                  transition={{ duration: 1, ease: "easeOut" }}
                  className={`h-full bg-gradient-to-r ${getColorClasses(currentStatus.color)}`}
                />
              </div>
              <p className="text-sm text-gray-500 text-center">
                {t('status.progress.untilNext', {
                  days: nextStatus.minStreak - currentStreak,
                  level: t(nextStatus.titleKey)
                })}
              </p>
            </div>
          )}
        </div>

        <AnimatePresence>
          {showDetails && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="overflow-hidden"
            >
              <div className="p-6 bg-gray-50">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">
                  {t('status.progress.title')}
                </h3>
                <div className="space-y-4">
                  {statusLevels.map((level) => {
                    const LevelIcon = (Icons as Record<string, React.FC<IconProps>>)[level.icon];
                    const isCurrentLevel = currentStatus.titleKey === level.titleKey;
                    const isUnlocked = currentStreak >= level.minStreak;

                    return (
                      <div
                        key={level.titleKey}
                        className={`p-4 rounded-xl transition-colors ${
                          isCurrentLevel ? 'bg-white shadow-md' : 'bg-white/50'
                        }`}
                      >
                        <div className="flex items-center gap-4">
                          <div
                            className={`p-3 rounded-lg ${
                              isUnlocked
                                ? `bg-gradient-to-br ${getColorClasses(level.color)}`
                                : 'bg-gray-200'
                            }`}
                          >
                            <LevelIcon className={`w-5 h-5 ${isUnlocked ? 'text-white' : 'text-gray-400'}`} />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <h4 className={`font-medium ${isUnlocked ? 'text-gray-900' : 'text-gray-500'}`}>
                                {t(level.titleKey)}
                              </h4>
                              {isCurrentLevel && (
                                <span className="px-2 py-1 text-xs font-medium text-indigo-600 bg-indigo-50 rounded-full">
                                  {t('status.progress.current')}
                                </span>
                              )}
                            </div>
                            <p className="text-sm text-gray-600">{t(level.descriptionKey)}</p>
                            <p className="text-sm text-gray-500 mt-1">
                              {t('status.progress.streakRequired', { count: level.minStreak })}
                            </p>
                          </div>
                          {isUnlocked && (
                            <Icons.CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
};