import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Loader, Sparkles, MessageSquare, AlertCircle, CheckCircle, ArrowRight, Calendar } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import type { JournalPrompt } from '../types';

interface Props {
  prompt: JournalPrompt;
  onSubmit: (answer: string) => Promise<void>;
  aiResponse: string;
  isLoading: boolean;
  userId: string;
  onNextPrompt: () => void;
  currentPromptIndex: number;
  totalPrompts: number;
  onJournalComplete: () => Promise<void>;
  canSubmitToday: boolean;
}

export const JournalEntry: React.FC<Props> = ({
  prompt,
  onSubmit,
  aiResponse,
  isLoading,
  userId,
  onNextPrompt,
  currentPromptIndex,
  totalPrompts,
  onJournalComplete,
  canSubmitToday
}) => {
  const { t } = useTranslation();
  const [answer, setAnswer] = useState('');
  const [error, setError] = useState('');
  const [isCompleting, setIsCompleting] = useState(false);
  const [journalCompleted, setJournalCompleted] = useState(false);
  const [showPrompt, setShowPrompt] = useState(true);
  const completionMessageRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setShowPrompt(true);
  }, [currentPromptIndex]);

  useEffect(() => {
    // When journal is completed, scroll the completion message into view
    if (journalCompleted && completionMessageRef.current) {
      completionMessageRef.current.scrollIntoView({ 
        behavior: 'smooth',
        block: 'center'
      });
    }
  }, [journalCompleted]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (answer.trim()) {
      try {
        await onSubmit(answer);
        setAnswer('');
        setError('');
        setShowPrompt(false);
      } catch (err) {
        setError(err instanceof Error ? err.message : t('common.error'));
      }
    }
  };

  const handleCompleteJournal = async () => {
    setIsCompleting(true);
    setError('');
    try {
      await completeJournal(userId);
      await onJournalComplete();
      setJournalCompleted(true);
    } catch (error) {
      console.error('Error completing journal:', error);
      setError(error instanceof Error ? error.message : t('journal.completeError'));
    } finally {
      setIsCompleting(false);
    }
  };

  if (!canSubmitToday || journalCompleted) {
    return (
      <motion.div
        ref={completionMessageRef}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-3xl mx-auto px-4 sm:px-0"
      >
        <div className="bg-white/80 backdrop-blur-lg rounded-2xl shadow-xl p-6 sm:p-8 text-center">
          <div className="flex items-center justify-center mb-4">
            <div className="p-3 bg-green-100 rounded-full">
              <CheckCircle className="w-6 h-6 sm:w-8 sm:h-8 text-green-600" />
            </div>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-gray-900 mb-2">
            {t('journal.completed.title')}
          </h2>
          <p className="text-gray-600 mb-4">
            {t('journal.completed.message')}
          </p>
          <div className="flex items-center justify-center gap-2 text-gray-500 mb-6">
            <Calendar className="w-4 h-4" />
            <span>{t('journal.completed.returnTomorrow')}</span>
          </div>
          <div className="p-4 bg-indigo-50 rounded-lg">
            <p className="text-sm text-indigo-700">
              {t('journal.completed.tip')}
            </p>
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-3xl mx-auto px-4 sm:px-0"
    >
      <AnimatePresence mode="wait">
        {showPrompt ? (
          <motion.div
            key="prompt"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="bg-white/80 backdrop-blur-lg rounded-2xl shadow-xl overflow-hidden"
          >
            <div className="px-4 sm:px-8 pt-6">
              <div className="flex items-center justify-between mb-4">
                <p className="text-sm text-gray-600">
                  {t('journal.progress', { current: currentPromptIndex + 1, total: totalPrompts })}
                </p>
                <div className="flex gap-1">
                  {Array.from({ length: totalPrompts }).map((_, index) => (
                    <div
                      key={index}
                      className={`h-1 w-4 sm:w-8 rounded-full ${
                        index < currentPromptIndex
                          ? 'bg-indigo-600'
                          : index === currentPromptIndex
                          ? 'bg-indigo-200'
                          : 'bg-gray-200'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>

            <div className="px-4 sm:px-8 pb-6 border-b border-gray-100">
              <div className="flex items-start sm:items-center gap-3 mb-4">
                <div className="p-2 bg-indigo-100 rounded-lg shrink-0">
                  <Sparkles className="w-5 h-5 text-indigo-600" />
                </div>
                <h2 className="text-lg sm:text-xl font-bold text-gray-800">{t(prompt.question)}</h2>
              </div>
              <p className="text-gray-600 leading-relaxed">{t(prompt.description)}</p>
            </div>

            {error && (
              <div className="px-4 sm:px-8 py-4 bg-red-50 border-b border-red-100">
                <div className="flex items-center gap-2 text-red-600">
                  <AlertCircle className="w-5 h-5" />
                  <p>{error}</p>
                </div>
              </div>
            )}

            <form onSubmit={handleSubmit} className="p-4 sm:p-8">
              <div className="relative">
                <textarea
                  value={answer}
                  onChange={(e) => setAnswer(e.target.value)}
                  className="w-full min-h-[200px] p-4 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200 bg-white/50 backdrop-blur-sm resize-none"
                  placeholder={t('journal.writePlaceholder')}
                  style={{ scrollbarWidth: 'thin' }}
                />
                <motion.button
                  type="submit"
                  disabled={isLoading || !answer.trim()}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="absolute bottom-4 right-4 flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-white bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
                >
                  {isLoading ? (
                    <>
                      <Loader className="w-4 h-4 animate-spin" />
                      {t('common.processing')}
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      {t('common.submit')}
                    </>
                  )}
                </motion.button>
              </div>
            </form>
          </motion.div>
        ) : (
          <motion.div
            key="reflection"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-2xl shadow-lg overflow-hidden"
          >
            <div className="px-4 sm:px-8 py-6">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-indigo-100 rounded-lg">
                    <MessageSquare className="w-5 h-5 text-indigo-600" />
                  </div>
                  <div>
                    <h3 className="text-lg sm:text-xl font-semibold text-indigo-900">
                      {t('journal.reflection.title')}
                    </h3>
                    <p className="text-sm text-indigo-600">
                      {t('journal.progress', { current: currentPromptIndex + 1, total: totalPrompts })}
                    </p>
                  </div>
                </div>
                {currentPromptIndex < totalPrompts - 1 ? (
                  <motion.button
                    onClick={onNextPrompt}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors"
                  >
                    {t('common.next')}
                    <ArrowRight className="w-4 h-4" />
                  </motion.button>
                ) : (
                  <motion.button
                    onClick={handleCompleteJournal}
                    disabled={isCompleting}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50"
                  >
                    {isCompleting ? (
                      <>
                        <Loader className="w-4 h-4 animate-spin" />
                        {t('journal.completing')}
                      </>
                    ) : (
                      <>
                        <CheckCircle className="w-4 h-4" />
                        {t('journal.complete')}
                      </>
                    )}
                  </motion.button>
                )}
              </div>
              <div className="prose prose-indigo max-w-none">
                <p className="text-gray-800 leading-relaxed whitespace-pre-wrap">{aiResponse}</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};