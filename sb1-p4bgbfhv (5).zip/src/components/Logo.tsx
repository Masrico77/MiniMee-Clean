import React from 'react';
import { motion } from 'framer-motion';
import { Brain } from 'lucide-react';

interface Props {
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export const Logo: React.FC<Props> = ({ size = 'md', className = '' }) => {
  const sizes = {
    sm: {
      container: 'w-6 h-6',
      icon: 'w-3 h-3',
      text: 'text-lg'
    },
    md: {
      container: 'w-8 h-8',
      icon: 'w-4 h-4',
      text: 'text-xl'
    },
    lg: {
      container: 'w-12 h-12',
      icon: 'w-6 h-6',
      text: 'text-3xl'
    }
  };

  const handleClick = () => {
    // If user is at the top of the page, no need to scroll
    if (window.scrollY === 0) return;

    // Smooth scroll to top
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  return (
    <motion.button
      onClick={handleClick}
      className={`flex items-center gap-2 ${className}`}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
    >
      <motion.div
        whileHover={{ rotate: [0, -10, 10, -10, 0] }}
        transition={{ duration: 0.5 }}
        className={`${sizes[size].container} rounded-xl bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center transform rotate-3`}
      >
        <Brain className={`${sizes[size].icon} text-white`} />
      </motion.div>
      <motion.h1 
        className={`${sizes[size].text} font-bold bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-purple-600`}
      >
        MiniMee
      </motion.h1>
    </motion.button>
  );
};