import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { LogIn, History, LogOut, Menu } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Logo } from './Logo';
import { LanguageToggle } from './LanguageToggle';
import type { User } from '@supabase/supabase-js';

interface Props {
  user: User | null;
  showHistory?: boolean;
  onHistoryClick?: () => void;
  onSignOut?: () => void;
}

export const Header: React.FC<Props> = ({ user, showHistory, onHistoryClick, onSignOut }) => {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const { t } = useTranslation();

  return (
    <header className="fixed top-0 left-0 right-0 z-40 bg-white/80 backdrop-blur-sm border-b border-indigo-100">
      <div className="max-w-7xl mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <Logo size="md" className="hidden sm:flex" />
            <Logo size="sm" className="flex sm:hidden" />
          </motion.div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-2">
            <LanguageToggle />
            {user ? (
              <>
                <button
                  onClick={onHistoryClick}
                  className="flex items-center px-3 py-1.5 text-sm text-gray-600 hover:text-gray-900 transition-colors"
                >
                  <History className="w-4 h-4 mr-2" />
                  {showHistory ? t('common.back') : t('journal.history.title')}
                </button>
                <button
                  onClick={onSignOut}
                  className="flex items-center px-3 py-1.5 text-sm text-gray-600 hover:text-gray-900 transition-colors"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  {t('auth.signOut')}
                </button>
              </>
            ) : (
              <motion.a
                href="#login"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="flex items-center px-4 py-2 rounded-lg text-sm font-medium text-white bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 transition-all duration-200"
              >
                <LogIn className="w-4 h-4 mr-2" />
                {t('auth.signIn')}
              </motion.a>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center gap-2">
            <LanguageToggle />
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
              aria-label="Toggle menu"
            >
              <Menu className="w-5 h-5 text-gray-600" />
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="md:hidden border-t border-gray-100 mt-3"
            >
              <div className="py-2 space-y-1">
                {user ? (
                  <>
                    <button
                      onClick={() => {
                        onHistoryClick?.();
                        setIsMenuOpen(false);
                      }}
                      className="w-full flex items-center px-4 py-2 text-sm text-gray-600 hover:bg-gray-50 transition-colors"
                    >
                      <History className="w-4 h-4 mr-2" />
                      {showHistory ? t('common.back') : t('journal.history.title')}
                    </button>
                    <button
                      onClick={() => {
                        onSignOut?.();
                        setIsMenuOpen(false);
                      }}
                      className="w-full flex items-center px-4 py-2 text-sm text-gray-600 hover:bg-gray-50 transition-colors"
                    >
                      <LogOut className="w-4 h-4 mr-2" />
                      {t('auth.signOut')}
                    </button>
                  </>
                ) : (
                  <a
                    href="#login"
                    onClick={() => setIsMenuOpen(false)}
                    className="w-full flex items-center px-4 py-2 text-sm text-gray-600 hover:bg-gray-50 transition-colors"
                  >
                    <LogIn className="w-4 h-4 mr-2" />
                    {t('auth.signIn')}
                  </a>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </header>
  );
};