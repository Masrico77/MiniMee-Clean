import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bot, Send, Loader, ArrowRight, Brain } from 'lucide-react';
import { getJournalResponse } from '../services/openai';
import { saveChatMessage } from '../services/chat';
import { completeOnboarding } from '../services/auth';
import { Logo } from './Logo';

interface Props {
  userId: string;
  onComplete: () => void;
}

export const OnboardingChat: React.FC<Props> = ({ userId, onComplete }) => {
  const [messages, setMessages] = useState<{ role: 'user' | 'assistant'; content: string }[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [isCompleting, setIsCompleting] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    // Start the conversation with a welcoming message
    const initialMessage = `Welcome to MiniMee! 🌟 I'm your personal journaling companion, and I'm excited to get to know you.

Let's start with something simple - what brings you to journaling today? It could be anything from wanting to reflect on your thoughts, track your personal growth, or simply have a space to express yourself.`;

    handleAIResponse(initialMessage);
  }, []);

  const handleAIResponse = async (content: string) => {
    setMessages(prev => [...prev, { role: 'assistant', content }]);
    
    try {
      const { conversationId: newConvId } = await saveChatMessage(
        userId,
        conversationId,
        'assistant',
        content
      );
      setConversationId(newConvId);
    } catch (error) {
      console.error('Error saving AI message:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setIsLoading(true);

    try {
      await saveChatMessage(userId, conversationId, 'user', userMessage);
      const response = await getJournalResponse("Initial user onboarding chat", userMessage, userId);
      await handleAIResponse(response);

      // Show confirmation after the first meaningful exchange
      if (messages.filter(m => m.role === 'user').length === 1) {
        setTimeout(() => {
          handleAIResponse(
            "Thank you for sharing! I understand better what you're looking for in your journaling journey. Would you like to start your first journal entry now? I'll be here to guide you through the process."
          );
          setShowConfirmation(true);
        }, 1000);
      }
    } catch (error) {
      console.error('Error in chat:', error);
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: "I apologize, but I'm having trouble responding right now. Please try again."
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleComplete = async () => {
    setIsCompleting(true);
    try {
      await completeOnboarding(userId);
      // First scroll to top smoothly
      window.scrollTo({ top: 0, behavior: 'smooth' });
      
      // After scroll animation completes, trigger completion
      setTimeout(() => {
        window.scrollTo({ top: 0 });
        onComplete();
      }, 300);
    } catch (error) {
      console.error('Error completing onboarding:', error);
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: "I'm having trouble completing the onboarding process. Please try again."
      }]);
    } finally {
      setIsCompleting(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-2xl mx-auto bg-white rounded-2xl shadow-xl overflow-hidden"
    >
      {/* Header */}
      <div className="p-6 bg-gradient-to-r from-indigo-600 to-purple-600">
        <div className="flex items-center justify-center gap-3 mb-4">
          <Logo size="md" className="text-white" />
        </div>
        <div className="text-center text-white/90">
          <p className="text-sm">Let's get to know each other and start your journaling journey</p>
        </div>
      </div>

      {/* Chat Area */}
      <div className="h-[400px] overflow-y-auto p-4 space-y-4">
        {messages.map((message, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[80%] p-3 rounded-2xl ${
                message.role === 'user'
                  ? 'bg-indigo-600 text-white rounded-tr-none'
                  : 'bg-gray-100 text-gray-800 rounded-tl-none'
              }`}
            >
              <p className="text-sm whitespace-pre-wrap">{message.content}</p>
            </div>
          </motion.div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-gray-100 p-3 rounded-2xl rounded-tl-none">
              <Loader className="w-5 h-5 animate-spin text-gray-600" />
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-4 border-t border-gray-100">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="relative">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type your message..."
              className="w-full px-4 py-2 pr-12 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            />
            <motion.button
              type="submit"
              disabled={!input.trim() || isLoading}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 bg-indigo-600 text-white rounded-lg disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send className="w-4 h-4" />
            </motion.button>
          </div>

          {/* Confirmation Section */}
          <AnimatePresence>
            {showConfirmation && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="p-4 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl"
              >
                <div className="text-center space-y-4">
                  <div className="flex items-center justify-center gap-2 text-indigo-600">
                    <Brain className="w-5 h-5" />
                    <p className="font-medium">Ready to start your first journal entry?</p>
                  </div>
                  <div className="flex justify-center gap-4">
                    <motion.button
                      onClick={handleComplete}
                      disabled={isCompleting}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="px-6 py-2 bg-indigo-600 text-white rounded-xl flex items-center gap-2 hover:bg-indigo-700 transition-colors disabled:opacity-50"
                    >
                      {isCompleting ? (
                        <>
                          <Loader className="w-4 h-4 animate-spin" />
                          Setting up...
                        </>
                      ) : (
                        <>
                          Begin Journaling
                          <ArrowRight className="w-4 h-4" />
                        </>
                      )}
                    </motion.button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </form>
      </div>
    </motion.div>
  );
};