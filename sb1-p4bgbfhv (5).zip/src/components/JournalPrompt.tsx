import React from 'react';
import { motion } from 'framer-motion';
import { BookOpen } from 'lucide-react';
import type { JournalPrompt } from '../types';

interface Props {
  prompt: JournalPrompt;
  onSelect: (prompt: JournalPrompt) => void;
}

export const JournalPromptCard: React.FC<Props> = ({ prompt, onSelect }) => {
  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      className="bg-white p-6 rounded-lg shadow-lg cursor-pointer hover:shadow-xl transition-all"
      onClick={() => onSelect(prompt)}
    >
      <div className="flex items-center gap-4 mb-4">
        <div className="p-3 bg-indigo-100 rounded-full">
          <BookOpen className="w-6 h-6 text-indigo-600" />
        </div>
        <h3 className="text-xl font-semibold text-gray-800">{prompt.question}</h3>
      </div>
      <p className="text-gray-600">{prompt.description}</p>
    </motion.div>
  );
};