import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Calendar, Brain, Loader, AlertCircle, RefreshCw, MessageSquare, BookOpen, Sparkles, TrendingUp } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { supabase } from '../lib/supabase';
import { getJournalResponse } from '../services/openai';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
}

interface EmotionData {
  emotion: string;
  intensity: number;
  color: string;
}

const emotionCategories = {
  positive: {
    gradient: 'from-emerald-50 to-teal-50',
    dotColor: 'bg-emerald-400',
    emotions: ['joy', 'gratitude', 'happiness', 'love', 'excitement', 'delight', 'contentment', 'peace'],
    label: 'Positive Emotions'
  },
  growth: {
    gradient: 'from-indigo-50 to-blue-50',
    dotColor: 'bg-indigo-400',
    emotions: ['hope', 'pride', 'confidence', 'inspiration', 'motivation', 'determination', 'ambition', 'empowerment'],
    label: 'Growth & Progress'
  },
  challenging: {
    gradient: 'from-amber-50 to-orange-50',
    dotColor: 'bg-amber-400',
    emotions: ['anxiety', 'frustration', 'stress', 'uncertainty', 'worry', 'doubt', 'overwhelm', 'fear'],
    label: 'Challenging Emotions'
  },
  reflective: {
    gradient: 'from-purple-50 to-fuchsia-50',
    dotColor: 'bg-purple-400',
    emotions: ['contemplation', 'curiosity', 'wonder', 'understanding', 'insight', 'awareness', 'mindfulness', 'introspection'],
    label: 'Reflective States'
  }
};

const EmotionGrid: React.FC<{ data: EmotionData[] }> = ({ data }) => {
  const categoryIntensities = Object.entries(emotionCategories).map(([key, category]) => {
    const categoryEmotions = data.filter(d => d.emotion === key);
    const totalIntensity = categoryEmotions.reduce((sum, e) => sum + e.intensity, 0);
    return {
      key,
      ...category,
      intensity: totalIntensity,
      emotions: categoryEmotions
    };
  });

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4 w-full max-w-2xl mx-auto">
      {categoryIntensities.map(({ key, gradient, dotColor, label, intensity }) => (
        <motion.div
          key={key}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className={`relative p-3 sm:p-6 rounded-xl bg-gradient-to-br ${gradient} overflow-hidden`}
        >
          <div className="relative z-10">
            <h4 className="text-sm font-medium text-gray-800 mb-1 sm:mb-2">{label}</h4>
            <div className="h-16 sm:h-24 relative">
              {Array.from({ length: Math.max(1, Math.ceil(intensity * 15)) }).map((_, i) => (
                <motion.div
                  key={i}
                  className={`absolute w-1.5 h-1.5 sm:w-2.5 sm:h-2.5 rounded-full ${dotColor}`}
                  initial={{ scale: 0 }}
                  animate={{ 
                    scale: [1, 1.2, 1],
                    opacity: [0.7, 1, 0.7]
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    delay: i * 0.2
                  }}
                  style={{
                    left: `${Math.random() * 80}%`,
                    top: `${Math.random() * 80}%`
                  }}
                />
              ))}
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
};

function extractEmotionsFromContent(content: string, metadata: any): { emotion: string; count: number }[] {
  const emotions: Record<string, number> = {};
  
  if (metadata?.emotional_themes) {
    metadata.emotional_themes.forEach((theme: string) => {
      emotions[theme.toLowerCase()] = (emotions[theme.toLowerCase()] || 0) + 1;
    });
  }

  const emotionKeywords = {
    joy: ['happy', 'excited', 'joyful', 'delighted', 'wonderful', 'amazing', 'fantastic', 'great'],
    gratitude: ['thankful', 'grateful', 'appreciate', 'blessed', 'fortunate'],
    love: ['love', 'caring', 'affection', 'warmth', 'connection'],
    contentment: ['content', 'satisfied', 'peaceful', 'calm', 'relaxed', 'serene'],
    
    hope: ['hopeful', 'optimistic', 'looking forward', 'anticipate', 'eager'],
    pride: ['proud', 'accomplished', 'achieved', 'successful', 'confident'],
    confidence: ['confident', 'capable', 'strong', 'empowered', 'assured'],
    inspiration: ['inspired', 'motivated', 'energized', 'driven', 'determined'],
    
    anxiety: ['anxious', 'worried', 'nervous', 'uneasy', 'apprehensive', 'tense'],
    frustration: ['frustrated', 'annoyed', 'irritated', 'upset', 'agitated'],
    stress: ['stressed', 'overwhelmed', 'pressured', 'burdened', 'strained'],
    uncertainty: ['uncertain', 'unsure', 'confused', 'doubtful', 'hesitant'],
    
    contemplation: ['thinking', 'reflecting', 'pondering', 'considering', 'processing'],
    curiosity: ['curious', 'interested', 'intrigued', 'fascinated', 'wondering'],
    insight: ['realized', 'understood', 'discovered', 'learned', 'recognized'],
    awareness: ['aware', 'mindful', 'conscious', 'present', 'attentive']
  };

  Object.entries(emotionKeywords).forEach(([emotion, keywords]) => {
    const matches = keywords.some(keyword => {
      const regex = new RegExp(`\\b${keyword}\\b`, 'i');
      return regex.test(content);
    });
    
    if (matches) {
      emotions[emotion] = (emotions[emotion] || 0) + 1;
    }
  });

  const categorizedEmotions = Object.entries(emotions).map(([emotion, count]) => {
    let category = '';
    for (const [cat, data] of Object.entries(emotionCategories)) {
      if (data.emotions.includes(emotion)) {
        category = cat;
        break;
      }
    }
    return { emotion: category || emotion, count };
  });

  return categorizedEmotions;
}

function combineEmotions(entries: any[]): EmotionData[] {
  const emotionCounts: Record<string, number> = {};
  let totalCount = 0;

  entries.forEach(entry => {
    const emotions = extractEmotionsFromContent(
      entry.content || entry.answer || '',
      entry.metadata
    );
    
    emotions.forEach(({ emotion, count }) => {
      if (emotion) {
        emotionCounts[emotion] = (emotionCounts[emotion] || 0) + count;
        totalCount += count;
      }
    });
  });

  const result: EmotionData[] = Object.keys(emotionCategories).map(category => ({
    emotion: category,
    intensity: (emotionCounts[category] || 0) / (totalCount || 1),
    color: '#9CA3AF'
  }));

  return result;
}

const renderSummarySection = (
  title: string,
  icon: React.ReactNode,
  items: string[],
  gradientFrom: string,
  gradientTo: string
) => (
  <motion.div
    initial={{ opacity: 0, y: 10 }}
    animate={{ opacity: 1, y: 0 }}
    className={`bg-gradient-to-br from-${gradientFrom} to-${gradientTo} rounded-xl p-4 sm:p-6`}
  >
    <div className="flex items-center gap-3 mb-4">
      <div className="p-2 bg-white/50 rounded-lg">
        {icon}
      </div>
      <h3 className="font-semibold text-gray-900">{title}</h3>
    </div>
    <div className="space-y-3">
      {items.map((item, index) => {
        const cleanedItem = item.replace(/^[•*\s-]+/, '').trim();
        
        return (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="flex items-start gap-3 group"
          >
            <div className="w-1.5 h-1.5 rounded-full bg-indigo-500/40 mt-2.5 group-hover:bg-indigo-500 transition-colors duration-200" />
            <p className="flex-1 text-[15px] text-gray-700 leading-relaxed tracking-wide font-normal">
              {cleanedItem}
            </p>
          </motion.div>
        );
      })}
    </div>
  </motion.div>
);

export const WeeklySummary: React.FC<Props> = ({ isOpen, onClose, userId }) => {
  const { t } = useTranslation();
  const [summary, setSummary] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [retryCount, setRetryCount] = useState(0);
  const [journalCount, setJournalCount] = useState(0);
  const [chatCount, setChatCount] = useState(0);
  const [emotionData, setEmotionData] = useState<EmotionData[]>([]);
  const [showHeatMap, setShowHeatMap] = useState(false);
  const [parsedSummary, setParsedSummary] = useState<{
    themes: string[];
    insights: string[];
    growth: string[];
  }>({
    themes: [],
    insights: [],
    growth: []
  });

  const parseAISummary = (text: string) => {
    const sections = {
      themes: [] as string[],
      insights: [] as string[],
      growth: [] as string[]
    };

    const lines = text.split('\n');
    let currentSection: keyof typeof sections | null = null;

    lines.forEach(line => {
      const trimmedLine = line.trim();
      
      if (trimmedLine.toLowerCase().includes('key themes & patterns')) {
        currentSection = 'themes';
      } else if (trimmedLine.toLowerCase().includes('insights & observations')) {
        currentSection = 'insights';
      } else if (trimmedLine.toLowerCase().includes('growth & progress')) {
        currentSection = 'growth';
      } else if (currentSection && (trimmedLine.startsWith('-') || trimmedLine.startsWith('•'))) {
        const point = trimmedLine.substring(1).trim();
        if (point) {
          sections[currentSection].push(point);
        }
      }
    });

    setParsedSummary(sections);
  };

  const fetchWeeklySummary = async (retry = false) => {
    if (retry) {
      setRetryCount(prev => prev + 1);
    } else {
      setRetryCount(0);
    }

    setIsLoading(true);
    setError(null);

    try {
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);

      const { data: userStats, error: statsError } = await supabase
        .from('user_stats')
        .select('total_entries')
        .eq('user_id', userId)
        .single();

      if (statsError) throw statsError;

      const [journalResult, chatResult] = await Promise.all([
        supabase
          .from('journal_entries')
          .select('prompt, answer, ai_response, created_at, metadata')
          .eq('user_id', userId)
          .gte('created_at', weekAgo.toISOString())
          .order('created_at', { ascending: false }),
        
        supabase
          .from('chat_messages')
          .select('role, content, created_at, metadata')
          .eq('user_id', userId)
          .gte('created_at', weekAgo.toISOString())
          .order('created_at', { ascending: false })
      ]);

      if (journalResult.error) throw journalResult.error;
      if (chatResult.error) throw chatResult.error;

      const combinedEmotions = combineEmotions([
        ...(journalResult.data || []),
        ...(chatResult.data || [])
      ]);
      
      setEmotionData(combinedEmotions);
      setJournalCount(userStats.total_entries || 0);
      setChatCount(chatResult.data?.length || 0);

      if (journalResult.data.length === 0 && chatResult.data.length === 0) {
        setSummary(t('weekSummary.empty.description'));
        return;
      }

      const context = {
        journalEntries: journalResult.data.map(entry => ({
          prompt: t(entry.prompt),
          answer: entry.answer,
          aiResponse: entry.ai_response,
          date: new Date(entry.created_at).toLocaleDateString(),
          themes: entry.metadata?.emotional_themes || [],
          topics: entry.metadata?.key_topics || []
        })),
        chatMessages: chatResult.data.map(msg => ({
          role: msg.role,
          content: msg.content,
          date: new Date(msg.created_at).toLocaleDateString(),
          themes: msg.metadata?.emotional_themes || [],
          topics: msg.metadata?.key_topics || []
        }))
      };

      const aiPrompt = `Create a comprehensive weekly summary that analyzes both journal entries and chat conversations. Structure the response in these exact sections:

Key Themes & Patterns:
- Common emotional themes across both journals and chats
- Recurring topics or concerns
- Progress and growth indicators

Insights & Observations:
- Notable reflections from journal entries
- Important realizations from chat conversations
- Connections between journal and chat content

Growth & Progress:
- Signs of personal development
- Changes in perspective or approach
- Areas of consistent focus

Format each point with bullet points (using "-" or "•").
Keep points concise but meaningful, and maintain absolute privacy (no specific personal details).
Ensure consistent formatting for easy parsing.`;

      const aiResponse = await getJournalResponse(aiPrompt, JSON.stringify(context), userId);
      
      if (!aiResponse) throw new Error('No response from AI');
      
      setSummary(aiResponse);
      parseAISummary(aiResponse);
    } catch (err) {
      console.error('Error fetching summary:', err);
      setError(
        retryCount >= 2
          ? t('weekSummary.error.title')
          : t('weekSummary.error.description')
      );
    } finally {
      setIsLoading(false);
    }
  };

  React.useEffect(() => {
    if (isOpen) {
      fetchWeeklySummary();
    } else {
      setSummary(null);
      setError(null);
    }
  }, [isOpen, userId]);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-start justify-center overflow-y-auto"
          onClick={onClose}
        >
          <div className="min-h-screen w-full py-4 sm:py-8 px-3 sm:px-6">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={e => e.stopPropagation()}
              className="bg-white w-full max-w-2xl mx-auto rounded-2xl shadow-xl relative"
            >
              <div className="p-4 sm:p-6 border-b border-gray-100 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-t-2xl">
                <div className="flex flex-col gap-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-white/10 rounded-lg">
                        <Calendar className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <h2 className="text-lg font-semibold text-white">
                          {t('weekSummary.title')}
                        </h2>
                        <p className="text-sm text-white/80">
                          Weekly Insights & Reflections
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={onClose}
                      className="p-1.5 hover:bg-white/10 rounded-lg transition-colors text-white"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  {!isLoading && summary && (
                    <motion.button
                      onClick={() => setShowHeatMap(!showHeatMap)}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      className="flex items-center justify-center gap-2 px-3 py-2 bg-white/10 text-white text-sm rounded-lg hover:bg-white/20 transition-colors w-full sm:w-auto mt-2"
                    >
                      {showHeatMap ? (
                        <>
                          <MessageSquare className="w-4 h-4" />
                          View Summary
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4" />
                          View Emotion Map
                        </>
                      )}
                    </motion.button>
                  )}
                </div>
              </div>

              <div className="p-4 sm:p-6 space-y-6">
                {isLoading ? (
                  <div className="flex flex-col items-center justify-center py-8 space-y-2">
                    <Loader className="w-6 h-6 text-indigo-600 animate-spin" />
                    <p className="text-sm text-gray-600">{t('weekSummary.loading')}</p>
                  </div>
                ) : error ? (
                  <div className="flex flex-col items-center justify-center py-6 space-y-4">
                    <div className="p-3 bg-red-50 rounded-full">
                      <AlertCircle className="w-6 h-6 text-red-600" />
                    </div>
                    <div className="text-center">
                      <h3 className="font-medium text-gray-900 mb-2">{t('weekSummary.error.title')}</h3>
                      <p className="text-sm text-gray-600">{error}</p>
                    </div>
                    {retryCount < 3 && (
                      <motion.button
                        onClick={() => fetchWeeklySummary(true)}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
                      >
                        <RefreshCw className="w-4 h-4" />
                        {t('weekSummary.error.retry')}
                      </motion.button>
                    )}
                  </div>
                ) : summary ? (
                  <AnimatePresence mode="wait">
                    {showHeatMap ? (
                      <motion.div
                        key="heatmap"
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        className="space-y-4 sm:space-y-6"
                      >
                        <div className="grid grid-cols-2 gap-3 sm:gap-4">
                          <motion.div
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="p-3 sm:p-4 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl"
                          >
                            <div className="flex items-center gap-2 mb-1 sm:mb-2">
                              <BookOpen className="w-4 h-4 text-indigo-600" />
                              <span className="text-xs sm:text-sm font-medium text-gray-900">Completed Journals</span>
                            </div>
                            <p className="text-lg sm:text-2xl font-bold text-indigo-600">{journalCount}</p>
                          </motion.div>
                          <motion.div
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.1 }}
                            className="p-3 sm:p-4 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl"
                          >
                            <div className="flex items-center gap-2 mb-1 sm:mb-2">
                              <MessageSquare className="w-4 h-4 text-purple-600" />
                              <span className="text-xs sm:text-sm font-medium text-gray-900">Chat Messages</span>
                            </div>
                            <p className="text-lg sm:text-2xl font-bold text-purple-600">{chatCount}</p>
                          </motion.div>
                        </div>

                        <motion.div
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="bg-white rounded-xl p-3 sm:p-6 shadow-sm"
                        >
                          <div className="flex items-center gap-2 mb-3 sm:mb-4">
                            <Sparkles className="w-5 h-5 text-indigo-600" />
                            <h3 className="font-medium text-gray-900">Emotional Landscape</h3>
                          </div>
                          <div className="flex flex-col items-center gap-4 sm:gap-6">
                            <EmotionGrid data={emotionData} />
                            <p className="text-xs sm:text-sm text-gray-600 text-center max-w-md">
                              This visualization shows your emotional landscape through pulsating dots. 
                              The number and intensity of dots in each category represent the prevalence 
                              of those emotions in your journal entries and chat conversations.
                            </p>
                          </div>
                        </motion.div>
                      </motion.div>
                    ) : (
                      <motion.div
                        key="summary"
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 20 }}
                        className="space-y-6"
                      >
                        {renderSummarySection(
                          'Key Themes & Patterns',
                          <Sparkles className="w-4 h-4 text-indigo-600" />,
                          parsedSummary.themes,
                          'indigo-50',
                          'purple-50'
                        )}

                        {renderSummarySection(
                          'Insights & Observations',
                          <Brain className="w-4 h-4 text-purple-600" />,
                          parsedSummary.insights,
                          'purple-50',
                          'pink-50'
                        )}

                        {renderSummarySection(
                          'Growth & Progress',
                          <TrendingUp className="w-4 h-4 text-pink-600" />,
                          parsedSummary.growth,
                          'pink-50',
                          'rose-50'
                        )}
                      </motion.div>
                    )}
                  </AnimatePresence>
                ) : (
                  <div className="text-center py-8">
                    <h3 className="font-medium text-gray-900 mb-2">{t('weekSummary.empty.title')}</h3>
                    <p className="text-sm text-gray-600">{t('weekSummary.empty.description')}</p>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};