import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Shield, FileText, X, HelpCircle, Globe, Brain, Lock } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Logo } from './Logo';

export const Footer: React.FC = () => {
  const [showPrivacy, setShowPrivacy] = useState(false);
  const [showTerms, setShowTerms] = useState(false);
  const [showFAQ, setShowFAQ] = useState(false);
  const { t } = useTranslation();

  const Modal: React.FC<{
    show: boolean;
    onClose: () => void;
    title: string;
    children: React.ReactNode;
  }> = ({ show, onClose, title, children }) => (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.95 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0.95 }}
            onClick={(e) => e.stopPropagation()}
            className="bg-white rounded-xl shadow-lg max-w-2xl w-full max-h-[80vh] overflow-hidden flex flex-col"
          >
            <div className="p-4 border-b border-gray-100 flex items-center justify-between bg-gradient-to-r from-indigo-500 to-purple-500">
              <h2 className="text-lg font-semibold text-white">{title}</h2>
              <button
                onClick={onClose}
                className="p-1 hover:bg-white/10 rounded-lg transition-colors text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 overflow-y-auto">{children}</div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );

  return (
    <footer className="bg-gradient-to-br from-white to-indigo-50/50 border-t border-indigo-100">
      <div className="max-w-7xl mx-auto px-4 py-8 sm:py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo and Description */}
          <div className="col-span-1 md:col-span-2 space-y-4">
            <Logo size="sm" />
            <p className="text-gray-600 text-sm">
              {t('footer.description')}
            </p>
            <p className="text-sm text-gray-500">
              {t('footer.copyright', { year: new Date().getFullYear() })}
            </p>
          </div>
          
          {/* Legal Links */}
          <div className="space-y-4">
            <h4 className="text-sm font-semibold text-gray-900">{t('footer.legal.title')}</h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => setShowPrivacy(true)}
                  className="text-gray-600 hover:text-indigo-600 transition-colors text-sm flex items-center gap-2 group"
                >
                  <Shield className="w-4 h-4 text-gray-400 group-hover:text-indigo-600 transition-colors" />
                  {t('footer.legal.privacy')}
                </button>
              </li>
              <li>
                <button
                  onClick={() => setShowTerms(true)}
                  className="text-gray-600 hover:text-indigo-600 transition-colors text-sm flex items-center gap-2 group"
                >
                  <FileText className="w-4 h-4 text-gray-400 group-hover:text-indigo-600 transition-colors" />
                  {t('footer.legal.terms')}
                </button>
              </li>
              <li>
                <button
                  onClick={() => setShowFAQ(true)}
                  className="text-gray-600 hover:text-indigo-600 transition-colors text-sm flex items-center gap-2 group"
                >
                  <HelpCircle className="w-4 h-4 text-gray-400 group-hover:text-indigo-600 transition-colors" />
                  FAQ
                </button>
              </li>
            </ul>
          </div>

          {/* Security Info */}
          <div className="space-y-4">
            <h4 className="text-sm font-semibold text-gray-900">{t('footer.security.title')}</h4>
            <div className="p-4 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-lg border border-indigo-100/50">
              <p className="text-sm text-gray-600">
                {t('footer.security.description')}
              </p>
            </div>
          </div>
        </div>
      </div>

      <Modal
        show={showPrivacy}
        onClose={() => setShowPrivacy(false)}
        title={t('footer.privacy.title')}
      >
        <div className="prose prose-indigo max-w-none">
          <div className="flex items-center gap-2 mb-4">
            <Shield className="w-5 h-5 text-indigo-600 flex-shrink-0" />
            <h3 className="text-lg font-semibold text-gray-900 m-0">{t('footer.privacy.title')}</h3>
          </div>
          
          <p className="text-gray-600 mb-6">{t('footer.privacy.description')}</p>

          {/* Information Collection */}
          <h4 className="font-semibold text-gray-800">{t('footer.privacy.sections.collection.title')}</h4>
          <div className="text-gray-600 mb-4">
            {t('footer.privacy.sections.collection.description')}
            <ul className="list-disc pl-5 space-y-1">
              {(t('footer.privacy.sections.collection.items', { returnObjects: true }) as string[]).map((item, index) => (
                <li key={index}>{item}</li>
              ))}
            </ul>
          </div>

          {/* Information Usage */}
          <h4 className="font-semibold text-gray-800">{t('footer.privacy.sections.usage.title')}</h4>
          <div className="text-gray-600 mb-4">
            {t('footer.privacy.sections.usage.description')}
            <ul className="list-disc pl-5 space-y-1">
              {(t('footer.privacy.sections.usage.items', { returnObjects: true }) as string[]).map((item, index) => (
                <li key={index}>{item}</li>
              ))}
            </ul>
          </div>

          {/* Data Security */}
          <h4 className="font-semibold text-gray-800">{t('footer.privacy.sections.security.title')}</h4>
          <p className="text-gray-600 mb-4">
            {t('footer.privacy.sections.security.description')}
          </p>

          {/* User Rights */}
          <h4 className="font-semibold text-gray-800">{t('footer.privacy.sections.rights.title')}</h4>
          <div className="text-gray-600">
            {t('footer.privacy.sections.rights.description')}
            <ul className="list-disc pl-5 space-y-1">
              {(t('footer.privacy.sections.rights.items', { returnObjects: true }) as string[]).map((item, index) => (
                <li key={index}>{item}</li>
              ))}
            </ul>
          </div>
        </div>
      </Modal>

      <Modal
        show={showTerms}
        onClose={() => setShowTerms(false)}
        title={t('footer.terms.title')}
      >
        <div className="prose prose-indigo max-w-none">
          <div className="flex items-center gap-2 mb-4">
            <FileText className="w-5 h-5 text-indigo-600 flex-shrink-0" />
            <h3 className="text-lg font-semibold text-gray-900 m-0">{t('footer.terms.title')}</h3>
          </div>

          {/* Acceptance of Terms */}
          <h4 className="font-semibold text-gray-800">{t('footer.terms.sections.acceptance.title')}</h4>
          <p className="text-gray-600 mb-4">
            {t('footer.terms.sections.acceptance.description')}
          </p>

          {/* User Responsibilities */}
          <h4 className="font-semibold text-gray-800">{t('footer.terms.sections.responsibilities.title')}</h4>
          <div className="text-gray-600 mb-4">
            {t('footer.terms.sections.responsibilities.description')}
            <ul className="list-disc pl-5 space-y-1">
              {(t('footer.terms.sections.responsibilities.items', { returnObjects: true }) as string[]).map((item, index) => (
                <li key={index}>{item}</li>
              ))}
            </ul>
          </div>

          {/* Service Usage */}
          <h4 className="font-semibold text-gray-800">{t('footer.terms.sections.service.title')}</h4>
          <p className="text-gray-600 mb-4">
            {t('footer.terms.sections.service.description')}
          </p>

          {/* Intellectual Property */}
          <h4 className="font-semibold text-gray-800">{t('footer.terms.sections.intellectual.title')}</h4>
          <p className="text-gray-600 mb-4">
            {t('footer.terms.sections.intellectual.description')}
          </p>

          {/* Limitation of Liability */}
          <h4 className="font-semibold text-gray-800">{t('footer.terms.sections.liability.title')}</h4>
          <p className="text-gray-600">
            {t('footer.terms.sections.liability.description')}
          </p>
        </div>
      </Modal>

      <Modal
        show={showFAQ}
        onClose={() => setShowFAQ(false)}
        title={t('footer.faq.title')}
      >
        <div className="prose prose-indigo max-w-none space-y-6">
          {/* Data Privacy */}
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Lock className="w-5 h-5 text-indigo-600 flex-shrink-0" />
              <h3 className="text-lg font-semibold text-gray-900 m-0">{t('footer.faq.data.title')}</h3>
            </div>
            <p className="text-gray-600">
              {t('footer.faq.data.description')}
            </p>
          </div>

          {/* Mobile App */}
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Brain className="w-5 h-5 text-indigo-600 flex-shrink-0" />
              <h3 className="text-lg font-semibold text-gray-900 m-0">{t('footer.faq.app.title')}</h3>
            </div>
            <p className="text-gray-600">
              {t('footer.faq.app.description')}
            </p>
          </div>

          {/* Language Support */}
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Globe className="w-5 h-5 text-indigo-600 flex-shrink-0" />
              <h3 className="text-lg font-semibold text-gray-900 m-0">{t('footer.faq.language.title')}</h3>
            </div>
            <p className="text-gray-600">
              {t('footer.faq.language.description')}
            </p>
          </div>

          {/* Benefits of Journaling */}
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Brain className="w-5 h-5 text-indigo-600 flex-shrink-0" />
              <h3 className="text-lg font-semibold text-gray-900 m-0">{t('footer.faq.benefits.title')}</h3>
            </div>
            <div className="text-gray-600 space-y-2">
              <p>{t('footer.faq.benefits.intro')}</p>
              <ul className="list-disc pl-5 space-y-1">
                {(t('footer.faq.benefits.items', { returnObjects: true }) as string[]).map((item, index) => (
                  <li key={index}>{item}</li>
                ))}
              </ul>
              <p>{t('footer.faq.benefits.conclusion')}</p>
            </div>
          </div>
        </div>
      </Modal>
    </footer>
  );
};