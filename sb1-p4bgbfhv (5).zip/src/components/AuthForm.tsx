import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { LogIn, UserPlus, Loader, AlertCircle, Lock, Mail, CheckCircle, Share2, Copy, Check, Link as LinkIcon, Sparkles, Brain, Shield } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { signIn, signUp, resendVerificationEmail, resetPassword } from '../services/auth';
import { OnboardingChat } from './OnboardingChat';

interface Props {
  onSuccess: () => void;
}

export const AuthForm: React.FC<Props> = ({ onSuccess }) => {
  const { t } = useTranslation();
  const [isSignUp, setIsSignUp] = useState(false);
  const [isForgotPassword, setIsForgotPassword] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);
  const [needsVerification, setNeedsVerification] = useState(false);
  const [verificationEmailSent, setVerificationEmailSent] = useState(false);
  const [showCopied, setShowCopied] = useState(false);
  const [shareError, setShareError] = useState<string | null>(null);
  const [resetEmailSent, setResetEmailSent] = useState(false);
  const formRef = useRef<HTMLDivElement>(null);
  const linkRef = useRef<HTMLInputElement>(null);

  const handleSuccess = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setTimeout(() => {
      window.scrollTo({ top: 0 });
      onSuccess();
    }, 300);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      if (isForgotPassword) {
        await resetPassword(email);
        setResetEmailSent(true);
      } else if (isSignUp) {
        const { user, isNewUser, needsEmailVerification } = await signUp(email, password);
        if (needsEmailVerification) {
          setNeedsVerification(true);
          setVerificationEmailSent(true);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        } else if (user && isNewUser) {
          setUserId(user.id);
          setShowOnboarding(true);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        } else {
          handleSuccess();
        }
      } else {
        const { user, isNewUser } = await signIn(email, password);
        if (user && isNewUser) {
          setUserId(user.id);
          setShowOnboarding(true);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        } else {
          handleSuccess();
        }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : t('common.error'));
      if (err instanceof Error && err.message.includes('verify your email')) {
        setNeedsVerification(true);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleResendVerification = async () => {
    setIsLoading(true);
    setError('');
    try {
      await resendVerificationEmail(email);
      setVerificationEmailSent(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : t('auth.verifyEmail.error'));
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setShowCopied(true);
      setTimeout(() => setShowCopied(false), 2000);
      setShareError(null);
    } catch (err) {
      console.error('Failed to copy:', err);
      setShareError(t('auth.form.invite.copyError'));
    }
  };

  const handleShare = async () => {
    const shareData = {
      title: t('auth.form.invite.shareTitle'),
      text: t('auth.form.invite.shareText'),
      url: window.location.origin
    };

    setShareError(null);
    
    try {
      if (navigator.share && await navigator.canShare?.(shareData)) {
        await navigator.share(shareData);
      } else {
        await copyToClipboard(`${shareData.text}\n\n${shareData.url}`);
      }
    } catch (err) {
      console.error('Share failed:', err);
      if (err instanceof Error && err.name !== 'AbortError') {
        setShareError(t('auth.form.invite.shareError'));
      }
    }
  };

  useEffect(() => {
    if (window.location.hash === '#login' && formRef.current) {
      formRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, []);

  if (showOnboarding && userId) {
    return <OnboardingChat userId={userId} onComplete={handleSuccess} />;
  }

  if (needsVerification) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md mx-auto"
      >
        <div className="bg-white/80 backdrop-blur-lg rounded-2xl shadow-xl p-8 text-center">
          <div className="flex justify-center mb-6">
            <div className="p-3 bg-indigo-100 rounded-xl">
              <Mail className="w-6 h-6 text-indigo-600" />
            </div>
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">{t('auth.form.verification.title')}</h2>
          <p className="text-gray-600 mb-4">
            {t('auth.form.verification.description')} <strong>{email}</strong>. {t('auth.form.verification.instruction')}
          </p>
          {verificationEmailSent ? (
            <div className="flex items-center justify-center gap-2 text-green-600 mb-6">
              <CheckCircle className="w-5 h-5" />
              <span>{t('auth.form.verification.emailSent')}</span>
            </div>
          ) : (
            <button
              onClick={handleResendVerification}
              disabled={isLoading}
              className="text-indigo-600 hover:text-indigo-500 font-medium disabled:opacity-50"
            >
              {t('auth.form.verification.resendButton')}
            </button>
          )}
          <div className="mt-6 p-4 bg-indigo-50 rounded-lg">
            <p className="text-sm text-indigo-700">
              {t('auth.form.verification.afterVerify')}
            </p>
          </div>
        </div>
      </motion.div>
    );
  }

  if (resetEmailSent) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md mx-auto"
      >
        <div className="bg-white/80 backdrop-blur-lg rounded-2xl shadow-xl p-8 text-center">
          <div className="flex justify-center mb-6">
            <div className="p-3 bg-indigo-100 rounded-xl">
              <Mail className="w-6 h-6 text-indigo-600" />
            </div>
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">{t('auth.form.resetPassword.emailSent')}</h2>
          <p className="text-gray-600 mb-4">
            {t('auth.form.resetPassword.checkEmail')} <strong>{email}</strong>
          </p>
          <button
            onClick={() => {
              setIsForgotPassword(false);
              setResetEmailSent(false);
            }}
            className="text-indigo-600 hover:text-indigo-500 font-medium"
          >
            {t('auth.form.resetPassword.backToLogin')}
          </button>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      ref={formRef}
      id="login"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-md mx-auto scroll-mt-20"
    >
      <div className="bg-white/80 backdrop-blur-lg rounded-2xl shadow-xl overflow-hidden">
        <div className="px-8 pt-8 pb-6 relative">
          <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500" />
          <div className="flex justify-center mb-6">
            <div className="p-3 bg-indigo-100 rounded-xl">
              <Lock className="w-6 h-6 text-indigo-600" />
            </div>
          </div>
          <h2 className="text-2xl font-bold text-center text-gray-800 mb-2">
            {isForgotPassword 
              ? t('auth.form.resetPassword.title')
              : isSignUp 
                ? t('auth.createAccount') 
                : t('auth.signIn')}
          </h2>
          <p className="text-center text-gray-600 mb-6">
            {isForgotPassword
              ? t('auth.form.resetPassword.description')
              : isSignUp 
                ? t('auth.form.signUpDescription') 
                : t('auth.form.signInDescription')}
          </p>
        </div>

        <div className="px-8 pb-8">
          {isSignUp && (
            <div className="mb-6 p-4 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl">
              <div className="flex items-center gap-3 mb-3">
                <div className="p-2 bg-white/50 rounded-lg">
                  <Brain className="w-5 h-5 text-indigo-600" />
                </div>
                <h3 className="font-medium text-gray-900">Join MiniMee Today</h3>
              </div>
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-indigo-600 flex-shrink-0" />
                  <p className="text-sm text-gray-700">AI-powered journaling companion</p>
                </div>
                <div className="flex items-center gap-2">
                  <Shield className="w-4 h-4 text-indigo-600 flex-shrink-0" />
                  <p className="text-sm text-gray-700">Private and secure reflection space</p>
                </div>
                <div className="flex items-center gap-2">
                  <Brain className="w-4 h-4 text-indigo-600 flex-shrink-0" />
                  <p className="text-sm text-gray-700">Personalized insights and growth tracking</p>
                </div>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">{t('auth.form.emailLabel')}</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={t('auth.form.emailPlaceholder')}
                className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200 bg-white/50 backdrop-blur-sm"
                required
              />
            </div>

            {!isForgotPassword && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">{t('auth.form.passwordLabel')}</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder={t('auth.form.passwordPlaceholder')}
                  className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200 bg-white/50 backdrop-blur-sm"
                  required
                />
              </div>
            )}

            {error && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-center gap-2 text-sm p-3 rounded-lg bg-red-50 text-red-600 border border-red-100"
              >
                <AlertCircle className="w-4 h-4" />
                <p>{error}</p>
              </motion.div>
            )}

            <motion.button
              type="submit"
              disabled={isLoading}
              whileHover={{ scale: 1.01 }}
              whileTap={{ scale: 0.99 }}
              className={`w-full flex items-center justify-center py-3 px-4 rounded-lg text-sm font-medium text-white transition-all duration-200 ${
                isSignUp
                  ? 'bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:from-indigo-500 hover:via-purple-500 hover:to-pink-500'
                  : 'bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500'
              } focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed`}
            >
              {isLoading ? (
                <Loader className="w-5 h-5 animate-spin" />
              ) : isForgotPassword ? (
                t('auth.form.resetPassword.submit')
              ) : isSignUp ? (
                <>
                  <UserPlus className="w-5 h-5 mr-2" />
                  {t('auth.form.submitButton.signUp')}
                </>
              ) : (
                <>
                  <LogIn className="w-5 h-5 mr-2" />
                  {t('auth.form.submitButton.signIn')}
                </>
              )}
            </motion.button>
          </form>

          <div className="mt-6 flex flex-col items-center gap-4">
            {!isForgotPassword && (
              <motion.button
                onClick={() => setIsSignUp(!isSignUp)}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className={`w-full flex items-center justify-center gap-2 py-3 px-4 ${
                  isSignUp
                    ? 'text-sm text-indigo-600 hover:text-indigo-500 font-medium'
                    : 'bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:from-indigo-500 hover:via-purple-500 hover:to-pink-500 text-white rounded-lg shadow-md hover:shadow-lg'
                } transition-all duration-200`}
              >
                {isSignUp ? (
                  t('auth.alreadyHaveAccount')
                ) : (
                  <>
                    <UserPlus className="w-5 h-5" />
                    {t('auth.needAccount')}
                  </>
                )}
              </motion.button>
            )}

            <motion.button
              onClick={() => {
                setIsForgotPassword(!isForgotPassword);
                setError('');
              }}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="text-sm text-indigo-600 hover:text-indigo-500 font-medium focus:outline-none focus:underline transition-all duration-200"
            >
              {isForgotPassword 
                ? t('auth.form.resetPassword.backToLogin')
                : t('auth.form.resetPassword.forgotPassword')}
            </motion.button>

            <div className="w-full pt-6 border-t border-gray-100">
              <h3 className="text-sm font-medium text-gray-900 mb-3">
                {t('auth.form.invite.title')}
              </h3>
              <motion.button
                onClick={handleShare}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="w-full flex items-center justify-center gap-2 py-2 px-4 bg-indigo-50 text-indigo-600 rounded-lg hover:bg-indigo-100 transition-colors"
              >
                {showCopied ? (
                  <>
                    <Check className="w-4 h-4" />
                    {t('auth.form.invite.copied')}
                  </>
                ) : (
                  <>
                    <Share2 className="w-4 h-4" />
                    {t('auth.form.invite.shareButton')}
                  </>
                )}
              </motion.button>

              {shareError && (
                <div className="mt-3">
                  <div className="flex items-center gap-2 mb-2">
                    <LinkIcon className="w-4 h-4 text-gray-500" />
                    <span className="text-sm text-gray-600">{t('auth.form.invite.copyLink')}</span>
                  </div>
                  <div className="flex items-center gap-2 p-2 bg-gray-50 rounded-lg">
                    <input
                      ref={linkRef}
                      type="text"
                      value={window.location.origin}
                      readOnly
                      className="flex-1 bg-transparent border-none text-gray-600 text-sm focus:outline-none"
                      onClick={(e) => e.currentTarget.select()}
                    />
                    <button
                      onClick={() => copyToClipboard(window.location.origin)}
                      className="p-1.5 hover:bg-gray-200 rounded transition-colors"
                      title={t('auth.form.invite.copyButton')}
                    >
                      {showCopied ? (
                        <Check className="w-4 h-4 text-green-500" />
                      ) : (
                        <Copy className="w-4 h-4 text-gray-500" />
                      )}
                    </button>
                  </div>
                </div>
              )}

              <p className="text-xs text-gray-500 mt-2">
                {t('auth.form.invite.description')}
              </p>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default AuthForm;