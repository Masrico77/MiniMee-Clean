// Update the statusLevels array to use the correct translation keys
const statusLevels: StatusLevel[] = [
  {
    titleKey: 'status.levels.novice.title',
    icon: 'Sparkles',
    minStreak: 0,
    color: 'gray'
  },
  {
    titleKey: 'status.levels.consistent.title',
    icon: 'Pen',
    minStreak: 5,
    color: 'blue'
  },
  {
    titleKey: 'status.levels.dedicated.title',
    icon: 'BookOpen',
    minStreak: 10,
    color: 'green'
  },
  {
    titleKey: 'status.levels.master.title',
    icon: 'Brain',
    minStreak: 15,
    color: 'purple'
  },
  {
    titleKey: 'status.levels.keeper.title',
    icon: 'Star',
    minStreak: 20,
    color: 'yellow'
  }
];