import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';
import { Clock, MessageSquare, ChevronDown, ChevronRight, ArrowLeft } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import type { JournalEntry } from '../types';

interface Props {
  entries: JournalEntry[];
  onBack: () => void;
}

export const JournalHistory: React.FC<Props> = ({ entries, onBack }) => {
  const { t } = useTranslation();
  const [expandedDays, setExpandedDays] = useState<string[]>([]);

  // Group entries by day and reverse the order within each day
  const groupedEntries = entries.reduce((groups: Record<string, JournalEntry[]>, entry) => {
    const date = format(new Date(entry.created_at), 'yyyy-MM-dd');
    if (!groups[date]) {
      groups[date] = [];
    }
    groups[date].push(entry);
    return groups;
  }, {});

  // Sort days in ascending order (oldest to newest)
  const sortedDates = Object.keys(groupedEntries).sort((a, b) => 
    new Date(a).getTime() - new Date(b).getTime()
  );

  // Sort entries within each day in ascending order
  sortedDates.forEach(date => {
    groupedEntries[date].sort((a, b) => 
      new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
    );
  });

  const toggleDay = (date: string) => {
    setExpandedDays(prev => 
      prev.includes(date)
        ? prev.filter(d => d !== date)
        : [...prev, date]
    );
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <motion.button
            onClick={onBack}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="p-2 bg-white text-indigo-600 rounded-lg hover:bg-indigo-50 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </motion.button>
          <h2 className="text-2xl font-bold text-gray-800">{t('journal.history.title')}</h2>
        </div>
        <motion.button
          onClick={onBack}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="px-4 py-2 text-sm bg-white text-indigo-600 border border-indigo-200 rounded-lg hover:bg-indigo-50 transition-colors"
        >
          {t('journal.returnToJournal')}
        </motion.button>
      </div>

      <div className="space-y-4">
        {entries.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-gray-500">{t('journal.history.empty')}</p>
          </div>
        ) : (
          sortedDates.map((date) => {
            const isExpanded = expandedDays.includes(date);
            const formattedDate = format(new Date(date), 'MMMM d, yyyy');

            return (
              <motion.div
                key={date}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white rounded-lg shadow-md overflow-hidden"
              >
                <button
                  onClick={() => toggleDay(date)}
                  className="w-full px-6 py-4 flex items-center justify-between hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-indigo-50 rounded-lg">
                      <Clock className="w-4 h-4 text-indigo-600" />
                    </div>
                    <h3 className="font-semibold text-gray-900">{formattedDate}</h3>
                  </div>
                  {isExpanded ? (
                    <ChevronDown className="w-5 h-5 text-gray-400" />
                  ) : (
                    <ChevronRight className="w-5 h-5 text-gray-400" />
                  )}
                </button>

                <AnimatePresence>
                  {isExpanded && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                      className="overflow-hidden border-t border-gray-100"
                    >
                      <div className="divide-y divide-gray-100">
                        {groupedEntries[date].map((entry) => (
                          <div key={entry.id} className="p-6">
                            <h4 className="text-lg font-semibold text-gray-800 mb-3">
                              {t(entry.prompt)}
                            </h4>
                            <p className="text-gray-700 mb-4 whitespace-pre-wrap">
                              {entry.answer}
                            </p>
                            
                            {entry.ai_response && (
                              <div className="bg-indigo-50 rounded-lg p-4">
                                <div className="flex items-center text-indigo-600 mb-2">
                                  <MessageSquare className="w-4 h-4 mr-2" />
                                  <span className="font-medium">
                                    {t('journal.history.aiResponse')}
                                  </span>
                                </div>
                                <p className="text-gray-700 whitespace-pre-wrap">
                                  {entry.ai_response}
                                </p>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })
        )}
      </div>
    </div>
  );
};