import React from 'react';
import { motion } from 'framer-motion';
import { Trophy } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { AchievementBadge } from './AchievementBadge';

interface Achievement {
  id: string;
  name: string;
  description: string;
  category: string;
  points: number;
  icon_name: string;
  unlocked: boolean;
  unlocked_at?: string;
}

interface Props {
  achievements: Achievement[];
}

export const Achievements: React.FC<Props> = ({ achievements }) => {
  const { t } = useTranslation();
  const categories = Array.from(new Set(achievements.map(a => a.category)));

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex items-center space-x-3 mb-6">
        <Trophy className="w-6 h-6 text-indigo-600" />
        <h2 className="text-2xl font-bold text-gray-900">{t('achievements.title')}</h2>
      </div>

      <div className="space-y-8">
        {categories.map(category => (
          <motion.div
            key={category}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h3 className="text-lg font-semibold text-gray-800 mb-4 capitalize">
              {t(`achievements.categories.${category}`)}
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {achievements
                .filter(a => a.category === category)
                .map(achievement => (
                  <AchievementBadge
                    key={achievement.id}
                    name={achievement.name}
                    description={achievement.description}
                    iconName={achievement.icon_name}
                    points={achievement.points}
                    isUnlocked={achievement.unlocked}
                    unlockedAt={achievement.unlocked_at}
                  />
                ))}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};