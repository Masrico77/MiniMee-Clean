import React from 'react';
import { motion } from 'framer-motion';
import { MessageSquare } from 'lucide-react';

interface Props {
  onClick: () => void;
}

export const ChatButton: React.FC<Props> = ({ onClick }) => {
  return (
    <motion.button
      onClick={onClick}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      className="p-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-full shadow-lg hover:shadow-xl transition-all group relative"
      aria-label="Open chat"
    >
      <div className="relative">
        <MessageSquare className="w-6 h-6" />
        <div className="absolute right-full top-1/2 -translate-y-1/2 mr-3 px-3 py-2 bg-white text-gray-900 rounded-lg shadow-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none hidden md:block">
          <div className="text-sm font-medium">Chat with MiniMee</div>
          <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 rotate-45 w-2 h-2 bg-white"></div>
        </div>
      </div>
    </motion.button>
  );
};