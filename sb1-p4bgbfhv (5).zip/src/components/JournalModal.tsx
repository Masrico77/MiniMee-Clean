import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Loader, Sparkles, MessageSquare, X, ArrowRight, CheckCircle } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import type { JournalPrompt } from '../types';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  prompt: JournalPrompt;
  onSubmit: (answer: string) => Promise<void>;
  aiResponse: string;
  isLoading: boolean;
  currentPromptIndex: number;
  totalPrompts: number;
  onNextPrompt: () => void;
  onComplete: () => void;
  isCompleting: boolean;
}

export const JournalModal: React.FC<Props> = ({
  isOpen,
  onClose,
  prompt,
  onSubmit,
  aiResponse,
  isLoading,
  currentPromptIndex,
  totalPrompts,
  onNextPrompt,
  onComplete,
  isCompleting
}) => {
  const { t } = useTranslation();
  const [answer, setAnswer] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!answer.trim() || isLoading) return;
    
    await onSubmit(answer);
    setAnswer('');
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        >
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            className="bg-white rounded-2xl shadow-xl w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col"
          >
            {/* Header */}
            <div className="p-6 border-b border-gray-100 bg-gradient-to-r from-indigo-500 to-purple-500">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-white/10 rounded-lg">
                    <Sparkles className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h2 className="text-lg font-semibold text-white">
                      {t('journal.title')}
                    </h2>
                    <p className="text-sm text-white/80">
                      {t('journal.progress', { current: currentPromptIndex + 1, total: totalPrompts })}
                    </p>
                  </div>
                </div>
                <button
                  onClick={onClose}
                  className="p-2 hover:bg-white/10 rounded-lg transition-colors text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-2">
                <h3 className="text-xl text-white font-medium">{t(prompt.question)}</h3>
                <p className="text-white/90">{t(prompt.description)}</p>
              </div>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-6">
              {!aiResponse ? (
                <form onSubmit={handleSubmit}>
                  <textarea
                    value={answer}
                    onChange={(e) => setAnswer(e.target.value)}
                    placeholder={t('journal.writePlaceholder')}
                    className="w-full h-48 p-4 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent resize-none"
                    disabled={isLoading}
                  />
                  <div className="mt-4 flex justify-end">
                    <motion.button
                      type="submit"
                      disabled={isLoading || !answer.trim()}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                    >
                      {isLoading ? (
                        <>
                          <Loader className="w-4 h-4 animate-spin" />
                          {t('common.processing')}
                        </>
                      ) : (
                        <>
                          <Send className="w-4 h-4" />
                          {t('common.submit')}
                        </>
                      )}
                    </motion.button>
                  </div>
                </form>
              ) : (
                <div className="space-y-6">
                  <div className="flex items-center gap-2 text-indigo-600">
                    <MessageSquare className="w-5 h-5" />
                    <h3 className="font-medium">{t('journal.reflection.title')}</h3>
                  </div>
                  <p className="text-gray-700 whitespace-pre-wrap">{aiResponse}</p>
                  <div className="flex justify-end gap-4">
                    {currentPromptIndex < totalPrompts - 1 ? (
                      <motion.button
                        onClick={onNextPrompt}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
                      >
                        {t('common.next')}
                        <ArrowRight className="w-4 h-4" />
                      </motion.button>
                    ) : (
                      <motion.button
                        onClick={onComplete}
                        disabled={isCompleting}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50"
                      >
                        {isCompleting ? (
                          <>
                            <Loader className="w-4 h-4 animate-spin" />
                            {t('journal.completing')}
                          </>
                        ) : (
                          <>
                            <CheckCircle className="w-4 h-4" />
                            {t('journal.complete')}
                          </>
                        )}
                      </motion.button>
                    )}
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};