import React from 'react';
import { motion } from 'framer-motion';
import * as Icons from 'lucide-react';
import { useTranslation } from 'react-i18next';
import type { IconProps } from 'lucide-react';

interface Props {
  name: string;
  description: string;
  iconName: string;
  points: number;
  isUnlocked: boolean;
  unlockedAt?: string;
}

export const AchievementBadge: React.FC<Props> = ({
  name,
  description,
  iconName,
  points,
  isUnlocked,
  unlockedAt
}) => {
  const { t } = useTranslation();
  const Icon = (Icons as Record<string, React.FC<IconProps>>)[iconName] || Icons.Award;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className={`relative p-4 rounded-lg ${
        isUnlocked ? 'bg-gradient-to-br from-indigo-50 to-purple-50' : 'bg-gray-100'
      }`}
    >
      <div className="flex items-start space-x-4">
        <div
          className={`p-3 rounded-full ${
            isUnlocked ? 'bg-indigo-100 text-indigo-600' : 'bg-gray-200 text-gray-400'
          }`}
        >
          <Icon className="w-6 h-6" />
        </div>
        <div className="flex-1">
          <h3 className={`font-semibold ${isUnlocked ? 'text-gray-900' : 'text-gray-500'}`}>
            {t(`achievements.${name}`)}
          </h3>
          <p className={`text-sm ${isUnlocked ? 'text-gray-600' : 'text-gray-400'}`}>
            {t(`achievements.${description}`)}
          </p>
          {isUnlocked && unlockedAt && (
            <p className="text-xs text-indigo-600 mt-1">
              {t('achievements.unlockedOn', { date: new Date(unlockedAt).toLocaleDateString() })}
            </p>
          )}
        </div>
        <div className={`text-sm font-semibold ${isUnlocked ? 'text-indigo-600' : 'text-gray-400'}`}>
          {t('achievements.points', { count: points })}
        </div>
      </div>
      {!isUnlocked && (
        <div className="absolute inset-0 bg-gray-100/50 backdrop-blur-[1px] rounded-lg flex items-center justify-center">
          <div className="p-2 rounded-full bg-gray-200">
            <Icons.Lock className="w-4 h-4 text-gray-400" />
          </div>
        </div>
      )}
    </motion.div>
  );
};