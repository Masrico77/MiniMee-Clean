import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Brain, MessageSquare, BarChart as ChartBar, Calendar, ArrowRight, ArrowLeft } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { SmartJournalingIllustration } from './illustrations/SmartJournalingIllustration';
import { AIChatIllustration } from './illustrations/AIChatIllustration';
import { MilestonesIllustration } from './illustrations/MilestonesIllustration';
import { WeeklyInsightsIllustration } from './illustrations/WeeklyInsightsIllustration';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

const guideSteps = [
  {
    id: 'smart-journaling',
    translationKey: 'smartJournaling',
    illustration: SmartJournalingIllustration,
    icon: Brain
  },
  {
    id: 'ai-chat',
    translationKey: 'aiCompanion',
    illustration: AIChatIllustration,
    icon: MessageSquare
  },
  {
    id: 'milestones',
    translationKey: 'progress',
    illustration: MilestonesIllustration,
    icon: Calendar
  },
  {
    id: 'insights',
    translationKey: 'insights',
    illustration: WeeklyInsightsIllustration,
    icon: ChartBar
  }
];

export const GuideModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const { t } = useTranslation();
  const [currentStep, setCurrentStep] = useState(0);

  const nextStep = () => {
    setCurrentStep((prev) => Math.min(prev + 1, guideSteps.length - 1));
  };

  const prevStep = () => {
    setCurrentStep((prev) => Math.max(prev - 1, 0));
  };

  const currentGuideStep = guideSteps[currentStep];

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            onClick={(e) => e.stopPropagation()}
            className="bg-white w-full max-w-4xl rounded-2xl shadow-xl overflow-hidden"
          >
            {/* Header */}
            <div className="p-6 border-b border-gray-100 flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900">{t('guide.title')}</h2>
              <button
                onClick={onClose}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            {/* Content */}
            <div className="relative">
              <div className="grid grid-cols-1 md:grid-cols-2">
                {/* Illustration Section */}
                <div className="relative h-64 md:h-[500px] bg-gradient-to-br from-indigo-50 to-purple-50">
                  <motion.div
                    key={currentStep}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="absolute inset-0"
                  >
                    {React.createElement(currentGuideStep.illustration)}
                  </motion.div>
                </div>

                {/* Content Section */}
                <div className="p-8 flex flex-col justify-between bg-gradient-to-br from-indigo-50/50 to-purple-50/50">
                  <div>
                    <div className="flex items-center gap-3 mb-4">
                      <div className="p-3 bg-indigo-100 rounded-xl">
                        {React.createElement(currentGuideStep.icon, {
                          className: "w-6 h-6 text-indigo-600"
                        })}
                      </div>
                      <motion.h3
                        key={`title-${currentStep}`}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="text-2xl font-bold text-gray-900"
                      >
                        {t(`guide.steps.${currentGuideStep.translationKey}.title`)}
                      </motion.h3>
                    </div>

                    <motion.p
                      key={`description-${currentStep}`}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="text-gray-600 text-lg leading-relaxed mb-8"
                    >
                      {t(`guide.steps.${currentGuideStep.translationKey}.description`)}
                    </motion.p>

                    {/* Progress Indicators */}
                    <div className="flex gap-2 mb-8">
                      {guideSteps.map((_, index) => (
                        <div
                          key={index}
                          className={`h-1 rounded-full flex-1 transition-colors ${
                            index === currentStep
                              ? 'bg-indigo-600'
                              : index < currentStep
                              ? 'bg-indigo-200'
                              : 'bg-gray-200'
                          }`}
                        />
                      ))}
                    </div>
                  </div>

                  {/* Navigation */}
                  <div className="flex justify-between items-center">
                    <button
                      onClick={prevStep}
                      disabled={currentStep === 0}
                      className="flex items-center gap-2 px-4 py-2 text-gray-600 hover:text-gray-900 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                    >
                      <ArrowLeft className="w-4 h-4" />
                      {t('guide.previous')}
                    </button>

                    {currentStep < guideSteps.length - 1 ? (
                      <button
                        onClick={nextStep}
                        className="flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
                      >
                        {t('guide.next')}
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    ) : (
                      <button
                        onClick={onClose}
                        className="flex items-center gap-2 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                      >
                        {t('guide.getStarted')}
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};