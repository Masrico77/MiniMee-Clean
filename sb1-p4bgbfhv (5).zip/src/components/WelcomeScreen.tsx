import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Brain, Sparkles, MessageSquare, Shield, Lock, Star, PlayCircle } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { GuideModal } from './GuideModal';

export const WelcomeScreen: React.FC = () => {
  const { t } = useTranslation();
  const [showGuide, setShowGuide] = useState(false);

  return (
    <div className="max-w-4xl mx-auto text-center mb-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-12"
      >
        {/* Hero Section */}
        <div>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            {t('welcome.hero.title')}
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-purple-600">
              {' '}MiniMee
            </span>
            <span className="block text-3xl md:text-4xl mt-2 text-gray-800">
              {t('welcome.hero.subtitle')}
            </span>
          </h1>
          <div className="max-w-3xl mx-auto">
            <p className="text-xl text-gray-700 leading-relaxed mb-8">
              {t('welcome.hero.description')}
            </p>
            <motion.button
              onClick={() => setShowGuide(true)}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl shadow-lg hover:shadow-xl transition-all text-lg font-medium"
            >
              <PlayCircle className="w-6 h-6" />
              {t('welcome.seeHowItWorks')}
            </motion.button>
          </div>
        </div>

        {/* Stats Section */}
        <div>
          <h2 className="text-2xl font-bold text-gray-900 mb-6">{t('welcome.stats.title')}</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <motion.div
              whileHover={{ y: -5 }}
              className="p-6 bg-white/80 backdrop-blur-sm rounded-xl shadow-sm border border-gray-100"
            >
              <div className="text-3xl font-bold text-indigo-600 mb-2">{t('welcome.stats.clarity.value')}</div>
              <p className="text-gray-600">
                {t('welcome.stats.clarity.text')}
              </p>
            </motion.div>

            <motion.div
              whileHover={{ y: -5 }}
              className="p-6 bg-white/80 backdrop-blur-sm rounded-xl shadow-sm border border-gray-100"
            >
              <div className="text-3xl font-bold text-purple-600 mb-2">{t('welcome.stats.awareness.value')}</div>
              <p className="text-gray-600">
                {t('welcome.stats.awareness.text')}
              </p>
            </motion.div>

            <motion.div
              whileHover={{ y: -5 }}
              className="p-6 bg-white/80 backdrop-blur-sm rounded-xl shadow-sm border border-gray-100"
            >
              <div className="text-3xl font-bold text-pink-600 mb-2">{t('welcome.stats.growth.value')}</div>
              <p className="text-gray-600">
                {t('welcome.stats.growth.text')}
              </p>
            </motion.div>
          </div>
        </div>

        {/* Features Section */}
        <div>
          <h2 className="text-2xl font-bold text-gray-900 mb-6">{t('welcome.features.title')}</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <motion.div
              whileHover={{ y: -5 }}
              className="p-6 bg-white/90 backdrop-blur-sm rounded-xl shadow-sm"
            >
              <div className="bg-indigo-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
                <Brain className="w-6 h-6 text-indigo-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">{t('welcome.features.reflection.title')}</h3>
              <p className="text-gray-600 text-sm">
                {t('welcome.features.reflection.description')}
              </p>
            </motion.div>

            <motion.div
              whileHover={{ y: -5 }}
              className="p-6 bg-white/90 backdrop-blur-sm rounded-xl shadow-sm"
            >
              <div className="bg-purple-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
                <Sparkles className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">{t('welcome.features.growth.title')}</h3>
              <p className="text-gray-600 text-sm">
                {t('welcome.features.growth.description')}
              </p>
            </motion.div>

            <motion.div
              whileHover={{ y: -5 }}
              className="p-6 bg-white/90 backdrop-blur-sm rounded-xl shadow-sm"
            >
              <div className="bg-pink-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
                <MessageSquare className="w-6 h-6 text-pink-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">{t('welcome.features.dialogue.title')}</h3>
              <p className="text-gray-600 text-sm">
                {t('welcome.features.dialogue.description')}
              </p>
            </motion.div>
          </div>
        </div>

        {/* Privacy Section */}
        <div>
          <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white p-6 rounded-xl shadow-lg mb-6">
            <div className="flex items-center justify-center gap-3 mb-4">
              <Shield className="w-8 h-8" />
              <h3 className="text-2xl font-bold">{t('welcome.privacy.title')}</h3>
            </div>
            <p className="text-lg">
              {t('welcome.privacy.description')}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-4 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-lg">
              <Lock className="w-5 h-5 text-indigo-600 mb-2 mx-auto" />
              <h3 className="font-medium text-gray-900 mb-1">{t('welcome.privacy.features.security.title')}</h3>
              <p className="text-sm text-gray-600">
                {t('welcome.privacy.features.security.description')}
              </p>
            </div>
            <div className="p-4 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-lg">
              <Brain className="w-5 h-5 text-indigo-600 mb-2 mx-auto" />
              <h3 className="font-medium text-gray-900 mb-1">{t('welcome.privacy.features.growth.title')}</h3>
              <p className="text-sm text-gray-600">
                {t('welcome.privacy.features.growth.description')}
              </p>
            </div>
            <div className="p-4 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-lg">
              <MessageSquare className="w-5 h-5 text-indigo-600 mb-2 mx-auto" />
              <h3 className="font-medium text-gray-900 mb-1">{t('welcome.privacy.features.conversations.title')}</h3>
              <p className="text-sm text-gray-600">
                {t('welcome.privacy.features.conversations.description')}
              </p>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="bg-white/90 backdrop-blur-sm rounded-xl p-8 shadow-lg border border-indigo-50">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">{t('welcome.cta.title')}</h2>
          <p className="text-gray-600 mb-6">
            {t('welcome.cta.description')}
          </p>
          <motion.a
            href="#login"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="inline-flex items-center px-6 py-3 rounded-lg text-white bg-gradient-to-r from-indigo-600 to-purple-600 font-medium shadow-lg hover:shadow-xl transition-all"
          >
            {t('welcome.cta.button')}
            <Star className="w-4 h-4 ml-2" />
          </motion.a>
        </div>
      </motion.div>

      <GuideModal isOpen={showGuide} onClose={() => setShowGuide(false)} />
    </div>
  );
};