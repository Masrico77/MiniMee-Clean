import React from 'react';
import { motion } from 'framer-motion';
import type { LucideIcon } from 'lucide-react';
import { GRADIENT_BUTTON_VARIANTS, MOTION_VARIANTS, COMPONENT_STYLES } from '../constants/designTokens';

interface GradientButtonProps {
  onClick: () => void;
  variant: keyof typeof GRADIENT_BUTTON_VARIANTS;
  icon: LucideIcon;
  title: string;
  description: string;
}

export const GradientButton: React.FC<GradientButtonProps> = ({
  onClick,
  variant,
  icon: Icon,
  title,
  description
}) => {
  const styles = GRADIENT_BUTTON_VARIANTS[variant];
  const { gradientButton: buttonStyles } = COMPONENT_STYLES;

  return (
    <motion.button
      onClick={onClick}
      whileHover={MOTION_VARIANTS.buttonHover}
      whileTap={MOTION_VARIANTS.buttonTap}
      className={buttonStyles.base}
    >
      <div className={`${buttonStyles.container} bg-gradient-to-br ${styles.gradient} ${styles.hoverShadow}`}>
        <div className={`${buttonStyles.overlay} ${styles.skewDirection} ${styles.hoverSkew}`} />
        <div className={buttonStyles.content}>
          <div className={buttonStyles.iconContainer}>
            <Icon className={buttonStyles.icon} />
          </div>
          <div className={buttonStyles.textContainer}>
            <h3 className={buttonStyles.title}>{title}</h3>
            <p className={buttonStyles.description}>{description}</p>
          </div>
        </div>
      </div>
    </motion.button>
  );
}