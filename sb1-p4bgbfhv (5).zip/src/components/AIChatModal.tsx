import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Send, Bot, Loader, Clock, ChevronLeft, Brain, Sparkles, Shield, MessageCircle } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { getChatResponse } from '../services/openai';
import { saveChatMessage, getChatHistory, getConversation } from '../services/chat';
import { format } from 'date-fns';
import type { Message, ChatConversation } from '../types';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
}

export const AIChatModal: React.FC<Props> = ({ isOpen, onClose, userId }) => {
  const { t } = useTranslation();
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content: t('chat.welcome')
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [currentConversationId, setCurrentConversationId] = useState<string | null>(null);
  const [conversations, setConversations] = useState<ChatConversation[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      loadChatHistory();
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
    }
  }, [isOpen]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    setMessages([{
      role: 'assistant',
      content: t('chat.welcome')
    }]);
  }, [t]);

  useEffect(() => {
    const handleResize = () => {
      if (chatContainerRef.current && window.visualViewport) {
        const viewport = window.visualViewport;
        chatContainerRef.current.style.height = `${viewport.height}px`;
      }
    };

    window.visualViewport?.addEventListener('resize', handleResize);
    window.visualViewport?.addEventListener('scroll', handleResize);

    return () => {
      window.visualViewport?.removeEventListener('resize', handleResize);
      window.visualViewport?.removeEventListener('scroll', handleResize);
    };
  }, []);

  const loadChatHistory = async () => {
    try {
      const history = await getChatHistory(userId);
      setConversations(history);
    } catch (error) {
      console.error('Error loading chat history:', error);
    }
  };

  const loadConversation = async (conversationId: string) => {
    try {
      const messages = await getConversation(conversationId);
      setMessages(messages);
      setCurrentConversationId(conversationId);
      setShowHistory(false);
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
    } catch (error) {
      console.error('Error loading conversation:', error);
    }
  };

  const startNewChat = () => {
    setMessages([{
      role: 'assistant',
      content: t('chat.welcome')
    }]);
    setCurrentConversationId(null);
    setShowHistory(false);
    setTimeout(() => {
      inputRef.current?.focus();
    }, 100);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setIsLoading(true);

    try {
      // Save user message
      const { conversationId } = await saveChatMessage(
        userId,
        currentConversationId,
        'user',
        userMessage
      );
      setCurrentConversationId(conversationId);

      // Get AI response with user context
      const response = await getChatResponse(userMessage, userMessage, userId);
      
      // Save AI response
      await saveChatMessage(userId, conversationId, 'assistant', response);
      
      setMessages(prev => [...prev, { role: 'assistant', content: response }]);
      loadChatHistory(); // Refresh history
    } catch (error) {
      console.error('Error in chat:', error);
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: t('chat.error')
      }]);
    } finally {
      setIsLoading(false);
      inputRef.current?.focus();
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center"
          onClick={onClose}
        >
          <motion.div
            ref={chatContainerRef}
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            onClick={e => e.stopPropagation()}
            className="bg-white w-full h-full sm:h-[600px] sm:w-full sm:max-w-2xl sm:rounded-2xl shadow-xl flex flex-col overflow-hidden"
          >
            {/* Header */}
            <div className="p-4 sm:p-6 border-b border-gray-100 bg-gradient-to-r from-indigo-500 to-purple-500 shrink-0">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  {showHistory ? (
                    <>
                      <Clock className="w-6 h-6 text-white" />
                      <h2 className="text-lg font-semibold text-white">{t('chat.history')}</h2>
                    </>
                  ) : (
                    <>
                      <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center">
                        <Brain className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h2 className="text-lg font-semibold text-white">{t('chat.title')}</h2>
                        <p className="text-sm text-white/80">{t('chat.subtitle')}</p>
                      </div>
                    </>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setShowHistory(!showHistory)}
                    className="p-2 hover:bg-white/10 rounded-lg transition-colors text-white"
                    aria-label={showHistory ? t('common.back') : t('chat.history')}
                  >
                    {showHistory ? <ChevronLeft className="w-5 h-5" /> : <Clock className="w-5 h-5" />}
                  </button>
                  <button
                    onClick={onClose}
                    className="p-2 hover:bg-white/10 rounded-lg transition-colors text-white"
                    aria-label={t('common.close')}
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>
              {!showHistory && (
                <div className="flex items-center gap-2 text-white/90 text-sm bg-white/10 p-2 rounded-lg">
                  <Shield className="w-4 h-4 flex-shrink-0" />
                  <span>{t('chat.privacy')}</span>
                </div>
              )}
            </div>

            {showHistory ? (
              // Chat History View
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                <button
                  onClick={startNewChat}
                  className="w-full p-3 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-600 font-medium transition-colors text-left flex items-center gap-2"
                >
                  <Brain className="w-5 h-5" />
                  {t('chat.newChat')}
                </button>
                
                {conversations.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 text-center">
                    <div className="w-16 h-16 bg-indigo-50 rounded-full flex items-center justify-center mb-4">
                      <MessageCircle className="w-8 h-8 text-indigo-400" />
                    </div>
                    <h3 className="text-lg font-medium text-gray-900 mb-2">
                      {t('chat.noHistory')}
                    </h3>
                    <p className="text-sm text-gray-600 max-w-sm mx-auto">
                      {t('chat.startNewChat')}
                    </p>
                  </div>
                ) : (
                  conversations.map((conversation) => (
                    <button
                      key={conversation.id}
                      onClick={() => loadConversation(conversation.id)}
                      className="w-full p-3 rounded-xl bg-gray-50 hover:bg-gray-100 transition-colors text-left"
                    >
                      <div className="flex justify-between items-center mb-1">
                        <span className="font-medium text-gray-900 line-clamp-1">
                          {conversation.chat_messages[0]?.content}
                        </span>
                        <span className="text-sm text-gray-500 flex-shrink-0 ml-2">
                          {format(new Date(conversation.created_at), 'MMM d, yyyy')}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600">
                        {t('chat.messages', { count: conversation.chat_messages.length })}
                      </p>
                    </button>
                  ))
                )}
              </div>
            ) : (
              // Chat View
              <>
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {messages.map((message, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-[85%] sm:max-w-[75%] p-3 rounded-2xl ${
                          message.role === 'user'
                            ? 'bg-indigo-600 text-white rounded-tr-none'
                            : 'bg-gray-100 text-gray-800 rounded-tl-none'
                        }`}
                      >
                        <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                      </div>
                    </motion.div>
                  ))}
                  {isLoading && (
                    <div className="flex justify-start">
                      <div className="bg-gray-100 p-3 rounded-2xl rounded-tl-none">
                        <Loader className="w-5 h-5 animate-spin text-gray-600" />
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>

                <form onSubmit={handleSubmit} className="p-4 border-t border-gray-100 bg-white shrink-0">
                  <div className="relative flex items-center">
                    <input
                      ref={inputRef}
                      type="text"
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      placeholder={t('chat.placeholder')}
                      className="w-full px-4 py-3 pr-12 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                      disabled={isLoading}
                    />
                    <motion.button
                      type="submit"
                      disabled={!input.trim() || isLoading}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="absolute right-2 p-2 bg-indigo-600 text-white rounded-lg disabled:opacity-50 disabled:cursor-not-allowed"
                      aria-label={t('common.submit')}
                    >
                      <Send className="w-5 h-5" />
                    </motion.button>
                  </div>
                </form>
              </>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};