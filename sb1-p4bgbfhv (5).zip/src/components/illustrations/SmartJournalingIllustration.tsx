import React from 'react';
import { Brain } from 'lucide-react';

export const SmartJournalingIllustration: React.FC = () => {
  return (
    <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-indigo-600/5 to-purple-600/5">
      <div className="relative w-96 h-96">
        {/* Central Brain Icon */}
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
          <div className="relative animate-float">
            {/* Outer Glow */}
            <div className="absolute inset-0 rounded-full bg-gradient-to-r from-indigo-500 to-purple-500 blur-xl opacity-20 scale-150 animate-pulse-slow" />
            {/* Icon Container */}
            <div className="relative w-32 h-32 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-2xl rotate-3 flex items-center justify-center shadow-xl">
              <Brain className="w-16 h-16 text-white animate-pulse-slow" />
            </div>
          </div>
        </div>

        {/* Floating Particles */}
        {[...Array(12)].map((_, i) => (
          <div
            key={`particle-${i}`}
            className="absolute w-2 h-2 rounded-full bg-gradient-to-r from-indigo-400 to-purple-400 animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 2}s`
            }}
          />
        ))}
      </div>
    </div>
  );
};