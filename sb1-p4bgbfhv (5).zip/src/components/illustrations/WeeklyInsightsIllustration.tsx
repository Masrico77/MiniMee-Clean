import React from 'react';
import { BarChart, TrendingUp, Brain, LineChart } from 'lucide-react';

export const WeeklyInsightsIllustration: React.FC = () => {
  return (
    <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-indigo-600/5 to-purple-600/5">
      <div className="relative w-96 h-96">
        {/* Central Chart */}
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
          <div className="relative animate-float">
            {/* Background Glow */}
            <div className="absolute inset-0 bg-gradient-to-r from-indigo-500 to-purple-500 blur-xl opacity-20 animate-pulse-slow" />
            
            {/* Chart Container */}
            <div className="relative w-64 h-48 bg-white rounded-xl shadow-xl p-4">
              {/* Chart Bars */}
              <div className="h-full flex items-end justify-between gap-2">
                {[0.4, 0.6, 0.3, 0.8, 0.5, 0.7, 0.9].map((height, index) => (
                  <div
                    key={index}
                    className="w-6 bg-gradient-to-t from-indigo-600 to-purple-600 rounded-t-lg animate-float"
                    style={{ 
                      height: `${height * 100}%`,
                      animationDelay: `${index * 0.1}s`
                    }}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Floating Elements */}
        <div className="absolute inset-0">
          {/* Brain Icon */}
          <div className="absolute top-12 left-12 animate-float" style={{ animationDelay: '0.2s' }}>
            <div className="w-16 h-16 bg-white rounded-xl shadow-lg flex items-center justify-center">
              <Brain className="w-8 h-8 text-indigo-600 animate-pulse-slow" />
            </div>
          </div>

          {/* Line Chart */}
          <div className="absolute top-12 right-12 animate-float" style={{ animationDelay: '0.4s' }}>
            <div className="w-16 h-16 bg-white rounded-xl shadow-lg flex items-center justify-center">
              <LineChart className="w-8 h-8 text-purple-600 animate-pulse-slow" />
            </div>
          </div>

          {/* Trending Icon */}
          <div className="absolute bottom-12 left-12 animate-float" style={{ animationDelay: '0.6s' }}>
            <div className="w-16 h-16 bg-white rounded-xl shadow-lg flex items-center justify-center">
              <TrendingUp className="w-8 h-8 text-indigo-600 animate-pulse-slow" />
            </div>
          </div>

          {/* Bar Chart */}
          <div className="absolute bottom-12 right-12 animate-float" style={{ animationDelay: '0.8s' }}>
            <div className="w-16 h-16 bg-white rounded-xl shadow-lg flex items-center justify-center">
              <BarChart className="w-8 h-8 text-purple-600 animate-pulse-slow" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};