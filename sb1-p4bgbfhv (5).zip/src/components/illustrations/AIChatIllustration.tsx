import React from 'react';
import { MessageSquare, Sparkles, Brain } from 'lucide-react';

export const AIChatIllustration: React.FC = () => {
  return (
    <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-indigo-600/5 to-purple-600/5">
      <div className="relative w-96 h-96">
        {/* Chat Bubbles */}
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-sm">
          {/* AI Message */}
          <div className="relative mb-4 transform -translate-x-12 animate-float" style={{ animationDelay: '0.5s' }}>
            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-4 rounded-2xl rounded-tl-none text-white shadow-lg">
              <div className="flex items-center gap-2">
                <Brain className="w-5 h-5 animate-pulse-slow" />
                <span className="text-sm">AI Response</span>
              </div>
            </div>
            <div className="absolute -left-2 -top-2">
              <Sparkles className="w-4 h-4 text-indigo-400 animate-pulse-slow" />
            </div>
          </div>

          {/* User Message */}
          <div className="relative transform translate-x-12 animate-float">
            <div className="bg-white p-4 rounded-2xl rounded-tr-none shadow-lg">
              <div className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-indigo-600 animate-pulse-slow" />
                <span className="text-sm text-gray-600">Your Message</span>
              </div>
            </div>
            <div className="absolute -right-2 -top-2">
              <Sparkles className="w-4 h-4 text-purple-400 animate-pulse-slow" />
            </div>
          </div>
        </div>

        {/* Floating Particles */}
        {[...Array(12)].map((_, i) => (
          <div
            key={`particle-${i}`}
            className="absolute w-2 h-2 rounded-full bg-gradient-to-r from-indigo-400 to-purple-400 animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 2}s`
            }}
          />
        ))}
      </div>
    </div>
  );
};