import React from 'react';
import { Trophy, Star, Target, Crown } from 'lucide-react';

export const MilestonesIllustration: React.FC = () => {
  return (
    <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-indigo-600/5 to-purple-600/5">
      <div className="relative w-96 h-96">
        {/* Achievement Podium */}
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 flex items-end gap-4">
          {/* Second Place */}
          <div className="relative animate-float" style={{ animationDelay: '0.2s' }}>
            <div className="w-24 h-32 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-t-lg shadow-lg flex flex-col items-center justify-end pb-4">
              <div className="absolute -top-8">
                <div className="w-16 h-16 bg-white rounded-full shadow-lg flex items-center justify-center">
                  <Star className="w-8 h-8 text-indigo-600 animate-pulse-slow" />
                </div>
              </div>
              <span className="text-2xl font-bold text-indigo-600">2</span>
            </div>
          </div>

          {/* First Place */}
          <div className="relative animate-float">
            <div className="w-24 h-40 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-t-lg shadow-lg flex flex-col items-center justify-end pb-4">
              <div className="absolute -top-8">
                <div className="w-16 h-16 bg-white rounded-full shadow-lg flex items-center justify-center">
                  <Trophy className="w-8 h-8 text-indigo-600 animate-pulse-slow" />
                </div>
              </div>
              <span className="text-2xl font-bold text-white">1</span>
            </div>
          </div>

          {/* Third Place */}
          <div className="relative animate-float" style={{ animationDelay: '0.4s' }}>
            <div className="w-24 h-24 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-t-lg shadow-lg flex flex-col items-center justify-end pb-4">
              <div className="absolute -top-8">
                <div className="w-16 h-16 bg-white rounded-full shadow-lg flex items-center justify-center">
                  <Target className="w-8 h-8 text-indigo-600 animate-pulse-slow" />
                </div>
              </div>
              <span className="text-2xl font-bold text-indigo-600">3</span>
            </div>
          </div>
        </div>

        {/* Floating Stars */}
        {[...Array(12)].map((_, i) => (
          <div
            key={i}
            className="absolute animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 2}s`
            }}
          >
            <Star className="w-4 h-4 text-indigo-400 animate-pulse-slow" />
          </div>
        ))}
      </div>
    </div>
  );
};