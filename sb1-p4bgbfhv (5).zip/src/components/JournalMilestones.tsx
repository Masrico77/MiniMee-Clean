import React from 'react';
import { motion } from 'framer-motion';
import { Calendar, CheckCircle, Star } from 'lucide-react';

interface Props {
  totalEntries: number;
  currentStreak: number;
  lastEntryDate: string | null;
}

export const JournalMilestones: React.FC<Props> = ({ totalEntries, currentStreak, lastEntryDate }) => {
  const milestones = [
    { icon: Calendar, label: 'Streak', value: `${currentStreak}d` },
    { icon: CheckCircle, label: 'Entries', value: totalEntries },
    { icon: Star, label: 'Last', value: lastEntryDate ? new Date(lastEntryDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : '-' },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-4xl mx-auto mb-6"
    >
      <div className="bg-white/90 backdrop-blur-md shadow-sm rounded-lg px-4 py-2 flex items-center justify-center gap-8 border border-indigo-50">
        {milestones.map(({ icon: Icon, label, value }, index) => (
          <React.Fragment key={label}>
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-indigo-50 rounded-lg">
                <Icon className="w-3.5 h-3.5 text-indigo-600" />
              </div>
              <div className="flex items-baseline gap-1.5">
                <span className="text-xs text-gray-500">{label}</span>
                <span className="text-sm font-medium text-gray-900">{value}</span>
              </div>
            </div>
            {index < milestones.length - 1 && (
              <div className="w-px h-4 bg-gray-200" />
            )}
          </React.Fragment>
        ))}
      </div>
    </motion.div>
  );
};