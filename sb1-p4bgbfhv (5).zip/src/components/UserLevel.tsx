import React from 'react';
import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import * as Icons from 'lucide-react';
import type { IconProps } from 'lucide-react';

interface Props {
  level: number;
  title: string;
  points: number;
  nextLevelPoints: number;
  iconName: string;
  colorScheme: string;
}

export const UserLevel: React.FC<Props> = ({
  level,
  title,
  points,
  nextLevelPoints,
  iconName,
  colorScheme
}) => {
  const { t } = useTranslation();
  const Icon = (Icons as Record<string, React.FC<IconProps>>)[iconName] || Icons.Award;
  const progress = (points / nextLevelPoints) * 100;

  const getColorClasses = (scheme: string) => {
    const colors = {
      gray: 'from-gray-500 to-gray-600',
      blue: 'from-blue-500 to-blue-600',
      green: 'from-green-500 to-green-600',
      purple: 'from-purple-500 to-purple-600',
      gold: 'from-yellow-500 to-amber-600'
    };
    return colors[scheme as keyof typeof colors] || colors.gray;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-lg shadow-lg p-6"
    >
      <div className="flex items-center space-x-4 mb-4">
        <div className={`p-3 rounded-full bg-gradient-to-br ${getColorClasses(colorScheme)}`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
        <div>
          <h3 className="text-xl font-bold text-gray-900">{t(title)}</h3>
          <p className="text-sm text-gray-600">{t('status.level', { level })}</p>
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-gray-600">{t('status.points', { count: points })}</span>
          <span className="text-gray-600">{t('status.points', { count: nextLevelPoints })}</span>
        </div>
        <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 1, ease: "easeOut" }}
            className={`h-full bg-gradient-to-r ${getColorClasses(colorScheme)}`}
          />
        </div>
        <p className="text-xs text-gray-500 text-center">
          {t('status.pointsUntilNext', { count: nextLevelPoints - points })}
        </p>
      </div>
    </motion.div>
  );
};