// Button variants and styles
export const GRADIENT_BUTTON_VARIANTS = {
  primary: {
    gradient: 'from-indigo-500 via-indigo-600 to-purple-600',
    hoverShadow: 'hover:shadow-xl',
    skewDirection: '-skew-y-12',
    hoverSkew: 'group-hover:skew-y-12'
  },
  secondary: {
    gradient: 'from-purple-500 via-fuchsia-600 to-pink-600',
    hoverShadow: 'hover:shadow-xl',
    skewDirection: 'skew-y-12',
    hoverSkew: 'group-hover:-skew-y-12'
  }
} as const;

// Common animation variants
export const MOTION_VARIANTS = {
  buttonHover: {
    scale: 1.02,
    transition: { duration: 0.2 }
  },
  buttonTap: {
    scale: 0.98,
    transition: { duration: 0.1 }
  }
} as const;

// Common component styles
export const COMPONENT_STYLES = {
  gradientButton: {
    base: 'relative group overflow-hidden',
    container: 'p-6 sm:p-8 rounded-2xl shadow-lg transition-all',
    overlay: 'absolute inset-0 bg-white/5 transform transition-transform duration-700 ease-out',
    content: 'relative flex flex-col items-center text-white space-y-4',
    iconContainer: 'p-3 bg-white/10 rounded-xl',
    icon: 'w-8 h-8',
    textContainer: 'text-center',
    title: 'text-xl sm:text-2xl font-bold mb-2',
    description: 'text-white/80 text-sm sm:text-base'
  }
} as const;