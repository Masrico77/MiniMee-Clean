import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { Configuration, OpenAIApi } from 'https://esm.sh/openai@3.1.0'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

// Helper to create error response
function createErrorResponse(message: string, status = 500) {
  return new Response(
    JSON.stringify({ 
      error: message,
      response: "I apologize, but I'm having trouble processing your request right now. Please try again in a moment." 
    }),
    {
      status,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json',
      },
    }
  );
}

// Format journal entries for context
function formatJournalContext(entries: any[]): string {
  if (!entries?.length) return '';

  let context = "Previous Journal Entries:\n\n";
  entries.forEach((entry, index) => {
    const date = new Date(entry.created_at).toLocaleDateString();
    context += `Entry ${entries.length - index} [${date}]:\n`;
    context += `Question: ${entry.prompt}\n`;
    context += `Response: ${entry.answer}\n`;
    context += `Emotional Themes: ${extractEmotionalThemes(entry.answer)}\n`;
    context += `AI Analysis: ${entry.ai_response}\n\n`;
  });
  return context;
}

// Format chat history for context
function formatChatContext(messages: any[]): string {
  if (!messages?.length) return '';

  let context = "Recent Chat History:\n\n";
  messages.forEach((msg, index) => {
    const date = new Date(msg.created_at).toLocaleDateString();
    context += `[${date}] ${msg.role === 'user' ? 'User' : 'Assistant'}: ${msg.content}\n`;
  });
  return context + '\n';
}

// Extract emotional themes from text
function extractEmotionalThemes(text: string): string {
  const emotionalKeywords = {
    joy: ['happy', 'excited', 'grateful', 'love', 'wonderful', 'amazing'],
    sadness: ['sad', 'disappointed', 'hurt', 'lonely', 'depressed'],
    anger: ['angry', 'frustrated', 'annoyed', 'upset'],
    fear: ['afraid', 'worried', 'anxious', 'nervous'],
    hope: ['hopeful', 'optimistic', 'looking forward', 'excited about'],
    growth: ['learning', 'improving', 'growing', 'developing', 'progress']
  };

  const themes = new Set<string>();
  const lowercaseText = text.toLowerCase();

  Object.entries(emotionalKeywords).forEach(([theme, keywords]) => {
    if (keywords.some(keyword => lowercaseText.includes(keyword))) {
      themes.add(theme);
    }
  });

  return themes.size ? Array.from(themes).join(', ') : 'neutral';
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return createErrorResponse('Missing Authorization header', 401);
    }

    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: authHeader },
        },
      }
    );

    const {
      data: { user },
      error: authError,
    } = await supabaseClient.auth.getUser();

    if (authError || !user) {
      return createErrorResponse('Unauthorized', 401);
    }

    const { prompt, answer, type = 'journal' } = await req.json();

    // Get comprehensive user context
    const [journalEntries, chatMessages, userStats] = await Promise.all([
      // Get recent journal entries
      supabaseClient
        .from('journal_entries')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(10),

      // Get recent chat history
      supabaseClient
        .from('chat_messages')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(10),

      // Get user stats
      supabaseClient
        .from('user_stats')
        .select('*')
        .eq('user_id', user.id)
        .single()
    ]);

    // Build comprehensive context
    let context = "User Context:\n\n";
    
    // Add user stats context
    if (userStats.data) {
      context += "User Progress:\n";
      context += `Total Entries: ${userStats.data.total_entries}\n`;
      context += `Current Streak: ${userStats.data.current_streak} days\n`;
      context += `Writing Style: ${userStats.data.total_words / userStats.data.total_entries} words per entry average\n\n`;
    }

    // Add journal history context
    if (journalEntries.data?.length) {
      context += formatJournalContext(journalEntries.data);
    }

    // Add chat history context for chat interactions
    if (type === 'chat' && chatMessages.data?.length) {
      context += formatChatContext(chatMessages.data);
    }

    // Initialize OpenAI
    const configuration = new Configuration({
      apiKey: Deno.env.get('OPENAI_API_KEY'),
    });
    const openai = new OpenAIApi(configuration);

    // Create system prompt based on context
    const systemPrompt = type === 'journal'
      ? `You are MiniMee, an AI journaling companion focused on personal growth and emotional intelligence. 
         Use the user's journal history to provide personalized, insightful responses that:
         1. Identify patterns and themes in their emotional journey
         2. Acknowledge progress and growth
         3. Offer thoughtful perspectives and gentle guidance
         4. Maintain absolute privacy (never ask for or store personal details)
         5. Adapt your tone and approach based on their writing style and emotional state

         Remember previous interactions to provide continuity in the conversation.
         Focus on emotional themes and personal growth while maintaining privacy.`
      : `You are MiniMee, a thoughtful chat companion focused on personal growth.
         Use the chat history and journal entries to:
         1. Maintain conversation continuity
         2. Reference relevant past insights
         3. Provide personalized guidance
         4. Keep privacy as the highest priority
         5. Adapt your responses based on their emotional state and progress

         Never ask for personal identifying information.
         Focus on emotional well-being and growth while maintaining strict privacy.`;

    // Get AI response
    const completion = await openai.createChatCompletion({
      model: "gpt-4",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: `${context}\nCurrent Input:\n${prompt}\n\nUser's Response: ${answer}` }
      ],
      temperature: 0.7,
      max_tokens: 750,
    });

    const aiResponse = completion.data.choices[0]?.message?.content || 
                      "Thank you for sharing your thoughts.";

    return new Response(
      JSON.stringify({ response: aiResponse }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error) {
    console.error('Error:', error);
    return createErrorResponse(
      'An unexpected error occurred. Please try again later.',
      500
    );
  }
});