-- Function to check if a journal entry is complete for a given date
CREATE OR REPLACE FUNCTION is_day_complete(
  p_user_id uuid,
  p_date date
) RETURNS boolean AS $$
DECLARE
  v_completed_count integer;
BEGIN
  SELECT COUNT(*)
  INTO v_completed_count
  FROM journal_entries
  WHERE user_id = p_user_id
    AND DATE(created_at) = p_date
    AND completed = true;

  RETURN v_completed_count > 0;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to get the last completed date
CREATE OR REPLACE FUNCTION get_last_completed_date(p_user_id uuid)
RETURNS date AS $$
DECLARE
  v_last_date date;
BEGIN
  SELECT DATE(MAX(created_at))
  INTO v_last_date
  FROM journal_entries
  WHERE user_id = p_user_id
    AND completed = true;
  
  RETURN v_last_date;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Updated streak calculation function
CREATE OR REPLACE FUNCTION calculate_current_streak(p_user_id uuid)
RETURNS integer AS $$
DECLARE
  v_current_date date := CURRENT_DATE;
  v_check_date date;
  v_streak integer := 0;
  v_last_completed_date date;
BEGIN
  -- Get the last completed date
  v_last_completed_date := get_last_completed_date(p_user_id);
  
  -- If no completed entries or last completion was more than a day ago, return 0
  IF v_last_completed_date IS NULL OR 
     v_last_completed_date < v_current_date - interval '1 day' THEN
    RETURN 0;
  END IF;

  -- Start checking from the last completed date
  v_check_date := v_last_completed_date;
  
  -- Count consecutive days backwards
  WHILE is_day_complete(p_user_id, v_check_date) LOOP
    v_streak := v_streak + 1;
    v_check_date := v_check_date - interval '1 day';
  END LOOP;

  RETURN v_streak;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to update only streak-related fields
CREATE OR REPLACE FUNCTION update_streak_only(p_user_id uuid)
RETURNS void AS $$
DECLARE
  v_current_streak integer;
  v_stats record;
BEGIN
  -- Get current stats
  SELECT current_streak, longest_streak
  INTO v_stats
  FROM user_stats
  WHERE user_id = p_user_id;

  -- Calculate new streak
  v_current_streak := calculate_current_streak(p_user_id);

  -- Update only streak-related fields
  UPDATE user_stats
  SET
    current_streak = v_current_streak,
    longest_streak = GREATEST(COALESCE(v_stats.longest_streak, 0), v_current_streak)
  WHERE user_id = p_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger function for streak updates
CREATE OR REPLACE FUNCTION trigger_streak_update()
RETURNS TRIGGER AS $$
BEGIN
  -- Only update streak when a journal entry is completed
  IF NEW.completed = true THEN
    PERFORM update_streak_only(NEW.user_id);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for journal entries
DROP TRIGGER IF EXISTS update_streak_on_completion ON journal_entries;
CREATE TRIGGER update_streak_on_completion
  AFTER INSERT OR UPDATE OF completed
  ON journal_entries
  FOR EACH ROW
  EXECUTE FUNCTION trigger_streak_update();

-- Update all user streaks
DO $$
DECLARE
  r RECORD;
BEGIN
  FOR r IN SELECT DISTINCT user_id FROM user_stats
  LOOP
    PERFORM update_streak_only(r.user_id);
  END LOOP;
END $$;