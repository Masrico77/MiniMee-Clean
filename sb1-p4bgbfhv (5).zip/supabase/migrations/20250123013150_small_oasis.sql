/*
  # Fix user_stats RLS policies

  1. Changes
    - Add RLS policies for user_stats table to allow:
      - Users to insert their own stats
      - Users to update their own stats
      - Users to read their own stats
  
  2. Security
    - Enable RLS on user_stats table
    - Add policies for authenticated users only
    - Restrict access to user's own data
*/

-- Drop existing policies if they exist
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can read own stats" ON user_stats;
  DROP POLICY IF EXISTS "Users can insert own stats" ON user_stats;
  DROP POLICY IF EXISTS "Users can update own stats" ON user_stats;
END $$;

-- Ensure RLS is enabled
ALTER TABLE user_stats ENABLE ROW LEVEL SECURITY;

-- Create policies for user_stats
CREATE POLICY "Users can read own stats"
  ON user_stats FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own stats"
  ON user_stats FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own stats"
  ON user_stats FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid());