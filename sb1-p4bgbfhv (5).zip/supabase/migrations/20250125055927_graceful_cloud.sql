-- Function to calculate streak without affecting last entry date or total entries
CREATE OR REPLACE FUNCTION calculate_current_streak(p_user_id uuid)
RETURNS integer AS $$
DECLARE
  v_current_date date;
  v_prev_date date := NULL;
  v_current_streak integer := 0;
BEGIN
  -- Calculate streak only looking at completed entries
  FOR v_current_date IN
    SELECT DISTINCT DATE(created_at)
    FROM journal_entries
    WHERE user_id = p_user_id
      AND completed = true
    ORDER BY DATE(created_at) DESC
  LOOP
    IF v_prev_date IS NULL THEN
      -- First entry
      v_current_streak := 1;
      v_prev_date := v_current_date;
    ELSIF are_dates_consecutive(v_current_date, v_prev_date) THEN
      -- Consecutive day
      v_current_streak := v_current_streak + 1;
    ELSE
      -- Gap detected - exit loop as we only care about current streak
      EXIT;
    END IF;
    v_prev_date := v_current_date;
  END LOOP;

  -- Check if the streak is still active (last completed entry must be today or yesterday)
  IF v_prev_date < CURRENT_DATE - interval '1 day' THEN
    v_current_streak := 0;
  END IF;

  RETURN v_current_streak;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to update only the streak
CREATE OR REPLACE FUNCTION update_streak_only(p_user_id uuid)
RETURNS void AS $$
DECLARE
  v_current_streak integer;
BEGIN
  -- Calculate new streak
  v_current_streak := calculate_current_streak(p_user_id);

  -- Update only the current_streak in user_stats
  UPDATE user_stats
  SET
    current_streak = v_current_streak,
    longest_streak = GREATEST(longest_streak, v_current_streak)
  WHERE user_id = p_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Update streaks for all users
DO $$
DECLARE
  r RECORD;
BEGIN
  FOR r IN SELECT DISTINCT user_id FROM user_stats
  LOOP
    PERFORM update_streak_only(r.user_id);
  END LOOP;
END $$;