/*
  # Update RLS Policies

  This migration safely adds or updates Row Level Security (RLS) policies
  without recreating existing tables.

  1. Security Updates
    - Adds INSERT policy for profiles table
    - Updates UPDATE policy for profiles table
    - Ensures consistent RLS policies across all tables
*/

-- Drop existing policies if they exist
DO $$ 
BEGIN
  -- Profiles policies
  DROP POLICY IF EXISTS "Users can read own profile" ON profiles;
  DROP POLICY IF EXISTS "Users can insert own profile" ON profiles;
  DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
  
  -- Journal entries policies
  DROP POLICY IF EXISTS "Users can read own journal entries" ON journal_entries;
  DROP POLICY IF EXISTS "Users can insert own journal entries" ON journal_entries;
  
  -- Prompt history policies
  DROP POLICY IF EXISTS "Users can read own prompt history" ON prompt_history;
  DROP POLICY IF EXISTS "Users can insert own prompt history" ON prompt_history;
END $$;

-- Ensure RLS is enabled
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE journal_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE prompt_history ENABLE ROW LEVEL SECURITY;

-- Create policies for profiles
CREATE POLICY "Users can read own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Create policies for journal entries
CREATE POLICY "Users can read own journal entries"
  ON journal_entries FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own journal entries"
  ON journal_entries FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

-- Create policies for prompt history
CREATE POLICY "Users can read own prompt history"
  ON prompt_history FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own prompt history"
  ON prompt_history FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());