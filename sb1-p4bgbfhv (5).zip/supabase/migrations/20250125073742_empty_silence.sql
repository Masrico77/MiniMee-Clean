-- Force recalculation of streaks with debug logging
DO $$
DECLARE
  r RECORD;
  v_dates date[];
  v_current_streak integer;
  v_user_id uuid;
BEGIN
  -- Loop through all users
  FOR r IN SELECT DISTINCT user_id FROM user_stats
  LOOP
    v_user_id := r.user_id;
    
    -- Get completed journal dates for this user
    SELECT ARRAY(
      SELECT DISTINCT DATE(created_at)
      FROM journal_entries
      WHERE user_id = v_user_id
        AND completed = true
      ORDER BY DATE(created_at) DESC
    ) INTO v_dates;

    -- Calculate streak for debugging
    IF array_length(v_dates, 1) > 0 THEN
      -- Force streak calculation
      SELECT calculate_current_streak(v_user_id) INTO v_current_streak;
      
      -- Update the user's stats
      UPDATE user_stats
      SET 
        current_streak = v_current_streak,
        longest_streak = GREATEST(longest_streak, v_current_streak),
        last_entry_date = (
          SELECT MAX(created_at)
          FROM journal_entries
          WHERE user_id = v_user_id
            AND completed = true
        )
      WHERE user_id = v_user_id;
    END IF;
  END LOOP;
END $$;