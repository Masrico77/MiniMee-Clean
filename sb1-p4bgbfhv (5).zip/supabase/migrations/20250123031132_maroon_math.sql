-- Create a function to safely set up new user stats
CREATE OR REPLACE FUNCTION setup_new_user_stats(p_user_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO user_stats (
    user_id,
    total_entries,
    longest_streak,
    current_streak,
    total_words,
    total_points,
    current_level,
    entries_this_week,
    entries_this_month
  )
  VALUES (
    p_user_id,
    0, 0, 0, 0, 0, 1, 0, 0
  )
  ON CONFLICT (user_id) DO NOTHING;
END;
$$;

-- Drop the old trigger if it exists
DROP TRIGGER IF EXISTS on_profile_created ON profiles;

-- Create a new trigger that uses the safe setup function
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  PERFORM setup_new_user_stats(NEW.id);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_profile_created
  AFTER INSERT ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();