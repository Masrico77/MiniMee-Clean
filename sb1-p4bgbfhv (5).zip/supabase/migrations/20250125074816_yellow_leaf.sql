-- Create enum for prompt categories
CREATE TYPE prompt_category AS ENUM (
  'gratitude',
  'reflection',
  'growth',
  'mindfulness',
  'goals',
  'relationships',
  'creativity',
  'challenges'
);

-- Create prompts table
CREATE TABLE IF NOT EXISTS journal_prompts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  question text NOT NULL,
  description text,
  category prompt_category NOT NULL,
  active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE journal_prompts ENABLE ROW LEVEL SECURITY;

-- Create policy for reading prompts
CREATE POLICY "Anyone can read active prompts"
  ON journal_prompts
  FOR SELECT
  TO authenticated
  USING (active = true);

-- Insert initial prompts
INSERT INTO journal_prompts (question, description, category) VALUES
  -- Gratitude
  ('What are three things you''re grateful for today?', 'Take a moment to appreciate the positive aspects of your day.', 'gratitude'),
  ('Who has positively impacted your life recently?', 'Reflect on the people who have made a difference.', 'gratitude'),
  ('What simple pleasure brought you joy today?', 'Sometimes the smallest things bring the most happiness.', 'gratitude'),

  -- Reflection
  ('What was the most meaningful part of your day?', 'Consider the moments that felt most significant.', 'reflection'),
  ('How are you different today than you were a year ago?', 'Reflect on your personal growth and changes.', 'reflection'),
  ('What has been occupying your thoughts lately?', 'Explore the themes and patterns in your thinking.', 'reflection'),

  -- Growth
  ('What is one thing you''d like to improve about yourself?', 'Focus on areas where you see potential for growth.', 'growth'),
  ('What new skill or knowledge would you like to acquire?', 'Consider your learning goals and aspirations.', 'growth'),
  ('What challenge have you overcome recently?', 'Reflect on your resilience and problem-solving abilities.', 'growth'),

  -- Mindfulness
  ('How are you feeling right now, in this moment?', 'Practice being present with your current emotional state.', 'mindfulness'),
  ('What sensations are you aware of in your body?', 'Connect with your physical experience in this moment.', 'mindfulness'),
  ('What is bringing you peace right now?', 'Notice the elements that contribute to your sense of calm.', 'mindfulness'),

  -- Goals
  ('What small step can you take today toward a bigger goal?', 'Break down your aspirations into manageable actions.', 'goals'),
  ('What would you like to achieve this week?', 'Set intentions for the near future.', 'goals'),
  ('How have your goals evolved recently?', 'Reflect on how your aspirations have changed over time.', 'goals'),

  -- Relationships
  ('How have your relationships grown or changed lately?', 'Consider the dynamics in your important connections.', 'relationships'),
  ('What qualities do you value most in your relationships?', 'Reflect on what makes your connections meaningful.', 'relationships'),
  ('How do you show care for others?', 'Consider your ways of expressing love and support.', 'relationships'),

  -- Creativity
  ('What creative ideas have you been exploring?', 'Think about your artistic or innovative thoughts.', 'creativity'),
  ('How do you express yourself creatively?', 'Reflect on your unique ways of creating and expressing.', 'creativity'),
  ('What inspires your imagination?', 'Consider the sources of your creative energy.', 'creativity'),

  -- Challenges
  ('What challenge are you currently facing?', 'Explore your current difficulties with compassion.', 'challenges'),
  ('How do you handle stress or uncertainty?', 'Reflect on your coping mechanisms and strategies.', 'challenges'),
  ('What lesson have you learned from a recent difficulty?', 'Consider the growth that comes from challenges.', 'challenges');

-- Create function to get random prompts
CREATE OR REPLACE FUNCTION get_random_prompts(
  p_count integer DEFAULT 5,
  p_category prompt_category DEFAULT NULL
)
RETURNS SETOF journal_prompts AS $$
BEGIN
  RETURN QUERY
  SELECT *
  FROM journal_prompts
  WHERE active = true
    AND (p_category IS NULL OR category = p_category)
  ORDER BY random()
  LIMIT p_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_journal_prompts_updated_at
  BEFORE UPDATE ON journal_prompts
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Create indexes
CREATE INDEX idx_journal_prompts_category ON journal_prompts(category);
CREATE INDEX idx_journal_prompts_active ON journal_prompts(active);