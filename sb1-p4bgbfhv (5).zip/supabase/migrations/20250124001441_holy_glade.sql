/*
  # Add metadata columns to chat_messages and journal_entries

  1. New Columns
    - Add metadata JSONB column to chat_messages
    - Add metadata JSONB column to journal_entries
  
  2. Changes
    - Add default empty JSON object
    - Add indexes for better query performance
*/

-- Add metadata column to chat_messages
ALTER TABLE chat_messages
ADD COLUMN IF NOT EXISTS metadata JSONB DEFAULT '{}'::jsonb;

-- Add metadata column to journal_entries
ALTER TABLE journal_entries
ADD COLUMN IF NOT EXISTS metadata JSONB DEFAULT '{}'::jsonb;

-- Create GIN indexes for faster JSON querying
CREATE INDEX IF NOT EXISTS idx_chat_messages_metadata 
ON chat_messages USING GIN (metadata);

CREATE INDEX IF NOT EXISTS idx_journal_entries_metadata 
ON journal_entries USING GIN (metadata);

-- Update existing rows to have default metadata
UPDATE chat_messages
SET metadata = '{}'::jsonb
WHERE metadata IS NULL;

UPDATE journal_entries
SET metadata = '{}'::jsonb
WHERE metadata IS NULL;