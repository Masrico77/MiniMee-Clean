-- Function to count completed journals
CREATE OR REPLACE FUNCTION count_completed_journals(p_user_id uuid)
RETURNS integer AS $$
DECLARE
  v_total_entries integer := 0;
  v_current_date date;
BEGIN
  -- Count days where all prompts were completed
  FOR v_current_date IN
    SELECT DISTINCT DATE(created_at)
    FROM journal_entries
    WHERE user_id = p_user_id
    ORDER BY DATE(created_at)
  LOOP
    IF is_journal_complete(p_user_id, v_current_date) THEN
      v_total_entries := v_total_entries + 1;
    END IF;
  END LOOP;

  RETURN v_total_entries;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Update recalculate_streaks function to also fix total entries
CREATE OR REPLACE FUNCTION recalculate_streaks(p_user_id uuid)
RETURNS void AS $$
DECLARE
  v_current_date date;
  v_streak_date date;
  v_current_streak integer := 0;
  v_longest_streak integer := 0;
  v_last_entry_date timestamptz;
  v_total_entries integer;
BEGIN
  -- Get total completed journals
  v_total_entries := count_completed_journals(p_user_id);

  -- Calculate streak (existing logic)
  FOR v_current_date IN
    SELECT DISTINCT DATE(created_at)
    FROM journal_entries
    WHERE user_id = p_user_id
    ORDER BY DATE(created_at) DESC
  LOOP
    IF is_journal_complete(p_user_id, v_current_date) THEN
      IF v_streak_date IS NULL OR v_current_date = v_streak_date - interval '1 day' THEN
        v_current_streak := v_current_streak + 1;
        v_longest_streak := GREATEST(v_longest_streak, v_current_streak);
      ELSE
        v_current_streak := 1;
      END IF;
      v_streak_date := v_current_date;
      
      IF v_last_entry_date IS NULL THEN
        SELECT MAX(created_at) INTO v_last_entry_date
        FROM journal_entries
        WHERE user_id = p_user_id
          AND DATE(created_at) = v_current_date;
      END IF;
    END IF;
  END LOOP;

  -- Update user stats with correct total entries
  UPDATE user_stats
  SET
    total_entries = v_total_entries,
    current_streak = v_current_streak,
    longest_streak = GREATEST(longest_streak, v_longest_streak),
    last_entry_date = v_last_entry_date
  WHERE user_id = p_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Recalculate stats for all users
DO $$
DECLARE
  r RECORD;
BEGIN
  FOR r IN SELECT DISTINCT user_id FROM user_stats
  LOOP
    PERFORM recalculate_streaks(r.user_id);
  END LOOP;
END $$;