-- First drop the trigger to remove dependencies
DROP TRIGGER IF EXISTS update_streak_on_completion ON journal_entries;

-- Then we can safely drop the functions
DROP FUNCTION IF EXISTS trigger_streak_update();
DROP FUNCTION IF EXISTS update_streak_only(uuid);
DROP FUNCTION IF EXISTS calculate_current_streak(uuid);

-- Create new brute force streak calculation function
CREATE OR REPLACE FUNCTION calculate_current_streak(p_user_id uuid)
RETURNS integer AS $$
DECLARE
  v_dates date[];
  v_current_streak integer := 0;
  v_prev_date date;
BEGIN
  -- Get all completed journal dates in descending order
  SELECT ARRAY(
    SELECT DISTINCT DATE(created_at)
    FROM journal_entries
    WHERE user_id = p_user_id
      AND completed = true
    ORDER BY DATE(created_at) DESC
  ) INTO v_dates;

  -- If no entries, return 0
  IF array_length(v_dates, 1) IS NULL THEN
    RETURN 0;
  END IF;

  -- Check if most recent entry is from today or yesterday
  IF v_dates[1] < CURRENT_DATE - interval '1 day' THEN
    RETURN 0;
  END IF;

  -- Calculate streak by checking consecutive days
  v_current_streak := 1;
  v_prev_date := v_dates[1];

  FOR i IN 2..array_length(v_dates, 1) LOOP
    -- If there's a gap, break the streak
    IF v_dates[i] != v_prev_date - interval '1 day' THEN
      EXIT;
    END IF;
    v_current_streak := v_current_streak + 1;
    v_prev_date := v_dates[i];
  END LOOP;

  RETURN v_current_streak;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create function to update streak
CREATE OR REPLACE FUNCTION update_streak_only(p_user_id uuid)
RETURNS void AS $$
DECLARE
  v_current_streak integer;
BEGIN
  -- Calculate new streak
  v_current_streak := calculate_current_streak(p_user_id);

  -- Update user stats
  UPDATE user_stats
  SET
    current_streak = v_current_streak,
    longest_streak = GREATEST(longest_streak, v_current_streak)
  WHERE user_id = p_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger function
CREATE OR REPLACE FUNCTION trigger_streak_update()
RETURNS TRIGGER AS $$
BEGIN
  -- Only update streak when a journal entry is completed
  IF NEW.completed = true THEN
    PERFORM update_streak_only(NEW.user_id);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger
CREATE TRIGGER update_streak_on_completion
  AFTER INSERT OR UPDATE OF completed
  ON journal_entries
  FOR EACH ROW
  EXECUTE FUNCTION trigger_streak_update();

-- Update all existing streaks
DO $$
DECLARE
  r RECORD;
BEGIN
  FOR r IN SELECT DISTINCT user_id FROM user_stats
  LOOP
    PERFORM update_streak_only(r.user_id);
  END LOOP;
END $$;