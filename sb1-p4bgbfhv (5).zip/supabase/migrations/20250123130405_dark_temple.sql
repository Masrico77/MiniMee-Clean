/*
  # Fix Streak Calculation Logic

  1. Changes
    - Properly handle streak calculations based on consecutive days
    - Ensure streaks are tied to actual entries
    - Fix edge cases with same-day entries
    - Add proper error handling
  
  2. Functions
    - update_user_stats: Main function to update stats including streaks
    - calculate_streak: Helper function to calculate current streak
*/

-- Helper function to calculate streak
CREATE OR REPLACE FUNCTION calculate_streak(p_user_id uuid)
RETURNS integer AS $$
DECLARE
  v_streak integer := 0;
  v_last_date date;
  v_current_date date := CURRENT_DATE;
BEGIN
  -- Get the most recent entry date
  SELECT date_trunc('day', created_at)::date
  INTO v_last_date
  FROM journal_entries
  WHERE user_id = p_user_id
  ORDER BY created_at DESC
  LIMIT 1;

  -- If no entries, return 0
  IF v_last_date IS NULL THEN
    RETURN 0;
  END IF;

  -- If last entry was today, check streak
  IF v_last_date = v_current_date THEN
    WITH dated_entries AS (
      SELECT DISTINCT date_trunc('day', created_at)::date as entry_date
      FROM journal_entries
      WHERE user_id = p_user_id
      ORDER BY entry_date DESC
    )
    SELECT count(*)
    INTO v_streak
    FROM (
      SELECT entry_date,
             row_number() OVER (ORDER BY entry_date DESC) as rn,
             entry_date - (row_number() OVER (ORDER BY entry_date DESC))::integer as grp
      FROM dated_entries
      WHERE entry_date >= v_current_date - interval '30 days'
    ) sub
    WHERE grp = (
      SELECT entry_date - (row_number() OVER (ORDER BY entry_date DESC))::integer
      FROM dated_entries
      WHERE entry_date = v_current_date
      LIMIT 1
    );
  END IF;

  RETURN v_streak;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Main function to update user stats
CREATE OR REPLACE FUNCTION update_user_stats(p_user_id uuid)
RETURNS void AS $$
DECLARE
  v_current_streak integer;
  v_total_entries integer;
  v_longest_streak integer;
BEGIN
  -- Calculate current streak
  v_current_streak := calculate_streak(p_user_id);
  
  -- Get total entries
  SELECT count(DISTINCT date_trunc('day', created_at))
  INTO v_total_entries
  FROM journal_entries
  WHERE user_id = p_user_id;

  -- Get longest streak
  SELECT COALESCE(longest_streak, 0)
  INTO v_longest_streak
  FROM user_stats
  WHERE user_id = p_user_id;

  -- Update longest streak if current is higher
  v_longest_streak := GREATEST(v_longest_streak, v_current_streak);

  -- Update stats
  UPDATE user_stats
  SET
    current_streak = v_current_streak,
    longest_streak = v_longest_streak,
    total_entries = v_total_entries,
    last_entry_date = CURRENT_TIMESTAMP
  WHERE user_id = p_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for journal entries
CREATE OR REPLACE FUNCTION on_journal_entry()
RETURNS TRIGGER AS $$
BEGIN
  PERFORM update_user_stats(NEW.user_id);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop existing trigger if it exists
DROP TRIGGER IF EXISTS journal_entry_trigger ON journal_entries;

-- Create new trigger
CREATE TRIGGER journal_entry_trigger
  AFTER INSERT ON journal_entries
  FOR EACH ROW
  EXECUTE FUNCTION on_journal_entry();

-- Update all existing user stats
DO $$
DECLARE
  r RECORD;
BEGIN
  FOR r IN SELECT DISTINCT user_id FROM journal_entries
  LOOP
    PERFORM update_user_stats(r.user_id);
  END LOOP;
END $$;