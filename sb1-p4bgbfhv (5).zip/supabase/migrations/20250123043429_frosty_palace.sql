/*
  # Fix streak reset logic

  1. Changes
    - Add new function to properly handle streak resets
    - Ensures streak is reset to 0 (not 1) when broken
    - Maintains consistent behavior across all streak calculations

  2. Implementation
    - Creates a new function that will be used for streak updates
    - Does not modify existing functions to maintain backwards compatibility
    - Adds additional validation for edge cases
*/

-- Create a new function for proper streak handling
CREATE OR REPLACE FUNCTION update_user_streak(
  p_user_id uuid,
  p_current_date timestamptz DEFAULT CURRENT_TIMESTAMP
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_last_entry_date timestamptz;
  v_current_streak integer;
  v_longest_streak integer;
BEGIN
  -- Get current user stats
  SELECT 
    last_entry_date,
    current_streak,
    longest_streak
  INTO
    v_last_entry_date,
    v_current_streak,
    v_longest_streak
  FROM user_stats
  WHERE user_id = p_user_id;

  -- Calculate new streak
  IF v_last_entry_date IS NULL THEN
    -- First entry
    v_current_streak := 1;
  ELSIF v_last_entry_date >= p_current_date::date - interval '1 day' AND 
        v_last_entry_date < p_current_date::date + interval '1 day' THEN
    -- Consecutive day (including same-day entries)
    v_current_streak := v_current_streak + 1;
  ELSE
    -- Break in streak - reset to 0
    v_current_streak := 0;
  END IF;

  -- Update longest streak if current streak is longer
  v_longest_streak := GREATEST(v_longest_streak, v_current_streak);

  -- Update user stats
  UPDATE user_stats
  SET
    current_streak = v_current_streak,
    longest_streak = v_longest_streak,
    last_entry_date = p_current_date
  WHERE user_id = p_user_id;
END;
$$;

-- Create a trigger function to automatically update streaks
CREATE OR REPLACE FUNCTION trigger_update_streak()
RETURNS TRIGGER AS $$
BEGIN
  PERFORM update_user_streak(NEW.user_id);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger on journal entries
DROP TRIGGER IF EXISTS update_streak_on_entry ON journal_entries;
CREATE TRIGGER update_streak_on_entry
  AFTER INSERT ON journal_entries
  FOR EACH ROW
  EXECUTE FUNCTION trigger_update_streak();

-- Update existing streaks to ensure consistency
DO $$
DECLARE
  r RECORD;
BEGIN
  FOR r IN SELECT DISTINCT user_id FROM user_stats
  LOOP
    PERFORM update_user_streak(r.user_id);
  END LOOP;
END $$;