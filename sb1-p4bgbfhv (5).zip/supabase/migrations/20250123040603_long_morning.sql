/*
  # Add onboarding tracking to profiles

  1. Changes
    - Add onboarding_completed column to profiles table
    - Set default value to false
    - Add index for faster queries
*/

-- Add onboarding_completed column to profiles table
ALTER TABLE profiles 
ADD COLUMN IF NOT EXISTS onboarding_completed boolean DEFAULT false;

-- Add index for faster onboarding status queries
CREATE INDEX IF NOT EXISTS idx_profiles_onboarding_completed 
ON profiles(onboarding_completed);

-- Update existing profiles to have onboarding_completed set to true
-- since they were created before this feature
UPDATE profiles 
SET onboarding_completed = true 
WHERE onboarding_completed IS NULL;