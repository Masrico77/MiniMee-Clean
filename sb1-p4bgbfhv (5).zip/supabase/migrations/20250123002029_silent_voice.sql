/*
  # Backfill User Streaks

  1. Changes
    - Creates a function to calculate user streaks
    - Updates user_stats table with correct streak calculations
    - Handles edge cases and data consistency

  2. Details
    - Calculates current streak based on consecutive daily entries
    - Updates longest streak if current streak is longer
    - Preserves existing data while updating only streak-related fields
*/

-- Function to calculate user streaks
CREATE OR REPLACE FUNCTION calculate_user_streaks(p_user_id uuid)
RETURNS TABLE (
  current_streak integer,
  longest_streak integer,
  last_entry_date timestamptz
) AS $$
DECLARE
  v_current_date date := current_date;
  v_last_entry timestamptz;
  v_current_streak integer := 0;
  v_longest_streak integer := 0;
  v_prev_date date;
BEGIN
  -- Get all entry dates for the user, ordered by date
  FOR v_last_entry IN
    SELECT created_at
    FROM journal_entries
    WHERE user_id = p_user_id
    ORDER BY created_at DESC
  LOOP
    -- Convert timestamp to date for comparison
    IF v_prev_date IS NULL THEN
      -- First entry
      v_prev_date := v_last_entry::date;
      v_current_streak := 1;
    ELSIF v_prev_date - v_last_entry::date = 1 THEN
      -- Consecutive day
      v_current_streak := v_current_streak + 1;
    ELSE
      -- Break in streak
      v_longest_streak := GREATEST(v_longest_streak, v_current_streak);
      v_current_streak := 1;
    END IF;
    
    v_prev_date := v_last_entry::date;
  END LOOP;

  -- Update longest streak one final time
  v_longest_streak := GREATEST(v_longest_streak, v_current_streak);

  -- Check if the streak is still active (last entry was yesterday or today)
  IF v_last_entry::date < v_current_date - interval '1 day' THEN
    v_current_streak := 0;
  END IF;

  RETURN QUERY SELECT 
    v_current_streak,
    v_longest_streak,
    v_last_entry;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Update all user stats with correct streak calculations
DO $$
DECLARE
  r RECORD;
BEGIN
  FOR r IN SELECT id FROM profiles
  LOOP
    WITH streak_calc AS (
      SELECT * FROM calculate_user_streaks(r.id)
    )
    UPDATE user_stats
    SET
      current_streak = streak_calc.current_streak,
      longest_streak = streak_calc.longest_streak,
      last_entry_date = streak_calc.last_entry_date
    FROM streak_calc
    WHERE user_id = r.id;
  END LOOP;
END $$;