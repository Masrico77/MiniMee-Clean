/*
  # Add Gamification Features

  1. New Tables
    - `achievements`
      - Stores predefined achievements users can unlock
    - `user_achievements`
      - Tracks which achievements users have unlocked
    - `user_stats`
      - Tracks detailed user statistics and progress
    - `user_levels`
      - Defines level thresholds and rewards

  2. Security
    - Enable RLS on all new tables
    - Add policies for authenticated users
*/

-- Create achievements table
CREATE TABLE IF NOT EXISTS achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text NOT NULL,
  category text NOT NULL,
  points integer NOT NULL DEFAULT 0,
  icon_name text NOT NULL,
  requirements jsonb NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create user achievements table
CREATE TABLE IF NOT EXISTS user_achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  achievement_id uuid REFERENCES achievements(id) ON DELETE CASCADE NOT NULL,
  unlocked_at timestamptz DEFAULT now(),
  UNIQUE(user_id, achievement_id)
);

-- Create user stats table
CREATE TABLE IF NOT EXISTS user_stats (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  total_entries integer DEFAULT 0,
  longest_streak integer DEFAULT 0,
  current_streak integer DEFAULT 0,
  total_words integer DEFAULT 0,
  total_points integer DEFAULT 0,
  current_level integer DEFAULT 1,
  entries_this_week integer DEFAULT 0,
  entries_this_month integer DEFAULT 0,
  last_entry_date timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

-- Create user levels table
CREATE TABLE IF NOT EXISTS user_levels (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  level_number integer NOT NULL,
  title text NOT NULL,
  min_points integer NOT NULL,
  icon_name text NOT NULL,
  color_scheme text NOT NULL,
  perks jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  UNIQUE(level_number)
);

-- Enable RLS
ALTER TABLE achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_stats ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_levels ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Everyone can read achievements"
  ON achievements FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can read own achievements"
  ON user_achievements FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own achievements"
  ON user_achievements FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can read own stats"
  ON user_stats FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can update own stats"
  ON user_stats FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Everyone can read level information"
  ON user_levels FOR SELECT
  TO authenticated
  USING (true);

-- Insert default achievements
INSERT INTO achievements (name, description, category, points, icon_name, requirements) VALUES
  ('First Entry', 'Complete your first journal entry', 'milestones', 100, 'Pencil', '{"entries": 1}'),
  ('Weekly Warrior', 'Complete entries for 7 consecutive days', 'streaks', 500, 'Calendar', '{"streak": 7}'),
  ('Monthly Master', 'Complete entries for 30 consecutive days', 'streaks', 2000, 'Crown', '{"streak": 30}'),
  ('Reflection Rookie', 'Write 5 journal entries', 'milestones', 200, 'Book', '{"entries": 5}'),
  ('Journaling Journey', 'Write 20 journal entries', 'milestones', 1000, 'BookOpen', '{"entries": 20}'),
  ('Wordsmith', 'Write over 10,000 words', 'writing', 1500, 'PenTool', '{"words": 10000}'),
  ('Early Bird', 'Complete 5 entries before 9 AM', 'habits', 300, 'Sun', '{"morning_entries": 5}'),
  ('Night Owl', 'Complete 5 entries after 9 PM', 'habits', 300, 'Moon', '{"night_entries": 5}');

-- Insert default levels
INSERT INTO user_levels (level_number, title, min_points, icon_name, color_scheme, perks) VALUES
  (1, 'Novice Writer', 0, 'Pencil', 'gray', '{"features": ["basic_prompts"]}'),
  (2, 'Aspiring Journalist', 500, 'Book', 'blue', '{"features": ["basic_prompts", "custom_themes"]}'),
  (3, 'Dedicated Diarist', 2000, 'BookOpen', 'green', '{"features": ["basic_prompts", "custom_themes", "ai_insights"]}'),
  (4, 'Reflection Master', 5000, 'Crown', 'purple', '{"features": ["basic_prompts", "custom_themes", "ai_insights", "advanced_analytics"]}'),
  (5, 'Wisdom Keeper', 10000, 'Star', 'gold', '{"features": ["basic_prompts", "custom_themes", "ai_insights", "advanced_analytics", "custom_prompts"]}');