/*
  # Add metadata support for ChatGPT searching

  1. New Columns
    - Add metadata columns to journal_entries and chat_messages tables
    - Add search_vector column for full-text search
  
  2. Functions
    - Create function to generate search vectors
    - Create function to update search vectors
  
  3. Triggers
    - Create triggers to automatically update search vectors
    
  4. Indexes
    - Create GIN indexes for efficient searching
*/

-- Add search vector column to journal_entries
ALTER TABLE journal_entries
ADD COLUMN IF NOT EXISTS search_vector tsvector;

-- Add search vector column to chat_messages
ALTER TABLE chat_messages
ADD COLUMN IF NOT EXISTS search_vector tsvector;

-- Create function to generate search vector
CREATE OR REPLACE FUNCTION generate_search_vector(
  content text,
  metadata jsonb
) RETURNS tsvector AS $$
BEGIN
  RETURN (
    setweight(to_tsvector('english', COALESCE(content, '')), 'A') ||
    setweight(to_tsvector('english', COALESCE(metadata->>'emotional_themes', '')), 'B') ||
    setweight(to_tsvector('english', COALESCE(metadata->>'key_topics', '')), 'B') ||
    setweight(to_tsvector('english', COALESCE(metadata->>'sentiment_indicators', '')), 'C')
  );
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Create trigger function for journal entries
CREATE OR REPLACE FUNCTION journal_entries_search_trigger() RETURNS trigger AS $$
BEGIN
  NEW.search_vector := generate_search_vector(
    NEW.answer || ' ' || COALESCE(NEW.ai_response, ''),
    NEW.metadata
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger function for chat messages
CREATE OR REPLACE FUNCTION chat_messages_search_trigger() RETURNS trigger AS $$
BEGIN
  NEW.search_vector := generate_search_vector(
    NEW.content,
    NEW.metadata
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers
DROP TRIGGER IF EXISTS journal_entries_search_update ON journal_entries;
CREATE TRIGGER journal_entries_search_update
  BEFORE INSERT OR UPDATE
  ON journal_entries
  FOR EACH ROW
  EXECUTE FUNCTION journal_entries_search_trigger();

DROP TRIGGER IF EXISTS chat_messages_search_update ON chat_messages;
CREATE TRIGGER chat_messages_search_update
  BEFORE INSERT OR UPDATE
  ON chat_messages
  FOR EACH ROW
  EXECUTE FUNCTION chat_messages_search_trigger();

-- Create GIN indexes for search vectors
CREATE INDEX IF NOT EXISTS idx_journal_entries_search_vector
  ON journal_entries
  USING GIN (search_vector);

CREATE INDEX IF NOT EXISTS idx_chat_messages_search_vector
  ON chat_messages
  USING GIN (search_vector);

-- Update existing entries
UPDATE journal_entries
SET search_vector = generate_search_vector(
  answer || ' ' || COALESCE(ai_response, ''),
  metadata
);

UPDATE chat_messages
SET search_vector = generate_search_vector(
  content,
  metadata
);

-- Create search function
CREATE OR REPLACE FUNCTION search_user_content(
  p_user_id uuid,
  p_query text,
  p_limit integer DEFAULT 10
) RETURNS TABLE (
  content_type text,
  content text,
  metadata jsonb,
  created_at timestamptz,
  similarity real
) LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  RETURN QUERY
  (
    SELECT
      'journal' as content_type,
      answer || E'\n' || COALESCE(ai_response, '') as content,
      metadata,
      created_at,
      ts_rank(search_vector, websearch_to_tsquery('english', p_query)) as similarity
    FROM journal_entries
    WHERE user_id = p_user_id
      AND search_vector @@ websearch_to_tsquery('english', p_query)
    
    UNION ALL
    
    SELECT
      'chat' as content_type,
      content,
      metadata,
      created_at,
      ts_rank(search_vector, websearch_to_tsquery('english', p_query)) as similarity
    FROM chat_messages
    WHERE user_id = p_user_id
      AND search_vector @@ websearch_to_tsquery('english', p_query)
  )
  ORDER BY similarity DESC, created_at DESC
  LIMIT p_limit;
END;
$$;