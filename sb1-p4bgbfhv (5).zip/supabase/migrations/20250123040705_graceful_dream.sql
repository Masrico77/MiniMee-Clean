/*
  # Fix user stats handling

  1. Changes
    - Add unique constraint to user_stats table
    - Update user stats functions to handle conflicts properly
    - Add better error handling for stats creation
*/

-- First, ensure the unique constraint exists
ALTER TABLE user_stats 
DROP CONSTRAINT IF EXISTS user_stats_user_id_key;

ALTER TABLE user_stats
ADD CONSTRAINT user_stats_user_id_key UNIQUE (user_id);

-- Update the setup function to handle conflicts properly
CREATE OR REPLACE FUNCTION setup_new_user_stats(p_user_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO user_stats (
    user_id,
    total_entries,
    longest_streak,
    current_streak,
    total_words,
    total_points,
    current_level,
    entries_this_week,
    entries_this_month
  )
  VALUES (
    p_user_id,
    0, 0, 0, 0, 0, 1, 0, 0
  )
  ON CONFLICT (user_id) 
  DO UPDATE SET
    updated_at = now()
  WHERE user_stats.user_id = EXCLUDED.user_id;
END;
$$;

-- Update the handle_new_user trigger function
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  -- Attempt to create user stats, ignoring if they already exist
  BEGIN
    PERFORM setup_new_user_stats(NEW.id);
  EXCEPTION WHEN unique_violation THEN
    -- Stats already exist, nothing to do
    NULL;
  END;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;