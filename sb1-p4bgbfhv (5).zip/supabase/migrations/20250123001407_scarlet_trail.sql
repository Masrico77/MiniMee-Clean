/*
  # Add User Stats Functions
  
  1. New Functions
    - create_user_stats(): Creates initial user stats record
    - update_user_stats(): Updates user stats after journal entry
  
  2. Trigger
    - Auto-create user stats on profile creation
*/

-- Function to create initial user stats
CREATE OR REPLACE FUNCTION create_user_stats()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO user_stats (
    user_id,
    total_entries,
    longest_streak,
    current_streak,
    total_words,
    total_points,
    current_level,
    entries_this_week,
    entries_this_month,
    last_entry_date
  ) VALUES (
    NEW.id,
    0,
    0,
    0,
    0,
    0,
    1,
    0,
    0,
    NULL
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to create user stats when profile is created
DROP TRIGGER IF EXISTS on_profile_created ON profiles;
CREATE TRIGGER on_profile_created
  AFTER INSERT ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION create_user_stats();

-- Function to update user stats
CREATE OR REPLACE FUNCTION update_user_stats(
  p_user_id uuid,
  p_words integer
)
RETURNS void AS $$
DECLARE
  v_last_entry_date timestamptz;
  v_current_date timestamptz := current_timestamp;
BEGIN
  -- Get the last entry date
  SELECT last_entry_date INTO v_last_entry_date
  FROM user_stats
  WHERE user_id = p_user_id;

  -- Update user stats
  UPDATE user_stats
  SET
    total_entries = total_entries + 1,
    total_words = total_words + p_words,
    entries_this_week = CASE 
      WHEN v_last_entry_date IS NULL OR 
           date_trunc('week', v_current_date) != date_trunc('week', v_last_entry_date)
      THEN 1
      ELSE entries_this_week + 1
    END,
    entries_this_month = CASE 
      WHEN v_last_entry_date IS NULL OR 
           date_trunc('month', v_current_date) != date_trunc('month', v_last_entry_date)
      THEN 1
      ELSE entries_this_month + 1
    END,
    current_streak = CASE
      WHEN v_last_entry_date IS NULL THEN 1
      WHEN v_last_entry_date >= current_date - interval '1 day' THEN current_streak + 1
      ELSE 1
    END,
    longest_streak = CASE
      WHEN v_last_entry_date IS NULL THEN 1
      WHEN v_last_entry_date >= current_date - interval '1 day' AND current_streak + 1 > longest_streak THEN current_streak + 1
      ELSE longest_streak
    END,
    last_entry_date = v_current_date
  WHERE user_id = p_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;