/*
  # Fix User Setup Functions

  1. New Functions
    - setup_new_user: Creates profile and stats for new users
    - ensure_user_setup: Ensures profile and stats exist for existing users
  
  2. Changes
    - Added proper error handling
    - Added atomic operations
    - Added proper conflict handling
*/

-- Function to set up a new user
CREATE OR REPLACE FUNCTION setup_new_user(
  user_id uuid,
  user_email text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Create profile
  INSERT INTO profiles (id, email, created_at, last_login)
  VALUES (user_id, user_email, now(), now())
  ON CONFLICT (id) DO UPDATE
  SET last_login = now();

  -- Create initial stats
  INSERT INTO user_stats (
    user_id,
    total_entries,
    longest_streak,
    current_streak,
    total_words,
    total_points,
    current_level,
    entries_this_week,
    entries_this_month
  )
  VALUES (
    user_id,
    0, 0, 0, 0, 0, 1, 0, 0
  )
  ON CONFLICT (user_id) DO NOTHING;
END;
$$;

-- Function to ensure user setup is complete
CREATE OR REPLACE FUNCTION ensure_user_setup(
  user_id uuid,
  user_email text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Ensure profile exists and update last login
  INSERT INTO profiles (id, email, created_at, last_login)
  VALUES (user_id, user_email, now(), now())
  ON CONFLICT (id) DO UPDATE
  SET 
    last_login = now(),
    email = EXCLUDED.email;

  -- Ensure stats exist
  INSERT INTO user_stats (
    user_id,
    total_entries,
    longest_streak,
    current_streak,
    total_words,
    total_points,
    current_level,
    entries_this_week,
    entries_this_month
  )
  VALUES (
    user_id,
    0, 0, 0, 0, 0, 1, 0, 0
  )
  ON CONFLICT (user_id) DO NOTHING;
END;
$$;