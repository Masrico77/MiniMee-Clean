/*
  # Notification System Setup

  1. New Tables
    - `push_subscriptions`: Stores web push notification subscriptions
    - `notification_schedules`: Stores scheduled notification configurations
  
  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
    
  3. Functions
    - Add function to send notifications via Edge Function
*/

-- Create push subscriptions table
CREATE TABLE IF NOT EXISTS push_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  subscription jsonb NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create notification schedules table
CREATE TABLE IF NOT EXISTS notification_schedules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  body text NOT NULL,
  schedule_type text NOT NULL CHECK (schedule_type IN ('morning', 'evening')),
  schedule_time time NOT NULL,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Insert default notification schedules
INSERT INTO notification_schedules (title, body, schedule_type, schedule_time) VALUES
  ('Start Your Day with Reflection', 'Take a moment to set your intentions for the day with MiniMee.', 'morning', '09:00:00'),
  ('Complete Your Daily Journal', 'End your day with mindful reflection. Your journal is waiting for you.', 'evening', '20:00:00');

-- Enable RLS
ALTER TABLE push_subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE notification_schedules ENABLE ROW LEVEL SECURITY;

-- Create policies for push_subscriptions
CREATE POLICY "Users can manage their own subscriptions"
  ON push_subscriptions
  FOR ALL
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

-- Create policies for notification_schedules
CREATE POLICY "Everyone can read notification schedules"
  ON notification_schedules
  FOR SELECT
  TO authenticated
  USING (true);

-- Create function to send notifications
CREATE OR REPLACE FUNCTION send_notifications(
  p_title text,
  p_body text,
  p_url text DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- This function will be called by an external scheduler
  -- The actual notification sending will be handled by an Edge Function
  PERFORM net.http_post(
    url := current_setting('app.settings.edge_function_url', true) || '/send-notifications',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', current_setting('app.settings.edge_function_key', true)
    ),
    body := jsonb_build_object(
      'title', p_title,
      'body', p_body,
      'url', p_url
    )
  );
END;
$$;

-- Create index for better query performance
CREATE INDEX idx_push_subscriptions_user_id ON push_subscriptions(user_id);
CREATE INDEX idx_notification_schedules_schedule_type ON notification_schedules(schedule_type);
CREATE INDEX idx_notification_schedules_schedule_time ON notification_schedules(schedule_time);

-- Add trigger to update timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_push_subscriptions_updated_at
  BEFORE UPDATE ON push_subscriptions
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_notification_schedules_updated_at
  BEFORE UPDATE ON notification_schedules
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();