/*
  # Fix Last Entry Date Display

  1. Changes
    - Updates last_entry_date calculation to show the most recent entry date
    - Preserves streak calculation logic
    - Maintains total entries count

  2. Key Updates
    - Modifies recalculate_streaks function to properly set last_entry_date
    - Ensures last_entry_date reflects the most recent entry regardless of streak

  3. Security
    - Maintains existing RLS policies
    - Functions remain security definer
*/

-- Updated recalculate_streaks function with proper last entry date handling
CREATE OR REPLACE FUNCTION recalculate_streaks(p_user_id uuid)
RETURNS void AS $$
DECLARE
  v_current_date date;
  v_prev_date date := NULL;
  v_current_streak integer := 0;
  v_longest_streak integer := 0;
  v_last_entry_date timestamptz;
  v_total_entries integer;
BEGIN
  -- Get the most recent entry date first
  SELECT MAX(created_at)
  INTO v_last_entry_date
  FROM journal_entries
  WHERE user_id = p_user_id
    AND completed = true;

  -- Get total completed journals (preserve this calculation)
  v_total_entries := count_completed_journals(p_user_id);

  -- Calculate streak with proper gap handling
  FOR v_current_date IN
    SELECT DISTINCT DATE(created_at)
    FROM journal_entries
    WHERE user_id = p_user_id
      AND completed = true
    ORDER BY DATE(created_at) DESC
  LOOP
    IF v_prev_date IS NULL THEN
      -- First entry
      v_current_streak := 1;
      v_prev_date := v_current_date;
    ELSIF are_dates_consecutive(v_current_date, v_prev_date) THEN
      -- Consecutive day
      v_current_streak := v_current_streak + 1;
    ELSE
      -- Gap detected - reset streak
      v_current_streak := 0;
    END IF;

    -- Update longest streak
    v_longest_streak := GREATEST(v_longest_streak, v_current_streak);
    v_prev_date := v_current_date;
  END LOOP;

  -- Check if the streak is still active (last entry must be today or yesterday)
  IF v_last_entry_date < CURRENT_DATE - interval '1 day' THEN
    v_current_streak := 0;
  END IF;

  -- Update user stats
  UPDATE user_stats
  SET
    current_streak = v_current_streak,
    longest_streak = GREATEST(longest_streak, v_longest_streak),
    last_entry_date = v_last_entry_date,  -- This will now show January 23
    total_entries = v_total_entries
  WHERE user_id = p_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Recalculate streaks for all users
DO $$
DECLARE
  r RECORD;
BEGIN
  FOR r IN SELECT DISTINCT user_id FROM user_stats
  LOOP
    PERFORM recalculate_streaks(r.user_id);
  END LOOP;
END $$;