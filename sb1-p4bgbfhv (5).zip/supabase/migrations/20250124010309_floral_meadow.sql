-- Add completed flag to journal_entries
ALTER TABLE journal_entries 
ADD COLUMN IF NOT EXISTS completed BOOLEAN DEFAULT false;

-- Create function to check if journal is complete
CREATE OR REPLACE FUNCTION is_journal_complete(p_user_id uuid, p_date date)
RETURNS boolean AS $$
DECLARE
  v_total_prompts integer;
  v_answered_prompts integer;
BEGIN
  -- Get total number of prompts
  SELECT COUNT(*) INTO v_total_prompts FROM (
    SELECT DISTINCT prompt FROM journal_entries
    WHERE user_id = p_user_id
  ) AS distinct_prompts;

  -- Get number of prompts answered on given date
  SELECT COUNT(DISTINCT prompt) INTO v_answered_prompts
  FROM journal_entries
  WHERE user_id = p_user_id
    AND DATE(created_at) = p_date;

  RETURN v_answered_prompts >= v_total_prompts;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to recalculate streaks based on complete submissions
CREATE OR REPLACE FUNCTION recalculate_streaks(p_user_id uuid)
RETURNS void AS $$
DECLARE
  v_current_date date;
  v_streak_date date;
  v_current_streak integer := 0;
  v_longest_streak integer := 0;
  v_last_entry_date timestamptz;
BEGIN
  -- Get dates with complete journals
  FOR v_current_date IN
    SELECT DISTINCT DATE(created_at)
    FROM journal_entries
    WHERE user_id = p_user_id
    ORDER BY DATE(created_at) DESC
  LOOP
    -- Check if journal is complete for this date
    IF is_journal_complete(p_user_id, v_current_date) THEN
      IF v_streak_date IS NULL OR v_current_date = v_streak_date - interval '1 day' THEN
        -- Continue streak
        v_current_streak := v_current_streak + 1;
        v_longest_streak := GREATEST(v_longest_streak, v_current_streak);
      ELSE
        -- Break in streak
        v_current_streak := 1;
      END IF;
      v_streak_date := v_current_date;
      
      -- Store the most recent entry date
      IF v_last_entry_date IS NULL THEN
        SELECT MAX(created_at) INTO v_last_entry_date
        FROM journal_entries
        WHERE user_id = p_user_id
          AND DATE(created_at) = v_current_date;
      END IF;
    END IF;
  END LOOP;

  -- Update user stats
  UPDATE user_stats
  SET
    current_streak = v_current_streak,
    longest_streak = GREATEST(longest_streak, v_longest_streak),
    last_entry_date = v_last_entry_date
  WHERE user_id = p_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Recalculate streaks for all users
DO $$
DECLARE
  r RECORD;
BEGIN
  FOR r IN SELECT DISTINCT user_id FROM user_stats
  LOOP
    PERFORM recalculate_streaks(r.user_id);
  END LOOP;
END $$;